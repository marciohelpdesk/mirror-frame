
// Simple event bus for auth state changes
const listeners = new Set<(event: string, session: any) => void>();

// This mocks the Supabase client so the UI works without real credentials
export const supabase = {
  auth: {
    getSession: async () => {
      const stored = localStorage.getItem('pur_session');
      return { data: { session: stored ? JSON.parse(stored) : null } };
    },
    onAuthStateChange: (callback: (event: string, session: any) => void) => {
      listeners.add(callback);
      // Return unsubscribe function correctly structured
      return { data: { subscription: { unsubscribe: () => listeners.delete(callback) } } };
    },
    signInWithPassword: async ({ email, password }: any) => {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (email && password) {
        const session = { 
          user: { id: '1', email, user_metadata: { full_name: 'Marcio Silva' } },
          access_token: 'mock_token'
        };
        localStorage.setItem('pur_session', JSON.stringify(session));
        
        // Notify all listeners about the sign in
        listeners.forEach(cb => cb('SIGNED_IN', session));
        
        return { data: { session }, error: null };
      }
      return { data: null, error: { message: 'Invalid credentials' } };
    },
    signOut: async () => {
      localStorage.removeItem('pur_session');
      // Notify all listeners about the sign out
      listeners.forEach(cb => cb('SIGNED_OUT', null));
      return { error: null };
    }
  }
};
