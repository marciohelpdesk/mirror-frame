import { create } from 'zustand';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  score: number;
}

interface AppState {
  user: User | null;
  notifications: number;
  theme: 'light' | 'dark';
  
  // Actions
  setUser: (user: User) => void;
  updateScore: (points: number) => void;
  readNotification: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: {
    id: '1',
    name: 'Marcio Silva',
    email: 'marcio@pur.app',
    score: 94
  },
  notifications: 3,
  theme: 'light',

  setUser: (user) => set({ user }),
  updateScore: (points) => set((state) => ({ 
    user: state.user ? { ...state.user, score: state.user.score + points } : null 
  })),
  readNotification: () => set((state) => ({ 
    notifications: Math.max(0, state.notifications - 1) 
  })),
}));