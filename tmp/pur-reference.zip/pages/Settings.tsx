import React, { useState, useEffect } from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  User, 
  Bell, 
  Moon, 
  Globe, 
  Shield, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Star,
  Link,
  CheckCircle,
  Bot,
  Zap,
  Play
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseMock';
import { useToast } from '@/components/ui/toaster';

export default function Settings() {
  const navigate = useNavigate();
  const toast = useToast();
  // Initialize from localStorage (default to true)
  const [isAirbnbConnected, setIsAirbnbConnected] = useState(() => {
    return localStorage.getItem('airbnb_alerts_enabled') !== 'false';
  });

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast.success('Logout realizado!');
    navigate('/login');
  };

  const toggleAirbnb = (checked: boolean) => {
    setIsAirbnbConnected(checked);
    localStorage.setItem('airbnb_alerts_enabled', String(checked));
    
    if (checked) {
      toast.success('Alertas do Airbnb ativados');
    } else {
      toast.info('Alertas do Airbnb pausados');
    }
  };

  const testAlert = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAirbnbConnected) {
      toast.error('Habilite a conexão primeiro!');
      return;
    }
    toast.warning({ 
      title: 'Airbnb Alert (Teste)', 
      description: 'Hóspede Sarah Connor chega em 2h na Casa Praia Miami.' 
    });
  };

  const menuItems = [
    { icon: User, label: 'Perfil', action: () => {} },
    { icon: Bell, label: 'Notificações', action: () => {} },
    { icon: Moon, label: 'Modo Escuro', action: () => {}, toggle: true },
    { icon: Globe, label: 'Idioma', value: 'Português', action: () => {} },
    { icon: Shield, label: 'Segurança', action: () => {} },
    { icon: HelpCircle, label: 'Ajuda', action: () => {} },
  ];

  return (
    <MobileLayout title="Configurações">
      <div className="space-y-8 pt-4 animate-fade-in-up">
        {/* Profile Card */}
        <Card className="glass-panel border-0 overflow-hidden rounded-3xl shadow-lg shadow-sky-100/50">
          <CardContent className="p-8">
            <div className="flex items-center gap-6">
              <Avatar className="h-20 w-20 border-4 border-white shadow-md">
                <AvatarImage src="" />
                <AvatarFallback className="bg-gradient-to-br from-sky-500 to-blue-600 text-white text-2xl font-bold">
                  MS
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1.5">
                <h2 className="font-bold text-slate-800 text-2xl">Marcio Silva</h2>
                <p className="text-sm font-medium text-slate-500">marcio@email.com</p>
                <div className="flex items-center gap-1.5 mt-2 bg-amber-50 w-fit px-3 py-1.5 rounded-xl border border-amber-100">
                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  <span className="text-xs text-amber-700 font-bold">4.9 (128 reviews)</span>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-10 w-10 rounded-full hover:bg-slate-100">
                <ChevronRight className="h-6 w-6 text-slate-400" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pur Connect Section */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider px-2 ml-1">Integrações</h3>
          
          {/* Auto-Pilot Card (New) */}
          <div 
            onClick={() => navigate('/autopilot')}
            className="glass-panel p-1 rounded-2xl cursor-pointer hover:scale-[1.01] transition-transform group"
          >
             <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-violet-600 rounded-xl p-5 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full blur-2xl -mr-8 -mt-8 pointer-events-none" />
                
                <div className="flex items-center justify-between relative z-10">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
                         <Bot className="w-6 h-6 text-white" />
                      </div>
                      <div>
                         <h4 className="font-bold text-lg flex items-center gap-2">
                           Auto-Pilot
                           <span className="bg-white/20 text-[10px] px-2 py-0.5 rounded-md uppercase font-bold tracking-wider">Beta</span>
                         </h4>
                         <p className="text-indigo-100 text-xs font-medium">Automação de agenda & equipe</p>
                      </div>
                   </div>
                   <ChevronRight className="w-5 h-5 text-white/70 group-hover:text-white group-hover:translate-x-1 transition-all" />
                </div>
             </div>
          </div>

          {/* Airbnb Sync */}
          <div className="glass-panel p-6 rounded-2xl space-y-4">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#FF5A5F]/10 border border-[#FF5A5F]/20 flex items-center justify-center">
                    <Link className="h-6 w-6 text-[#FF5A5F]" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-700 text-lg flex items-center gap-2">
                        Airbnb 
                        {isAirbnbConnected && <CheckCircle className="w-4 h-4 text-emerald-500" />}
                    </h4>
                    <p className="text-xs text-slate-500">Sincronização & Alertas</p>
                  </div>
                </div>
                <Switch 
                    checked={isAirbnbConnected}
                    onCheckedChange={toggleAirbnb}
                />
             </div>
             {isAirbnbConnected && (
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-center justify-between">
                    <div className="text-xs text-slate-500">
                      <p>Status: <span className="font-bold text-emerald-600">Ativo</span></p>
                      <p>Última sync: <span className="font-bold text-slate-700">Há 5 min</span></p>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={testAlert}
                      className="h-8 text-xs bg-white hover:bg-slate-50 border-slate-200 text-slate-600 gap-1.5"
                    >
                      <Play className="w-3 h-3" /> Testar
                    </Button>
                </div>
             )}
          </div>
        </div>

        {/* Menu Items */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider px-2 ml-1">Geral</h3>
          <div className="space-y-4">
            {menuItems.map((item, index) => (
              <div
                key={index}
                onClick={item.action}
                className="w-full glass-panel p-6 flex items-center justify-between hover:scale-[1.01] hover:shadow-md transition-all cursor-pointer rounded-2xl"
              >
                <div className="flex items-center gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center">
                    <item.icon className="h-6 w-6 text-sky-600" />
                  </div>
                  <span className="font-bold text-slate-700 text-lg">{item.label}</span>
                </div>
                
                {item.toggle ? (
                  <Switch />
                ) : item.value ? (
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-slate-400">{item.value}</span>
                    <ChevronRight className="h-5 w-5 text-slate-300" />
                  </div>
                ) : (
                  <ChevronRight className="h-5 w-5 text-slate-300" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Logout */}
        <Button 
          variant="destructive" 
          className="w-full h-16 gap-3 shadow-xl shadow-red-500/20 rounded-3xl text-lg font-bold bg-white text-rose-500 hover:bg-rose-50 border border-rose-100 mt-4"
          onClick={handleLogout}
        >
          <LogOut className="h-6 w-6" />
          Sair da Conta
        </Button>

        <p className="text-center text-xs font-medium text-slate-400 pt-8 pb-6">
          Pur v1.0.0 • Build 2024
        </p>
      </div>
    </MobileLayout>
  );
}