import { MobileLayout } from '@/components/layout/MobileLayout';
import { EarningsCard, StatsGrid } from '@/features/earnings/components/LiveWidgets';
import { JobCard, Job } from '@/features/scheduling/components/JobCard';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { ProScoreCard } from '@/components/gamification/ProScoreCard';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Truck, AlertTriangle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useAppStore } from '@/lib/store';

const stats = {
  todayJobs: 5,
  completed: 3,
  pending: 2,
};

const recentJobs: Job[] = [
  { id: 1, property: 'Casa Praia Miami', time: '09:00', status: 'completed' },
  { id: 2, property: 'Apartamento Downtown', time: '14:00', status: 'in-progress' },
  { id: 3, property: 'Villa Orlando', time: '17:00', status: 'pending' },
];

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
};

export default function Dashboard() {
  const navigate = useNavigate();
  const user = useAppStore((state) => state.user);
  
  const today = new Date();
  const weekday = format(today, 'EEEE', { locale: ptBR });
  const dayMonth = format(today, "d 'de' MMM", { locale: ptBR });

  return (
    <MobileLayout showHeader={false} showBack={false}>
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="space-y-8 pt-14 pb-6"
      >
        {/* Header Flutuante */}
        <header className="flex justify-between items-start">
          <div className="space-y-1">
            <motion.p 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-slate-500 text-base font-medium"
            >
              Bom dia,
            </motion.p>
            <motion.h1 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-3xl font-bold text-slate-800 flex items-center gap-2"
            >
              {user?.name.split(' ')[0]} <span className="text-2xl animate-pulse-slow">👋</span>
            </motion.h1>
          </div>
          
          <div className="text-right">
            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider capitalize">
              {weekday}
            </p>
            <p className="text-slate-600 text-lg font-semibold capitalize">
              {dayMonth}
            </p>
          </div>
        </header>

        {/* Pro Score Widget (New) */}
        <motion.div variants={itemVariants}>
          <ProScoreCard 
            compact 
            metrics={{
              overallScore: user?.score || 94,
              consistencyScore: 98,
              qualityRating: 4.9,
              speedEfficiency: 92,
              photoQuality: 88,
              streakDays: 14
            }}
            onClick={() => navigate('/performance')}
          />
        </motion.div>

        {/* Earnings Card */}
        <motion.div variants={itemVariants} className="w-full">
          <EarningsCard />
        </motion.div>

        {/* Pur Partners Banner (New) */}
        <motion.div variants={itemVariants}>
          <div 
            onClick={() => navigate('/partners')}
            className="glass-panel p-1 rounded-3xl cursor-pointer group hover:scale-[1.01] transition-transform"
          >
             <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-[1.25rem] p-5 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/20 rounded-full blur-3xl -mr-10 -mt-10" />
                
                <div className="flex justify-between items-center relative z-10">
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/10 group-hover:bg-white/20 transition-colors">
                         <Truck className="w-6 h-6 text-sky-300" />
                      </div>
                      <div>
                         <h3 className="font-bold text-lg leading-tight">Pur Partners</h3>
                         <p className="text-slate-400 text-xs font-medium">Marketplace B2B</p>
                      </div>
                   </div>
                   <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 rounded-full">
                      <ArrowRight className="w-5 h-5" />
                   </Button>
                </div>

                <div className="mt-4 flex gap-2">
                   <span className="text-[10px] font-bold bg-rose-500/20 text-rose-300 px-2 py-1 rounded-lg border border-rose-500/20 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" /> SOS 24h
                   </span>
                   <span className="text-[10px] font-bold bg-white/10 text-slate-300 px-2 py-1 rounded-lg">
                      Enxoval
                   </span>
                   <span className="text-[10px] font-bold bg-white/10 text-slate-300 px-2 py-1 rounded-lg">
                      Manutenção
                   </span>
                </div>
             </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div variants={itemVariants}>
          <StatsGrid pending={stats.pending} completed={stats.completed} />
        </motion.div>

        {/* Next Jobs Section */}
        <motion.div variants={itemVariants} className="space-y-5">
          <SectionHeader 
            title="Próximos Jobs" 
            action={{ label: "Ver todos", onClick: () => navigate('/jobs') }}
          />

          <div className="space-y-4">
            {recentJobs.map((job) => (
              <motion.div key={job.id} variants={itemVariants}>
                <JobCard 
                  job={job} 
                  onClick={() => navigate(`/jobs/${job.id}`)} 
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </MobileLayout>
  );
}