import React, { useState } from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Clock, 
  BarChart3, 
  Target,
  Download,
  Calendar,
  Zap,
  Briefcase,
  Star
} from 'lucide-react';
import { motion } from 'framer-motion';

// --- Types ---
interface SeasonalityPoint {
  month: string;
  predictedJobs: number;
  suggestedHiring: number;
}

interface OperationalInsights {
  cleanerUtilization: number;
  propertyTurnoverTime: number;
  guestSatisfactionCorrelation: {
    cleaningRating: number;
    overallRating: number;
    correlation: number;
  };
  revenuePerHour: number;
  seasonalityForecast: SeasonalityPoint[];
}

// --- Mock Data ---
const insights: OperationalInsights = {
  cleanerUtilization: 78,
  propertyTurnoverTime: 3.5, // Average hours
  guestSatisfactionCorrelation: {
    cleaningRating: 4.8,
    overallRating: 4.9,
    correlation: 0.87
  },
  revenuePerHour: 145.50,
  seasonalityForecast: [
    { month: 'Fev', predictedJobs: 45, suggestedHiring: 0 },
    { month: 'Mar', predictedJobs: 52, suggestedHiring: 1 },
    { month: 'Abr', predictedJobs: 68, suggestedHiring: 2 },
    { month: 'Mai', predictedJobs: 60, suggestedHiring: 0 },
    { month: 'Jun', predictedJobs: 85, suggestedHiring: 3 },
  ]
};

// --- Sub-components ---

const InsightCard = ({ title, value, subtext, icon: Icon, trend, colorClass }: any) => (
  <motion.div 
    whileHover={{ y: -2 }}
    className="glass-panel p-5 rounded-3xl relative overflow-hidden flex flex-col justify-between h-full"
  >
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-2xl ${colorClass} bg-opacity-20`}>
        <Icon className={`w-6 h-6 ${colorClass.replace('bg-', 'text-').replace('bg-opacity-20', '')}`} />
      </div>
      {trend && (
        <span className={`text-xs font-bold px-2 py-1 rounded-lg ${trend > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
          {trend > 0 ? '+' : ''}{trend}%
        </span>
      )}
    </div>
    <div>
      <h3 className="text-3xl font-bold text-slate-800 tracking-tight">{value}</h3>
      <p className="text-sm font-semibold text-slate-500 mb-1">{title}</p>
      <p className="text-xs text-slate-400">{subtext}</p>
    </div>
  </motion.div>
);

const ForecastChart = ({ data }: { data: SeasonalityPoint[] }) => {
  const maxJobs = Math.max(...data.map(d => d.predictedJobs));
  
  return (
    <div className="w-full h-48 flex items-end justify-between gap-2 pt-8">
      {data.map((item, i) => {
        const height = (item.predictedJobs / maxJobs) * 100;
        return (
          <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
            {/* Tooltip-ish indicator for hiring */}
            {item.suggestedHiring > 0 && (
                <motion.div 
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 + i * 0.1 }}
                    className="mb-1 px-2 py-1 bg-rose-500 text-white text-[10px] font-bold rounded-md shadow-sm whitespace-nowrap"
                >
                    +{item.suggestedHiring} Staff
                </motion.div>
            )}
            
            {/* Bar */}
            <motion.div 
              className="w-full bg-slate-100 rounded-t-xl relative overflow-hidden group-hover:bg-sky-50 transition-colors"
              style={{ height: `${height}%` }}
              initial={{ height: 0 }}
              animate={{ height: `${height}%` }}
              transition={{ duration: 0.8, delay: i * 0.1, ease: "easeOut" }}
            >
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-sky-400 to-blue-500 opacity-80 h-full rounded-t-xl group-hover:opacity-100 transition-opacity" />
            </motion.div>
            
            {/* Label */}
            <span className="text-xs font-bold text-slate-400 group-hover:text-sky-600 transition-colors">{item.month}</span>
          </div>
        );
      })}
    </div>
  );
};

const QualityCorrelation = ({ data }: { data: typeof insights.guestSatisfactionCorrelation }) => {
    return (
        <div className="relative pt-6 pb-2">
            <div className="flex items-center justify-between mb-6">
                <div className="text-center">
                    <p className="text-3xl font-bold text-sky-600">{data.cleaningRating}</p>
                    <p className="text-xs font-bold text-slate-400 uppercase">Limpeza</p>
                </div>
                <div className="h-px flex-1 bg-slate-200 mx-4 relative">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2 text-xs font-bold text-slate-400 whitespace-nowrap rounded-full border border-slate-100">
                        {data.correlation * 100}% Impacto
                    </div>
                </div>
                <div className="text-center">
                    <p className="text-3xl font-bold text-emerald-500">{data.overallRating}</p>
                    <p className="text-xs font-bold text-slate-400 uppercase">Geral Airbnb</p>
                </div>
            </div>
            
            <div className="bg-slate-50 rounded-xl p-3 text-xs text-slate-500 leading-relaxed border border-slate-100">
                <span className="font-bold text-slate-700">Insight de IA:</span> A qualidade da limpeza tem uma correlação de <span className="font-bold text-sky-600">87%</span> com suas avaliações 5 estrelas. Manter o padrão atual garante Superhost.
            </div>
        </div>
    );
};

export default function ManagerDashboard() {
  const [timeRange, setTimeRange] = useState('30d');

  return (
    <MobileLayout 
        title="Manager Console" 
        rightAction={
            <Button variant="ghost" size="icon" className="w-10 h-10 rounded-xl hover:bg-slate-100 text-slate-500">
                <Download className="w-5 h-5" />
            </Button>
        }
        className="max-w-7xl mx-auto w-full"
    >
      <div className="space-y-6 pt-4 pb-8 animate-fade-in-up">
        
        {/* Time Filter Toggle */}
        <div className="flex justify-center">
            <div className="flex bg-white p-1 rounded-2xl border border-slate-100 shadow-sm w-fit">
                {['7d', '30d', '90d', 'Ano'].map((range) => (
                    <button
                        key={range}
                        onClick={() => setTimeRange(range)}
                        className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                            timeRange === range 
                            ? 'bg-slate-800 text-white shadow-md' 
                            : 'text-slate-500 hover:bg-slate-50'
                        }`}
                    >
                        {range}
                    </button>
                ))}
            </div>
        </div>

        {/* Section 1: KPI Cards - Responsive Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <InsightCard 
                title="Receita / Hora"
                value={`R$ ${insights.revenuePerHour.toFixed(0)}`}
                subtext="+12% vs mês anterior"
                icon={Zap}
                trend={12}
                colorClass="bg-amber-100 text-amber-600"
            />
            <InsightCard 
                title="Utilização"
                value={`${insights.cleanerUtilization}%`}
                subtext="Capacidade da equipe"
                icon={Users}
                trend={-5}
                colorClass="bg-sky-100 text-sky-600"
            />
            {/* Extra KPI cards for desktop completeness */}
            <InsightCard 
                title="Avaliação Geral"
                value={insights.guestSatisfactionCorrelation.overallRating}
                subtext="Média 30 dias"
                icon={Star}
                trend={2.1}
                colorClass="bg-violet-100 text-violet-600"
            />
            <InsightCard 
                title="Turnover"
                value={`${insights.propertyTurnoverTime}h`}
                subtext="Tempo médio"
                icon={Clock}
                trend={15}
                colorClass="bg-emerald-100 text-emerald-600"
            />
        </div>

        {/* Desktop Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Column 1 (2/3 width on desktop): Forecast Chart */}
            <div className="lg:col-span-2">
                <Card className="glass-panel border-0 shadow-lg shadow-sky-100/50 rounded-3xl overflow-visible h-full">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-slate-800">
                            <BarChart3 className="w-5 h-5 text-sky-500" />
                            Previsão de Demanda
                        </CardTitle>
                        <p className="text-xs text-slate-500">Projeção de jobs e necessidade de contratação</p>
                    </CardHeader>
                    <CardContent>
                        <ForecastChart data={insights.seasonalityForecast} />
                        <div className="mt-6 flex gap-4 text-xs font-medium text-slate-500 justify-center">
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-sky-500" />
                                Jobs Previstos
                            </div>
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full bg-rose-500" />
                                Sugestão Contratação
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Column 2 (1/3 width on desktop): Details */}
            <div className="space-y-6">
                {/* Section 3: Quality Correlation */}
                <Card className="glass-panel border-0 shadow-sm rounded-3xl">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-slate-800">
                            <Target className="w-5 h-5 text-emerald-500" />
                            Impacto na Qualidade
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <QualityCorrelation data={insights.guestSatisfactionCorrelation} />
                    </CardContent>
                </Card>

                {/* Section 4: Turnover Metrics Detail */}
                <div className="bg-slate-800 rounded-3xl p-6 text-white shadow-xl shadow-slate-300/50 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full blur-3xl -mr-10 -mt-10" />
                    
                    <div className="flex items-center gap-3 mb-6 relative z-10">
                        <div className="p-2 bg-white/10 rounded-xl">
                            <Clock className="w-5 h-5 text-sky-300" />
                        </div>
                        <div>
                            <h3 className="font-bold text-lg">Turnover Detail</h3>
                            <p className="text-xs text-slate-400">Tempo de Prontidão</p>
                        </div>
                    </div>

                    <div className="flex items-end gap-2 mb-2 relative z-10">
                        <span className="text-5xl font-bold tracking-tighter">{insights.propertyTurnoverTime}</span>
                        <span className="text-xl font-medium text-slate-400 mb-1">horas</span>
                    </div>
                    
                    <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden relative z-10">
                        <motion.div 
                            initial={{ width: 0 }}
                            whileInView={{ width: '70%' }}
                            transition={{ duration: 1 }}
                            className="h-full bg-gradient-to-r from-sky-400 to-emerald-400"
                        />
                    </div>
                    <p className="text-xs text-slate-400 mt-2 relative z-10">
                        <span className="text-emerald-400 font-bold">15% mais rápido</span> que a média (4.1h).
                    </p>
                </div>
            </div>
        </div>
      </div>
    </MobileLayout>
  );
}