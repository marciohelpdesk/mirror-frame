import React, { useState, useRef } from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Key, 
  Wifi, 
  Package, 
  Grid, 
  ClipboardList, 
  FileText, 
  Mail, 
  DollarSign, 
  Trash2,
  Pencil,
  MapPin,
  Bed,
  Bath,
  Maximize,
  Check,
  X,
  Camera,
  UploadCloud
} from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/toaster';
import { Label } from '@/components/ui/label';

const initialPropertyData = {
  id: 1,
  name: 'Ap 925',
  address: '3451 Queens St Apt 925',
  image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=800&auto=format&fit=crop',
  stats: {
    beds: 2,
    baths: 2,
    sqft: 1100
  },
  tags: [
    { label: 'Ready', color: 'bg-emerald-100 text-emerald-700' },
    { label: 'Apartment', color: 'bg-sky-100 text-sky-700' },
    { label: 'Airbnb Cleaning', color: 'bg-blue-50 text-blue-600' }
  ],
  details: [
    { 
      id: 'access',
      icon: Key, 
      color: 'bg-emerald-100 text-emerald-600',
      title: 'Access Code', 
      subtitle: 'Door lock or keypad code',
      value: 'No access code set' 
    },
    { 
      id: 'wifi',
      icon: Wifi, 
      color: 'bg-sky-100 text-sky-600',
      title: 'WiFi Password', 
      subtitle: 'Network credentials',
      value: 'No WiFi password set' 
    },
    { 
      id: 'supplies',
      icon: Package, 
      color: 'bg-indigo-100 text-indigo-600',
      title: 'Supplies Location', 
      subtitle: 'Where to find cleaning supplies',
      value: 'No location specified' 
    },
    { 
      id: 'notes',
      icon: FileText, 
      color: 'bg-amber-100 text-amber-600',
      title: 'Cleaning Notes', 
      subtitle: 'Special instructions & reminders',
      value: 'No notes added' 
    },
    { 
      id: 'email',
      icon: Mail, 
      color: 'bg-cyan-100 text-cyan-600',
      title: 'Email do Cliente', 
      subtitle: 'Para envio de relatórios',
      value: 'Nenhum email cadastrado' 
    },
    { 
      id: 'price',
      icon: DollarSign, 
      color: 'bg-emerald-100 text-emerald-600',
      title: 'Base Price', 
      subtitle: 'Standard cleaning rate',
      value: 'No price set' 
    }
  ]
};

interface DetailItem {
  id: string;
  icon: any;
  color: string;
  title: string;
  subtitle: string;
  value: string;
}

export default function PropertyDetail() {
  const navigate = useNavigate();
  const toast = useToast();
  const { id } = useParams();
  
  const [isEditing, setIsEditing] = useState(false);
  const [data, setData] = useState(initialPropertyData);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    // Here you would save to Supabase
    setIsEditing(false);
    toast.success('Alterações salvas com sucesso!');
    if (navigator.vibrate) navigator.vibrate(50);
  };

  const handleCancel = () => {
    setData(initialPropertyData); // Reset changes
    setIsEditing(false);
  };

  const handleDelete = () => {
    toast.success('Propriedade removida');
    navigate('/properties');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setData(prev => ({ ...prev, image: reader.result as string }));
        toast.success('Nova foto selecionada');
      };
      reader.readAsDataURL(file);
    }
  };

  const updateDetail = (index: number, newValue: string) => {
    const newDetails = [...data.details];
    newDetails[index] = { ...newDetails[index], value: newValue };
    setData(prev => ({ ...prev, details: newDetails }));
  };

  return (
    <MobileLayout 
      title={isEditing ? "Editar Propriedade" : "Detalhes"} 
      showBack={true}
      rightAction={
        <div className="flex gap-2">
            {isEditing ? (
                <Button 
                    onClick={handleSave}
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full bg-emerald-100 text-emerald-600 hover:bg-emerald-200 w-10 h-10 transition-all"
                >
                    <Check className="h-5 w-5" />
                </Button>
            ) : (
                <Button 
                    onClick={() => setIsEditing(true)}
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full bg-sky-50 text-sky-600 hover:bg-sky-100 w-10 h-10 transition-all"
                >
                    <Pencil className="h-5 w-5" />
                </Button>
            )}
        </div>
      }
    >
      <div className="space-y-6 pt-4 pb-8">
        
        {/* Cancel Bar (Visible only when editing) */}
        <AnimatePresence>
            {isEditing && (
                <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                >
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-center justify-between">
                        <span className="text-sm font-medium text-amber-800 flex items-center gap-2">
                            <Pencil className="h-4 w-4" />
                            Modo de Edição Ativo
                        </span>
                        <button onClick={handleCancel} className="text-xs font-bold text-amber-700 underline">
                            Cancelar
                        </button>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>

        {/* Hero Section */}
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-4 transition-all">
          <div className="relative h-64 rounded-2xl overflow-hidden group">
            <img 
              src={data.image} 
              alt={data.name} 
              className={`w-full h-full object-cover transition-all ${isEditing ? 'blur-[2px] scale-105' : ''}`}
            />
            
            {/* Gradient Overlay */}
            <div className={`absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent transition-opacity ${isEditing ? 'opacity-90' : 'opacity-100'}`} />
            
            {/* View Mode Content */}
            {!isEditing && (
                <div className="absolute bottom-5 left-5 right-5 text-white">
                    <h1 className="text-4xl font-bold mb-2 tracking-tight">{data.name}</h1>
                    <div className="flex items-center gap-2 text-white/90 font-medium">
                        <MapPin className="h-4 w-4 text-white" />
                        {data.address}
                    </div>
                </div>
            )}

            {/* Edit Mode Overlay */}
            {isEditing && (
                <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer bg-black/20"
                >
                    <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/40 mb-2">
                        <Camera className="h-8 w-8 text-white" />
                    </div>
                    <span className="text-white font-bold text-sm bg-black/40 px-3 py-1 rounded-full">Alterar Foto</span>
                    <input 
                        ref={fileInputRef} 
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleImageUpload}
                    />
                </div>
            )}
          </div>

          {/* Fields Section */}
          <div className="px-1 space-y-4">
            
            {/* Edit Title/Address Inputs */}
            {isEditing && (
                <div className="space-y-3 animate-fade-in-up">
                    <div className="space-y-1">
                        <Label className="text-xs text-slate-400 font-bold uppercase ml-1">Nome da Propriedade</Label>
                        <Input 
                            value={data.name} 
                            onChange={(e) => setData({...data, name: e.target.value})}
                            className="text-lg font-bold bg-slate-50 border-slate-200"
                        />
                    </div>
                    <div className="space-y-1">
                        <Label className="text-xs text-slate-400 font-bold uppercase ml-1">Endereço</Label>
                        <Input 
                            value={data.address} 
                            onChange={(e) => setData({...data, address: e.target.value})}
                            className="bg-slate-50 border-slate-200"
                        />
                    </div>
                </div>
            )}

            {/* Stats Row */}
            <div className={`flex items-center justify-between bg-slate-50 p-4 rounded-2xl border border-slate-100 ${isEditing ? 'gap-3' : ''}`}>
                <div className="flex flex-col items-center gap-1 flex-1 border-r border-slate-200/60 last:border-0">
                    <Bed className="h-5 w-5 text-sky-500" />
                    {isEditing ? (
                        <div className="flex items-center gap-1">
                            <Input 
                                type="number" 
                                value={data.stats.beds} 
                                onChange={e => setData({...data, stats: {...data.stats, beds: parseInt(e.target.value)}})}
                                className="h-8 w-12 text-center p-1 bg-white" 
                            />
                        </div>
                    ) : (
                        <span className="text-sm font-bold text-slate-700">{data.stats.beds} Quartos</span>
                    )}
                </div>
                <div className="flex flex-col items-center gap-1 flex-1 border-r border-slate-200/60 last:border-0">
                    <Bath className="h-5 w-5 text-sky-500" />
                    {isEditing ? (
                        <div className="flex items-center gap-1">
                            <Input 
                                type="number" 
                                value={data.stats.baths} 
                                onChange={e => setData({...data, stats: {...data.stats, baths: parseInt(e.target.value)}})}
                                className="h-8 w-12 text-center p-1 bg-white" 
                            />
                        </div>
                    ) : (
                        <span className="text-sm font-bold text-slate-700">{data.stats.baths} Banheiros</span>
                    )}
                </div>
                <div className="flex flex-col items-center gap-1 flex-1">
                    <Maximize className="h-5 w-5 text-sky-500" />
                    {isEditing ? (
                        <div className="flex items-center gap-1">
                            <Input 
                                type="number" 
                                value={data.stats.sqft} 
                                onChange={e => setData({...data, stats: {...data.stats, sqft: parseInt(e.target.value)}})}
                                className="h-8 w-16 text-center p-1 bg-white" 
                            />
                        </div>
                    ) : (
                        <span className="text-sm font-bold text-slate-700">{data.stats.sqft} sq ft</span>
                    )}
                </div>
            </div>
          </div>
        </div>

        {/* Detail Cards */}
        <div className="space-y-3">
          {data.details.map((item, index) => (
            <motion.div 
                key={item.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`bg-white rounded-3xl p-5 flex items-start gap-4 shadow-sm border transition-all ${isEditing ? 'border-sky-200 ring-4 ring-sky-50/50' : 'border-slate-100'}`}
            >
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${item.color}`}>
                    <item.icon className="h-6 w-6" />
                </div>
                <div className="flex-1 space-y-1 w-full">
                    <h3 className="font-bold text-slate-800 text-base">{item.title}</h3>
                    <p className="text-xs text-slate-400 font-medium">{item.subtitle}</p>
                    
                    {isEditing ? (
                        <Input 
                            value={item.value} 
                            onChange={(e) => updateDetail(index, e.target.value)}
                            className="mt-2 h-9 bg-slate-50 border-slate-200 text-sm focus:bg-white transition-all"
                            placeholder={`Digite ${item.title}...`}
                        />
                    ) : (
                        <p className={`text-sm mt-1 font-medium ${item.value.includes('No') || item.value.includes('Nenhum') ? 'text-slate-400 italic' : 'text-slate-600'}`}>
                            {item.value}
                        </p>
                    )}
                </div>
            </motion.div>
          ))}
        </div>

        {/* Delete Button (Only in edit mode or always bottom?) */}
        <div className="pt-4 px-2">
          {isEditing ? (
             <Button 
                variant="destructive" 
                onClick={handleDelete}
                className="w-full h-14 bg-rose-50 hover:bg-rose-100 border-rose-100 shadow-sm text-rose-600 font-bold gap-2 rounded-2xl"
             >
                <Trash2 className="h-5 w-5" />
                REMOVER PROPRIEDADE
             </Button>
          ) : (
             <p className="text-center text-xs text-slate-300 font-medium uppercase tracking-widest pt-4">
                ID da Propriedade: #{id}
             </p>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}