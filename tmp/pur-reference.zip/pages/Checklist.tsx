import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/components/ui/toaster';
import { 
  Camera, 
  Check, 
  ChevronLeft, 
  Clock, 
  Image as ImageIcon, 
  AlertCircle,
  MoreHorizontal,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Minimize2,
  Mic,
  Music,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ArrowRight,
  Zap
} from 'lucide-react';
import React, { useState, useRef, useMemo, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

// --- Types ---
interface ChecklistItemType {
  id: number;
  category: string;
  text: string;
  photos: string[];
  completed: boolean;
}

type SoundscapeType = 'silent' | 'lofi' | 'nature';

// --- Mock Data ---
const initialItems: ChecklistItemType[] = [
  { id: 1, category: 'Entrada', text: 'Verificar fechadura inteligente', photos: [], completed: false },
  { id: 2, category: 'Entrada', text: 'Limpar tapete de entrada', photos: [], completed: false },
  { id: 3, category: 'Sala de Estar', text: 'Aspirar sofá e poltronas', photos: [], completed: false },
  { id: 4, category: 'Sala de Estar', text: 'Limpar TV e eletrônicos', photos: [], completed: false },
  { id: 5, category: 'Sala de Estar', text: 'Organizar almofadas', photos: [], completed: false },
  { id: 6, category: 'Cozinha', text: 'Limpar interior da geladeira', photos: [], completed: false },
  { id: 7, category: 'Cozinha', text: 'Verificar louça na máquina', photos: [], completed: false },
  { id: 8, category: 'Cozinha', text: 'Limpar bancadas e pia', photos: [], completed: false },
  { id: 9, category: 'Banheiro Principal', text: 'Higienizar vaso sanitário', photos: [], completed: false },
  { id: 10, category: 'Banheiro Principal', text: 'Limpar box e vidros', photos: [], completed: false },
  { id: 11, category: 'Banheiro Principal', text: 'Repor papel higiênico', photos: [], completed: false },
];

// --- COMPONENTS ---

const SoapBubbles = () => {
  const bubbles = Array.from({ length: 15 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    size: Math.random() * 30 + 10,
    delay: Math.random() * 2,
    duration: Math.random() * 3 + 2,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
      {bubbles.map((bubble) => (
        <motion.div
          key={bubble.id}
          className="absolute rounded-full border border-white/40 shadow-sm backdrop-blur-[1px]"
          style={{
            left: bubble.left,
            width: bubble.size,
            height: bubble.size,
            background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.8), rgba(255,255,255,0.1) 60%, rgba(255,255,255,0.05) 100%)',
          }}
          initial={{ y: -100, x: 0, opacity: 0 }}
          animate={{ y: window.innerHeight + 100, opacity: [0, 1, 1, 0] }}
          transition={{ duration: bubble.duration, delay: bubble.delay, repeat: Infinity, ease: "linear" }}
        />
      ))}
    </div>
  );
};

const LiquidGauge = ({ value }: { value: number }) => {
  return (
    <div className="relative w-14 h-14 rounded-full border-2 border-sky-100 bg-white overflow-hidden shadow-inner shadow-slate-200">
      <div className="absolute inset-0 bg-slate-50 opacity-50"></div>
      <motion.div
        className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-sky-500 to-sky-400"
        initial={{ height: '0%' }}
        animate={{ height: `${value}%` }}
        transition={{ type: "spring", stiffness: 50, damping: 20 }}
      >
        <motion.div
          className="absolute -top-[120%] -left-[50%] w-[200%] h-[200%] bg-white/30 rounded-[40%]"
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />
      </motion.div>
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <span className={cn("text-xs font-bold transition-colors duration-300 drop-shadow-sm", value > 55 ? "text-white" : "text-slate-600")}>
          {Math.round(value)}%
        </span>
      </div>
    </div>
  );
};

// --- MAIN PAGE COMPONENT ---

export default function Checklist() {
  const navigate = useNavigate();
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // State
  const [items, setItems] = useState<ChecklistItemType[]>(initialItems);
  const [activeItemId, setActiveItemId] = useState<number | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  
  // Timer
  const [seconds, setSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);

  // Focus Mode State
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [currentFocusIndex, setCurrentFocusIndex] = useState(0);
  const [soundscape, setSoundscape] = useState<SoundscapeType>('silent');
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // --- Effects ---

  useEffect(() => {
    let interval: any;
    if (isTimerRunning) {
      interval = setInterval(() => setSeconds(s => s + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  // Grouping
  const groupedItems = useMemo(() => {
    const groups: Record<string, ChecklistItemType[]> = {};
    items.forEach(item => {
      if (!groups[item.category]) groups[item.category] = [];
      groups[item.category].push(item);
    });
    return groups;
  }, [items]);

  useEffect(() => {
    const initial: Record<string, boolean> = {};
    Object.keys(groupedItems).forEach(cat => initial[cat] = true);
    setExpandedCategories(initial);
  }, []);

  // --- Voice Recognition Logic (Simulated for Web Compatibility) ---
  useEffect(() => {
    if (!voiceEnabled || !isFocusMode) return;

    // Check if browser supports SpeechRecognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      toast.error('Seu navegador não suporta comandos de voz.');
      setVoiceEnabled(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'pt-BR';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const lastResult = event.results[event.results.length - 1];
      const command = lastResult[0].transcript.trim().toLowerCase();
      
      console.log('Voice Command:', command);
      
      if (command.includes('próximo') || command.includes('next')) {
        handleFocusNext();
        toast.info('Comando de voz: Próximo');
      } else if (command.includes('foto') || command.includes('câmera')) {
        fileInputRef.current?.click();
        toast.info('Comando de voz: Câmera');
      } else if (command.includes('ok') || command.includes('feito') || command.includes('check')) {
        const currentItem = items[currentFocusIndex];
        if (!currentItem.completed) handleToggleItem(currentItem.id);
        toast.success('Comando de voz: Item marcado');
      }
    };

    try {
      recognition.start();
    } catch (e) {
      console.error(e);
    }

    return () => {
      recognition.stop();
    };
  }, [voiceEnabled, isFocusMode, currentFocusIndex, items]);


  // --- Logic Helpers ---

  const completedCount = items.filter(i => i.completed).length;
  const progress = (completedCount / items.length) * 100;
  const isComplete = progress === 100;

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({ ...prev, [category]: !prev[category] }));
  };

  const handleToggleItem = (id: number) => {
    if (navigator.vibrate) navigator.vibrate(15);
    
    setItems(prev => {
        const newItems = prev.map(item => item.id === id ? { ...item, completed: !item.completed } : item);
        
        // Progress Haptics Check
        const newCompleted = newItems.filter(i => i.completed).length;
        const newProgress = (newCompleted / newItems.length) * 100;
        
        if (newProgress % 25 === 0 && newProgress > 0 && navigator.vibrate) {
            // Strong vibration on milestones
            navigator.vibrate([50, 50, 50]); 
            toast.success(`Marco atingido: ${newProgress}%`);
        }
        
        return newItems;
    });

    if (isFocusMode && !items.find(i => i.id === id)?.completed) {
        // Auto advance if checking off in focus mode (optional, mostly user prefers manual next)
        // setTimeout(handleFocusNext, 500); 
    }
  };

  const handlePhotoCapture = (itemId: number, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setActiveItemId(itemId);
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetId = isFocusMode ? items[currentFocusIndex].id : activeItemId;

    if (file && targetId) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setItems(prev => prev.map(item => 
          item.id === targetId 
            ? { ...item, photos: [...item.photos, reader.result as string], completed: true }
            : item
        ));
        toast.success('Foto salva e item completado!');
        setActiveItemId(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFocusNext = () => {
    if (currentFocusIndex < items.length - 1) {
        setCurrentFocusIndex(prev => prev + 1);
    } else {
        setIsFocusMode(false);
        toast.success('Focus Flow finalizado!');
    }
  };

  const handleFocusPrev = () => {
    if (currentFocusIndex > 0) {
        setCurrentFocusIndex(prev => prev - 1);
    }
  };

  const handleFinish = () => {
    if (!isComplete) {
      toast.error('Complete todos os itens antes de finalizar.');
      return;
    }
    toast.success('Inspeção finalizada com sucesso!');
    navigate('/jobs');
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // --- Background Styles for Focus Mode ---
  const getFocusBackground = () => {
    switch (soundscape) {
        case 'nature': return 'bg-gradient-to-b from-emerald-900 to-teal-900';
        case 'lofi': return 'bg-gradient-to-b from-indigo-900 to-purple-900';
        default: return 'bg-gradient-to-b from-slate-900 to-slate-800';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col relative overflow-hidden">
      
      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* --- FOCUS MODE OVERLAY --- */}
      <AnimatePresence>
        {isFocusMode && (
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className={cn(
                    "fixed inset-0 z-[100] flex flex-col text-white transition-colors duration-1000",
                    getFocusBackground()
                )}
            >
                {/* 1. Focus Header */}
                <div className="flex items-center justify-between p-6">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => setIsFocusMode(false)}
                        className="rounded-full bg-white/10 hover:bg-white/20 text-white"
                    >
                        <Minimize2 className="w-6 h-6" />
                    </Button>
                    
                    <div className="flex items-center gap-3 bg-white/10 px-4 py-2 rounded-full backdrop-blur-md">
                        <Clock className="w-4 h-4 text-white/70" />
                        <span className="font-mono font-bold">{formatTime(seconds)}</span>
                    </div>

                    <div className="flex gap-2">
                        <Button
                             variant="ghost" 
                             size="icon" 
                             onClick={() => setVoiceEnabled(!voiceEnabled)}
                             className={cn("rounded-full transition-all", voiceEnabled ? "bg-red-500/80 text-white animate-pulse" : "bg-white/10 text-white/50")}
                        >
                            <Mic className="w-5 h-5" />
                        </Button>
                        <Button
                             variant="ghost" 
                             size="icon" 
                             onClick={() => {
                                 const modes: SoundscapeType[] = ['silent', 'lofi', 'nature'];
                                 const nextIdx = (modes.indexOf(soundscape) + 1) % modes.length;
                                 setSoundscape(modes[nextIdx]);
                                 setIsPlaying(true);
                             }}
                             className="rounded-full bg-white/10 hover:bg-white/20 text-white"
                        >
                            {soundscape === 'silent' ? <VolumeX className="w-5 h-5" /> : <Music className="w-5 h-5" />}
                        </Button>
                    </div>
                </div>

                {/* 2. Audio Visualizer (Fake) */}
                <div className="h-12 flex items-center justify-center gap-1.5 opacity-50">
                    {soundscape !== 'silent' && Array.from({length: 12}).map((_, i) => (
                        <motion.div 
                            key={i}
                            className="w-1.5 bg-white rounded-full"
                            animate={{ 
                                height: isPlaying ? [10, Math.random() * 30 + 10, 10] : 8 
                            }}
                            transition={{ 
                                duration: 0.5, 
                                repeat: Infinity, 
                                delay: i * 0.1 
                            }}
                        />
                    ))}
                    {soundscape === 'silent' && <span className="text-xs font-medium tracking-widest uppercase opacity-50">Modo Silencioso</span>}
                </div>

                {/* 3. Main Content Card */}
                <div className="flex-1 flex flex-col justify-center px-6 pb-12 relative">
                    {/* Progress Indicator */}
                    <div className="absolute top-4 left-6 right-6 flex gap-1">
                        {items.map((_, idx) => (
                            <div 
                                key={idx} 
                                className={cn(
                                    "h-1 flex-1 rounded-full transition-colors duration-300",
                                    idx < currentFocusIndex ? "bg-white/80" : 
                                    idx === currentFocusIndex ? "bg-white" : "bg-white/20"
                                )}
                            />
                        ))}
                    </div>

                    <AnimatePresence mode='wait'>
                        <motion.div
                            key={currentFocusIndex}
                            initial={{ x: 50, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            exit={{ x: -50, opacity: 0 }}
                            className="space-y-6 text-center"
                        >
                            <span className="inline-block px-3 py-1 rounded-lg bg-white/20 text-sm font-bold uppercase tracking-wider backdrop-blur-sm">
                                {items[currentFocusIndex].category}
                            </span>
                            
                            <h2 className="text-3xl font-bold leading-tight drop-shadow-md">
                                {items[currentFocusIndex].text}
                            </h2>

                            {/* Photo Gallery in Focus Mode */}
                            {items[currentFocusIndex].photos.length > 0 && (
                                <div className="flex justify-center gap-3 py-4">
                                    {items[currentFocusIndex].photos.map((p, i) => (
                                        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} key={i} className="w-20 h-20 rounded-xl border-2 border-white/50 overflow-hidden shadow-lg">
                                            <img src={p} className="w-full h-full object-cover" />
                                        </motion.div>
                                    ))}
                                </div>
                            )}

                        </motion.div>
                    </AnimatePresence>
                </div>

                {/* 4. Large Action Controls */}
                <div className="bg-white/10 backdrop-blur-xl border-t border-white/10 p-6 pb-safe">
                    <div className="flex items-center gap-4 max-w-md mx-auto">
                        <Button
                             onClick={() => handlePhotoCapture(items[currentFocusIndex].id)}
                             className="h-16 w-16 rounded-2xl bg-white/20 hover:bg-white/30 border border-white/20 flex-shrink-0"
                        >
                            <Camera className="w-7 h-7" />
                        </Button>
                        
                        <Button
                            onClick={() => {
                                handleToggleItem(items[currentFocusIndex].id);
                                handleFocusNext();
                            }}
                            className={cn(
                                "flex-1 h-16 rounded-2xl text-lg font-bold shadow-xl transition-all",
                                items[currentFocusIndex].completed 
                                    ? "bg-emerald-500 hover:bg-emerald-600 text-white"
                                    : "bg-white text-slate-900 hover:bg-slate-100"
                            )}
                        >
                            {items[currentFocusIndex].completed ? (
                                <span className="flex items-center gap-2">
                                    Concluído <Check className="w-6 h-6" />
                                </span>
                            ) : (
                                <span className="flex items-center gap-2">
                                    Próximo <ArrowRight className="w-6 h-6" />
                                </span>
                            )}
                        </Button>
                    </div>
                </div>

                {/* 5. Soundscape Audio Element (Hidden) */}
                {/* Simulated: In a real app, this would be an <audio> tag with a src based on soundscape state */}
            </motion.div>
        )}
      </AnimatePresence>


      {/* --- NORMAL MODE UI --- */}
      
      {/* Show Soap Bubbles when complete */}
      <AnimatePresence>
        {isComplete && !isFocusMode && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <SoapBubbles />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full hover:bg-slate-100 -ml-2">
              <ChevronLeft className="h-6 w-6 text-slate-700" />
            </Button>
            <div>
              <h1 className="text-lg font-bold text-slate-800 leading-tight">Checklist</h1>
              <p className="text-xs text-slate-500 font-medium">Casa Praia Miami</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
             <Button 
                onClick={() => setIsFocusMode(true)}
                className="bg-slate-900 text-white hover:bg-slate-800 h-9 px-3 rounded-lg text-xs font-bold gap-2 shadow-md shadow-slate-300"
             >
                <Zap className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                Focus Flow
             </Button>
          </div>
        </div>
      </div>

      {/* List Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 pb-32">
        {Object.entries(groupedItems).map(([category, categoryItems]) => {
          const isExpanded = expandedCategories[category];
          const itemsList = categoryItems as ChecklistItemType[];
          const completedInCategory = itemsList.filter(i => i.completed).length;
          const totalInCategory = itemsList.length;
          const isCategoryComplete = completedInCategory === totalInCategory;

          return (
            <div key={category} className="space-y-2">
              <button 
                onClick={() => toggleCategory(category)}
                className="w-full flex items-center justify-between py-2 px-1 group"
              >
                <div className="flex items-center gap-2">
                  <h3 className={cn("text-sm font-bold uppercase tracking-wider transition-colors", isCategoryComplete ? "text-emerald-600" : "text-slate-500 group-hover:text-slate-700")}>
                    {category}
                  </h3>
                  {isCategoryComplete && <Check className="h-4 w-4 text-emerald-500" />}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-slate-400">{completedInCategory}/{totalInCategory}</span>
                  {isExpanded ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
                </div>
              </button>

              <AnimatePresence initial={false}>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-white rounded-xl shadow-sm border border-slate-200 divide-y divide-slate-100 overflow-hidden">
                      {itemsList.map((item) => {
                        const isChecked = item.completed;
                        const hasPhotos = item.photos.length > 0;

                        return (
                          <div 
                            key={item.id} 
                            onClick={() => handleToggleItem(item.id)}
                            className={cn("relative transition-colors duration-200 cursor-pointer", isChecked ? "bg-slate-50/50" : "bg-white hover:bg-slate-50")}
                          >
                            <div className="flex items-start gap-4 p-4">
                              <div className={cn("flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all mt-0.5", isChecked ? "bg-emerald-500 border-emerald-500" : "border-slate-300 bg-white")}>
                                {isChecked && <Check className="h-3.5 w-3.5 text-white stroke-[3px]" />}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className={cn("text-sm font-semibold transition-colors leading-relaxed", isChecked ? "text-slate-500 line-through decoration-slate-300" : "text-slate-800")}>
                                  {item.text}
                                </p>
                                {hasPhotos && (
                                  <div className="flex gap-2 mt-3 overflow-x-auto hide-scrollbar">
                                    {item.photos.map((photo, i) => (
                                      <div key={i} className="relative w-12 h-12 rounded-lg overflow-hidden border border-slate-200 flex-shrink-0">
                                        <img src={photo} className="w-full h-full object-cover" alt="evidence" />
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                              <div className="flex flex-col gap-2">
                                <button
                                  onClick={(e) => handlePhotoCapture(item.id, e)}
                                  className={cn("p-2 rounded-lg transition-colors border", hasPhotos ? "bg-sky-50 text-sky-600 border-sky-100" : "bg-white text-slate-400 border-slate-100 hover:border-slate-300")}
                                >
                                  <Camera className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* Footer Actions */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-200 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-50 pb-safe">
        <div className="flex items-center gap-4 max-w-lg mx-auto">
          <div className="flex items-center gap-3 flex-1">
             <LiquidGauge value={progress} />
             <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Progresso</span>
                <span className="text-sm font-semibold text-slate-700">{progress === 100 ? 'Tudo pronto!' : 'Em andamento'}</span>
             </div>
          </div>
          <Button 
            className={cn("h-14 px-8 rounded-2xl font-bold shadow-lg transition-all text-base", isComplete ? "bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-200 scale-105" : "bg-slate-800 text-slate-400 cursor-not-allowed")}
            onClick={handleFinish}
            disabled={!isComplete}
          >
            {isComplete ? 'Finalizar' : 'Pendente'}
          </Button>
        </div>
      </div>
    </div>
  );
}