import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  MapPin, 
  Clock, 
  Calendar, 
  MessageSquare, 
  Camera,
  CheckCircle2,
  ArrowRight,
  Share2,
  Phone,
  Navigation,
  Key,
  Wifi,
  ChevronRight,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef, useState } from 'react';
import { useToast } from '@/components/ui/toaster';
import { cn } from '@/lib/utils';

const jobData = {
  id: 1,
  property: 'Casa Praia Miami',
  address: '123 Ocean Drive, Miami Beach, FL',
  fullAddress: '123 Ocean Drive, Miami Beach, FL 33139',
  time: '09:00 - 12:00',
  duration: '3h estimadas',
  date: '02 Fev, 2026', // Shortened date
  weekday: 'Segunda-feira',
  type: 'Checkout',
  status: 'scheduled',
  guest: 'John Smith',
  guestCount: 4,
  phone: '+1 (305) 555-0123',
  accessCode: '4829#',
  wifiPass: 'OceanView2024',
  notes: 'Hóspede tem alergia a perfume. Usar produtos neutros nos quartos.',
  image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=800&auto=format&fit=crop',
  checklist: {
    total: 12,
    completed: 0,
    items: [
      { id: 1, text: 'Trocar lençóis (King Size)', done: false },
      { id: 2, text: 'Higienizar Banheiro Master', done: false },
      { id: 3, text: 'Verificar Louça na Máquina', done: false },
    ]
  }
};

export default function JobDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const containerRef = useRef<HTMLDivElement>(null);
  const [showAccess, setShowAccess] = useState(false);
  
  // Create a scroll effect for parallax
  const { scrollY } = useScroll({ container: containerRef });
  const imageY = useTransform(scrollY, [0, 300], [0, 150]);
  const headerOpacity = useTransform(scrollY, [0, 200], [0, 1]);

  const progress = (jobData.checklist.completed / jobData.checklist.total) * 100;

  const handleOpenMap = () => {
    toast.info('Abrindo GPS...');
    // window.open(`https://maps.google.com/?q=${jobData.fullAddress}`);
  };

  return (
    <div className="h-screen flex flex-col bg-slate-50 relative">
      
      {/* Sticky Top Bar (Fades in) */}
      <motion.div 
        style={{ opacity: headerOpacity }}
        className="absolute top-0 left-0 right-0 h-24 bg-white/80 backdrop-blur-md z-40 border-b border-slate-200"
      />

      {/* Navigation Header */}
      <div className="absolute top-0 left-0 right-0 z-50 px-6 pt-safe-top mt-2 flex justify-between items-center">
        <button 
          onClick={() => navigate(-1)} 
          className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center hover:bg-white/40 transition-colors shadow-sm"
        >
          <ArrowRight className="h-5 w-5 text-white rotate-180 drop-shadow-md" />
        </button>
        <motion.span 
            style={{ opacity: headerOpacity }}
            className="text-slate-800 font-bold text-lg"
        >
            Detalhes do Job
        </motion.span>
        <button 
          onClick={() => toast.success('Link copiado!')}
          className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center hover:bg-white/40 transition-colors shadow-sm"
        >
          <Share2 className="h-5 w-5 text-white drop-shadow-md" />
        </button>
      </div>

      {/* Hero Image with Parallax */}
      <div className="absolute top-0 left-0 right-0 h-[45vh] overflow-hidden z-0">
        <motion.img 
          style={{ y: imageY }}
          src={jobData.image} 
          className="w-full h-full object-cover"
          alt="Property"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-slate-50" />
      </div>

      {/* Main Content - Scrollable */}
      <div 
        ref={containerRef}
        className="flex-1 overflow-y-auto overflow-x-hidden pt-[32vh] pb-32 px-4 relative z-10 perspective-1000" 
      >
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 25 }}
          className="space-y-6"
        >
          
          {/* 1. Main Job Ticket Card */}
          <div className="bg-white rounded-[2rem] shadow-xl shadow-slate-200/50 p-6 relative overflow-hidden">
             {/* Decorative Top Line */}
             <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-sky-400 to-blue-500" />
             
             <div className="flex justify-between items-start mb-4">
                <div>
                    <Badge className="mb-2 bg-sky-100 text-sky-700 hover:bg-sky-200 border-0 px-3 py-1 text-xs font-bold rounded-lg uppercase tracking-wide">
                        {jobData.type}
                    </Badge>
                    <h1 className="text-2xl font-bold text-slate-800 leading-tight pr-4">
                        {jobData.property}
                    </h1>
                </div>
                <div className="text-right">
                    <div className="bg-slate-100 rounded-xl px-3 py-2 flex flex-col items-center min-w-[70px]">
                        <span className="text-xs font-bold text-slate-400 uppercase">{jobData.date.split(' ')[0]}</span>
                        <span className="text-xl font-bold text-slate-800">{jobData.date.split(' ')[1].replace(',','')}</span>
                    </div>
                </div>
             </div>

             <div className="flex items-center gap-2 text-slate-500 text-sm font-medium mb-6">
                <MapPin className="h-4 w-4 text-rose-500 shrink-0" />
                <span className="truncate">{jobData.fullAddress}</span>
             </div>

             {/* Time Block */}
             <div className="flex items-center justify-between bg-slate-50 rounded-2xl p-4 border border-slate-100">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                        <Clock className="h-5 w-5" />
                    </div>
                    <div>
                        <p className="text-sm font-bold text-slate-700">Horário</p>
                        <p className="text-xs text-slate-500 font-medium">{jobData.weekday}</p>
                    </div>
                </div>
                <div className="text-right">
                    <p className="text-lg font-bold text-slate-800">{jobData.time}</p>
                    <p className="text-xs text-emerald-600 font-bold">{jobData.duration}</p>
                </div>
             </div>
          </div>

          {/* 2. Quick Actions Bar */}
          <div className="grid grid-cols-4 gap-3">
            <button onClick={handleOpenMap} className="flex flex-col items-center gap-2 group">
                <div className="w-14 h-14 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center text-sky-500 group-active:scale-95 transition-all">
                    <Navigation className="h-6 w-6" />
                </div>
                <span className="text-[10px] font-bold text-slate-500">Mapa</span>
            </button>
            <button onClick={() => toast.info('Ligando...')} className="flex flex-col items-center gap-2 group">
                <div className="w-14 h-14 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center text-emerald-500 group-active:scale-95 transition-all">
                    <Phone className="h-6 w-6" />
                </div>
                <span className="text-[10px] font-bold text-slate-500">Ligar</span>
            </button>
            <button className="flex flex-col items-center gap-2 group">
                <div className="w-14 h-14 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center text-indigo-500 group-active:scale-95 transition-all">
                    <MessageSquare className="h-6 w-6" />
                </div>
                <span className="text-[10px] font-bold text-slate-500">Chat</span>
            </button>
            <button onClick={() => setShowAccess(!showAccess)} className="flex flex-col items-center gap-2 group">
                <div className={cn(
                    "w-14 h-14 rounded-2xl shadow-sm border flex items-center justify-center group-active:scale-95 transition-all",
                    showAccess ? "bg-amber-500 text-white border-amber-500" : "bg-white border-slate-100 text-amber-500"
                )}>
                    <Key className="h-6 w-6" />
                </div>
                <span className="text-[10px] font-bold text-slate-500">Acesso</span>
            </button>
          </div>

          {/* 3. Access & Wifi (Conditional Reveal) */}
          {showAccess && (
            <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-amber-50 border border-amber-100 rounded-2xl p-5 space-y-4"
            >
                <div className="flex items-center justify-between border-b border-amber-100 pb-3">
                    <div className="flex items-center gap-3">
                        <Key className="h-5 w-5 text-amber-600" />
                        <div>
                            <p className="text-xs text-amber-800 font-bold uppercase">Código Porta</p>
                            <p className="text-xl font-mono font-bold text-amber-900 tracking-widest">{jobData.accessCode}</p>
                        </div>
                    </div>
                    <Button variant="ghost" size="sm" className="h-8 text-amber-700 hover:bg-amber-100">Copiar</Button>
                </div>
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Wifi className="h-5 w-5 text-amber-600" />
                        <div>
                            <p className="text-xs text-amber-800 font-bold uppercase">Senha Wi-Fi</p>
                            <p className="text-base font-bold text-amber-900">{jobData.wifiPass}</p>
                        </div>
                    </div>
                    <Button variant="ghost" size="sm" className="h-8 text-amber-700 hover:bg-amber-100">Copiar</Button>
                </div>
            </motion.div>
          )}

          {/* 4. Guest & Notes */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
             <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-sky-500" />
                    Info do Hóspede
                </h3>
             </div>
             
             <div className="flex items-center gap-4 py-2">
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-500 text-lg">
                    {jobData.guest.charAt(0)}
                </div>
                <div>
                    <p className="font-bold text-slate-800 text-lg">{jobData.guest}</p>
                    <p className="text-slate-400 text-sm font-medium">{jobData.guestCount} pessoas • Checkout</p>
                </div>
             </div>

             {jobData.notes && (
                 <div className="bg-rose-50 rounded-xl p-4 border border-rose-100 flex gap-3 items-start">
                    <AlertTriangle className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
                    <p className="text-sm text-rose-800 leading-snug font-medium">
                        {jobData.notes}
                    </p>
                 </div>
             )}
          </div>

          {/* 5. Checklist Snapshot */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
             <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold text-slate-800">Checklist</h3>
                <span className="text-xs font-bold bg-slate-100 text-slate-600 px-2 py-1 rounded-md">
                    {progress.toFixed(0)}%
                </span>
             </div>
             
             <Progress value={progress} className="h-2.5 rounded-full" />
             
             <div className="space-y-3 pt-2">
                {jobData.checklist.items.map((item) => (
                    <div key={item.id} className="flex items-center gap-3">
                        <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            item.done ? "bg-emerald-500 border-emerald-500" : "border-slate-300"
                        )}>
                            {item.done && <CheckCircle2 className="h-3 w-3 text-white" />}
                        </div>
                        <span className="text-sm text-slate-600 font-medium truncate">{item.text}</span>
                    </div>
                ))}
                {jobData.checklist.total > 3 && (
                    <p className="text-xs text-slate-400 font-bold pl-8 pt-1">
                        + {jobData.checklist.total - 3} outros itens
                    </p>
                )}
             </div>

             <Button 
                variant="outline" 
                className="w-full h-12 border-sky-200 text-sky-600 hover:bg-sky-50 font-bold rounded-xl mt-2"
                onClick={() => navigate(`/checklist/${id}`)}
             >
                Ver Lista Completa
             </Button>
          </div>

        </motion.div>
      </div>

      {/* Sticky Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 p-4 pb-safe bg-white border-t border-slate-100 z-50 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
         <div className="flex gap-4">
            <Button 
              variant="outline" 
              className="flex-1 h-14 rounded-2xl border-slate-200 text-slate-600 font-bold text-base gap-2"
              onClick={() => navigate(`/checklist/${id}`)}
            >
              <Camera className="h-5 w-5" />
              Fotos
            </Button>
            <Button 
              className="flex-[2] h-14 rounded-2xl bg-slate-900 text-white hover:bg-slate-800 font-bold text-base gap-2 shadow-lg shadow-slate-300"
              onClick={() => navigate(`/checklist/${id}`)}
            >
              Iniciar Job
              <ArrowRight className="h-5 w-5" />
            </Button>
         </div>
      </div>

    </div>
  );
}