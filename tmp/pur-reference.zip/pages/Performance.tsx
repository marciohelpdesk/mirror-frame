import React from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { ProScoreCard, ProMetrics } from '@/components/gamification/ProScoreCard';
import { BadgesGrid } from '@/components/gamification/BadgesGrid';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { motion } from 'framer-motion';

// Mock Data
const userMetrics: ProMetrics = {
  overallScore: 94,
  consistencyScore: 98,
  qualityRating: 4.9,
  speedEfficiency: 92,
  photoQuality: 88,
  streakDays: 14
};

export default function Performance() {
  return (
    <MobileLayout title="Performance Pro" showBack={true}>
      <div className="space-y-8 pt-4 pb-8">
        
        {/* Main Score Section */}
        <section>
          <ProScoreCard metrics={userMetrics} />
        </section>

        {/* Badges Section */}
        <section className="space-y-4">
          <SectionHeader title="Conquistas & Badges" count={2} />
          <p className="text-xs text-slate-500 -mt-2 px-1">
            Desbloqueie badges exclusivos mantendo padrões de alta qualidade.
          </p>
          <BadgesGrid />
        </section>

        {/* Tips Section */}
        <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-sky-50 border border-sky-100 rounded-3xl p-6 space-y-3"
        >
            <h3 className="font-bold text-sky-900 text-sm uppercase tracking-wide">Dica do Sistema</h3>
            <p className="text-sm text-sky-800 font-medium leading-relaxed">
                Para desbloquear o badge <span className="font-bold">Fotógrafo Pro</span>, tente usar mais luz natural nas fotos do banheiro e cozinha. Sua média atual é 88/100.
            </p>
        </motion.div>
      </div>
    </MobileLayout>
  );
}