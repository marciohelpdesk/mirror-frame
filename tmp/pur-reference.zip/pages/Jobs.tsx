import React, { useState, useMemo } from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AirbnbService } from '@/services/airbnbSync';
import { AutoScheduler } from '@/services/autoScheduler';
import { 
  Plus, 
  ChevronLeft, 
  ChevronRight, 
  MapPin, 
  Calendar as CalendarIcon,
  RotateCcw,
  Filter,
  X,
  Check,
  Home,
  User,
  Clock,
  Sparkles,
  ArrowRight,
  LogOut,
  LogIn,
  AlertCircle,
  RefreshCw,
  Link,
  Bot
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/toaster';

// --- Types ---
type ViewType = 'day' | 'week' | 'month';
type JobStatus = 'scheduled' | 'pending' | 'in-progress' | 'completed';

interface Job {
  id: number;
  property: string;
  address: string;
  start: Date;
  end: Date;
  status: JobStatus;
  type?: string;
  guest?: string;
  cleanerName?: string; // New
  aiTags?: string[]; // New
  aiReason?: string; // New
}

// Mock Properties for Selection
const availableProperties = [
  { id: 1, name: 'Casa Praia Miami', address: '123 Ocean Drive', image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=200&auto=format&fit=crop' },
  { id: 2, name: 'Apartamento Downtown', address: '456 Brickell Ave', image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=200&auto=format&fit=crop' },
  { id: 3, name: 'Villa Orlando', address: '789 Disney Way', image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=200&auto=format&fit=crop' },
];

// --- Mock Data Generator ---
const createDate = (daysAdd: number, hours: number, minutes: number) => {
  const d = new Date();
  d.setDate(d.getDate() + daysAdd);
  d.setHours(hours, minutes, 0, 0);
  return d;
};

const generateMockJobs = (): Job[] => [
  {
    id: 1,
    property: 'Casa Praia Miami',
    address: '123 Ocean Drive',
    start: createDate(0, 10, 0), // Today 10:00
    end: createDate(0, 15, 0),   // Today 15:00
    status: 'scheduled',
    type: 'Checkout'
  },
  {
    id: 2,
    property: 'Villa Orlando',
    address: '789 Disney Way',
    start: createDate(1, 9, 0),
    end: createDate(1, 12, 30),
    status: 'completed',
    type: 'Deep Clean'
  },
  {
    id: 3,
    property: 'Apartamento Downtown',
    address: '456 Brickell Ave',
    start: createDate(1, 14, 0),
    end: createDate(1, 16, 0),
    status: 'pending',
    type: 'Turnover'
  },
];

const statusColors: Record<JobStatus, string> = {
  scheduled: 'bg-slate-100 text-slate-600 border-slate-200',
  pending: 'bg-amber-100 text-amber-700 border-amber-200',
  'in-progress': 'bg-cyan-100 text-cyan-700 border-cyan-200',
  completed: 'bg-emerald-100 text-emerald-700 border-emerald-200'
};

const statusDotColors: Record<JobStatus, string> = {
  scheduled: 'bg-slate-400',
  pending: 'bg-amber-400',
  'in-progress': 'bg-cyan-400',
  completed: 'bg-emerald-400'
};

const statusLabels: Record<string, string> = {
  all: 'Todos',
  scheduled: 'Agendado',
  pending: 'Pendente',
  'in-progress': 'Em Andamento',
  completed: 'Concluído'
};

export default function Agenda() {
  const navigate = useNavigate();
  const { success, error, info } = useToast();
  
  const [view, setView] = useState<ViewType>('month');
  const [currentDate, setCurrentDate] = useState(new Date()); 
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [filterStatus, setFilterStatus] = useState<JobStatus | 'all'>('all');
  const [jobs, setJobs] = useState<Job[]>(generateMockJobs());

  // --- Creation State (Wizard) ---
  const [isCreating, setIsCreating] = useState(false);
  const [step, setStep] = useState(1); // 1: Property, 2: Details, 3: Guest
  const [direction, setDirection] = useState(0); // For animation direction

  const [selectedPropertyId, setSelectedPropertyId] = useState<number | null>(null);
  const [newJobData, setNewJobData] = useState({
    date: new Date().toISOString().split('T')[0],
    checkoutTime: '11:00', // Previous guest leaves
    checkinTime: '16:00',  // New guest arrives
    type: 'Checkout',
    guest: '',
    guestCount: 2,
    notes: ''
  });

  const [isSyncing, setIsSyncing] = useState(false);

  // --- Helpers ---
  const getDaysInMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const getFirstDayOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1).getDay(); // 0 = Sun
  
  const isSameDay = (d1: Date, d2: Date) => 
    d1.getDate() === d2.getDate() && 
    d1.getMonth() === d2.getMonth() && 
    d1.getFullYear() === d2.getFullYear();

  const addMonths = (date: Date, amount: number) => {
    const newDate = new Date(date);
    newDate.setMonth(newDate.getMonth() + amount);
    return newDate;
  };

  const addDays = (date: Date, amount: number) => {
    const newDate = new Date(date);
    newDate.setDate(newDate.getDate() + amount);
    return newDate;
  };

  const getStartOfWeek = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day; // Adjust so Sunday is first
    return new Date(d.setDate(diff));
  };

  // --- Filtering ---
  const filteredJobs = useMemo(() => {
    if (filterStatus === 'all') return jobs;
    return jobs.filter(job => job.status === filterStatus);
  }, [jobs, filterStatus]);

  const getJobsForDay = (date: Date) => {
    return filteredJobs.filter(job => isSameDay(job.start, date));
  };

  // --- Handlers ---
  const handlePrev = () => {
    if (view === 'month') setCurrentDate(addMonths(currentDate, -1));
    else if (view === 'week') setCurrentDate(addDays(currentDate, -7));
    else setCurrentDate(addDays(currentDate, -1));
  };

  const handleNext = () => {
    if (view === 'month') setCurrentDate(addMonths(currentDate, 1));
    else if (view === 'week') setCurrentDate(addDays(currentDate, 7));
    else setCurrentDate(addDays(currentDate, 1));
  };

  const handleToday = () => {
    const now = new Date();
    setCurrentDate(now);
    setSelectedDate(now);
  };

  const handleDayClick = (day: number) => {
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    setSelectedDate(newDate);
  };

  const resetForm = () => {
    setIsCreating(false);
    setStep(1);
    setSelectedPropertyId(null);
    setNewJobData({
      date: new Date().toISOString().split('T')[0],
      checkoutTime: '11:00',
      checkinTime: '16:00',
      type: 'Checkout',
      guest: '',
      guestCount: 2,
      notes: ''
    });
  };

  const nextStep = () => {
    if (step === 1 && !selectedPropertyId) {
      error("Selecione uma propriedade para continuar");
      return;
    }
    setDirection(1);
    setStep(s => s + 1);
  };

  const prevStep = () => {
    setDirection(-1);
    setStep(s => s - 1);
  };

  const handleCreateJob = () => {
    const property = availableProperties.find(p => p.id === selectedPropertyId);
    if (!property) return;

    // Simulate standard cleaning time (Start = Checkout + 30min, End = Checkin - 30min) or custom logic
    const [year, month, day] = newJobData.date.split('-').map(Number);
    
    // Parse times
    const [outH, outM] = newJobData.checkoutTime.split(':').map(Number);
    const [inH, inM] = newJobData.checkinTime.split(':').map(Number);

    // Job starts when guest leaves
    const startDate = new Date(year, month - 1, day, outH, outM);
    // Job ends when new guest arrives
    const endDate = new Date(year, month - 1, day, inH, inM);

    const newJob: Job = {
      id: Date.now(),
      property: property.name,
      address: property.address,
      start: startDate,
      end: endDate,
      status: 'scheduled',
      type: newJobData.type,
      guest: newJobData.guest
    };

    setJobs(prev => [...prev, newJob]);
    success("Agendamento criado com sucesso!");
    resetForm();
    
    // Jump to the date
    setCurrentDate(startDate);
    setSelectedDate(startDate);
  };

  const handleSyncAirbnb = async () => {
    setIsSyncing(true);
    try {
      // 1. Fetch Reservations
      const reservations = await AirbnbService.syncReservations();
      
      const newJobs: Job[] = [];
      const config = AutoScheduler.getConfig();

      // 2. Process each reservation through AutoPilot
      for (const res of reservations) {
        let jobStart, jobEnd, cleanerName, aiTags, aiReason;

        if (config.enabled) {
          // AI Logic
          const schedule = await AutoScheduler.processReservation(res);
          jobStart = schedule.startTime;
          jobEnd = schedule.endTime;
          cleanerName = schedule.cleanerName;
          aiTags = schedule.tags;
          aiReason = schedule.aiReasoning;
        } else {
          // Fallback manual logic
          const jobDate = new Date(res.checkOut);
          jobStart = new Date(jobDate);
          jobStart.setHours(11, 0, 0, 0); 
          jobEnd = new Date(jobDate);
          jobEnd.setHours(15, 0, 0, 0); 
          cleanerName = 'Não atribuído';
        }

        newJobs.push({
          id: Date.now() + Math.random(),
          property: res.propertyName,
          address: availableProperties.find(p => p.name === res.propertyName)?.address || 'Endereço Importado',
          start: jobStart,
          end: jobEnd,
          status: 'scheduled',
          type: 'Checkout (Airbnb)',
          guest: res.guestName,
          cleanerName,
          aiTags,
          aiReason
        });
      }

      setJobs(prev => [...prev, ...newJobs]);
      
      if (config.enabled) {
        success(`${newJobs.length} reservas sincronizadas e agendadas pelo Auto-Pilot!`);
      } else {
        success(`${newJobs.length} reservas sincronizadas!`);
      }

      if (newJobs.length > 0) {
        // Jump to the first imported job
        setCurrentDate(newJobs[0].start);
        setSelectedDate(newJobs[0].start);
      }
    } catch (e) {
      error("Erro ao sincronizar com Airbnb");
    } finally {
      setIsSyncing(false);
    }
  };

  // --- Renderers ---

  const renderMonthView = () => {
    const daysInMonth = getDaysInMonth(currentDate);
    const firstDay = getFirstDayOfMonth(currentDate);
    const days = [];

    // Empty slots
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-10 w-10" />);
    }

    // Days
    for (let i = 1; i <= daysInMonth; i++) {
      const dateToCheck = new Date(currentDate.getFullYear(), currentDate.getMonth(), i);
      const isSelected = isSameDay(dateToCheck, selectedDate);
      const isToday = isSameDay(dateToCheck, new Date());
      const dayJobs = getJobsForDay(dateToCheck);
      const hasJobs = dayJobs.length > 0;
      const primaryStatus = hasJobs ? dayJobs[0].status : null;

      days.push(
        <button
          key={i}
          onClick={() => handleDayClick(i)}
          className="relative flex flex-col items-center justify-center h-10 w-10"
        >
          <div className={cn(
            "h-8 w-8 flex items-center justify-center rounded-full text-sm font-medium transition-all",
            isSelected ? "bg-cyan-500 text-white shadow-md shadow-cyan-200" : 
            isToday ? "bg-cyan-50 text-cyan-600 border border-cyan-100" : "text-slate-600 hover:bg-slate-100"
          )}>
            {i}
          </div>
          {hasJobs && !isSelected && (
            <div className={cn("absolute bottom-0 w-1.5 h-1.5 rounded-full", statusDotColors[primaryStatus!])} />
          )}
        </button>
      );
    }

    return (
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 animate-fade-in-up">
        {/* Days Header */}
        <div className="grid grid-cols-7 mb-2">
          {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map(day => (
            <div key={day} className="text-center text-[10px] font-bold text-slate-400 tracking-wider">
              {day}
            </div>
          ))}
        </div>
        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-y-2 place-items-center">
          {days}
        </div>
      </div>
    );
  };

  const renderWeekView = () => {
    const startOfWeek = getStartOfWeek(currentDate);
    const weekDays = Array.from({ length: 7 }, (_, i) => addDays(startOfWeek, i));
    const hours = Array.from({ length: 11 }, (_, i) => i + 8); // 8:00 to 18:00

    return (
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 overflow-hidden animate-fade-in-up">
        <div className="overflow-x-auto">
          <div className="min-w-[500px]">
            {/* Header Row */}
            <div className="grid grid-cols-8 gap-2 mb-4 border-b border-slate-100 pb-2">
              <div className="w-10 text-[10px] text-slate-400 font-bold self-end text-center">Hora</div>
              {weekDays.map((d, i) => {
                const isToday = isSameDay(d, new Date());
                return (
                  <div key={i} className="text-center flex flex-col items-center gap-1">
                    <span className="text-[10px] text-slate-400 font-bold uppercase">{d.toLocaleDateString('pt-BR', { weekday: 'short' }).slice(0, 3)}</span>
                    <div className={cn(
                      "w-7 h-7 flex items-center justify-center rounded-full text-xs font-bold",
                      isToday ? "bg-cyan-500 text-white" : "text-slate-700"
                    )}>
                      {d.getDate()}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Grid Body */}
            <div className="relative">
               {hours.map((hour) => (
                 <div key={hour} className="grid grid-cols-8 gap-2 h-14 border-b border-slate-50 relative group">
                    <div className="text-[10px] text-slate-400 font-medium -mt-2 text-center bg-white pr-1 z-10">{hour}:00</div>
                    {/* Columns for each day */}
                    {weekDays.map((day, dayIdx) => {
                       // Find jobs for this day AND this hour
                       const slotJobs = filteredJobs.filter(j => 
                         isSameDay(j.start, day) && 
                         j.start.getHours() === hour
                       );

                       return (
                         <div key={dayIdx} className="relative h-full border-l border-dashed border-slate-100 last:border-r-0">
                            {slotJobs.map(job => (
                              <motion.div
                                key={job.id}
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                onClick={() => navigate(`/jobs/${job.id}`)}
                                className={cn(
                                  "absolute top-1 left-0.5 right-0.5 bottom-1 rounded-md p-1 cursor-pointer hover:brightness-95 transition-all shadow-sm flex flex-col justify-center overflow-hidden border",
                                  statusColors[job.status]
                                )}
                              >
                                <div className="text-[9px] font-bold leading-none truncate">{job.property}</div>
                              </motion.div>
                            ))}
                         </div>
                       );
                    })}
                 </div>
               ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderDayView = () => {
    const hours = Array.from({ length: 12 }, (_, i) => i + 7);
    const dayJobs = getJobsForDay(currentDate);

    return (
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 min-h-[500px] animate-fade-in-up">
        <div className="relative space-y-8 pl-4">
          <div className="absolute left-[4.5rem] top-2 bottom-0 w-px bg-slate-100 border-l border-dashed border-slate-200" />
          {hours.map(hour => {
             const jobsStarting = dayJobs.filter(j => j.start.getHours() === hour);
             return (
               <div key={hour} className="relative flex items-start group">
                 <div className="w-14 text-xs font-bold text-slate-400 pt-1 text-right pr-4 flex-shrink-0">
                   {hour}:00
                 </div>
                 <div className="flex-1 min-h-[3rem] relative pt-1">
                    <div className="absolute top-3 left-0 w-full h-px bg-slate-50" />
                    {jobsStarting.map(job => (
                      <motion.div
                        key={job.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        onClick={() => navigate(`/jobs/${job.id}`)}
                        className="relative z-10 bg-white border border-slate-100 shadow-lg shadow-slate-100/50 rounded-2xl p-4 mb-4 cursor-pointer hover:border-cyan-200 hover:shadow-cyan-100 transition-all group/card"
                      >
                         <div className="flex items-start justify-between mb-2">
                           <div className="flex items-center gap-2">
                             <div className={cn("w-2 h-2 rounded-full", statusDotColors[job.status])} />
                             <span className="font-bold text-slate-800 text-lg">
                               {job.start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                             </span>
                           </div>
                           <Badge variant="outline" className={cn("text-[10px] font-bold uppercase border-0 px-2 py-0.5 rounded-md", statusColors[job.status])}>
                             {statusLabels[job.status]}
                           </Badge>
                         </div>
                         <h4 className="font-bold text-slate-700 text-base mb-1 group-hover/card:text-cyan-600 transition-colors">{job.property}</h4>
                         <div className="flex items-center gap-1.5 text-slate-400 text-sm">
                           <MapPin className="h-3.5 w-3.5" />
                           {job.address}
                         </div>
                      </motion.div>
                    ))}
                 </div>
               </div>
             );
          })}
          {dayJobs.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center opacity-50 pointer-events-none">
              <p className="text-slate-300 font-bold text-lg">Sem jobs agendados</p>
            </div>
          )}
        </div>
      </div>
    );
  };

  const selectedDayJobs = getJobsForDay(selectedDate);

  // --- WIZARD STEPS CONTENT ---

  const renderStep1_Property = () => (
    <div className="space-y-4">
      <Label className="text-sm font-bold text-slate-400 uppercase tracking-wider ml-1 flex items-center gap-2">
         <Home className="w-4 h-4" /> Selecione o Imóvel
      </Label>
      <div className="grid gap-4">
        {availableProperties.map(prop => (
          <motion.div
            key={prop.id}
            onClick={() => setSelectedPropertyId(prop.id)}
            whileTap={{ scale: 0.98 }}
            className={cn(
              "relative flex items-center gap-4 p-3 rounded-2xl border-2 cursor-pointer transition-all overflow-hidden",
              selectedPropertyId === prop.id 
                ? "border-sky-500 bg-sky-50 shadow-md ring-1 ring-sky-200" 
                : "border-transparent bg-white shadow-sm hover:border-slate-200"
            )}
          >
            <img src={prop.image} alt={prop.name} className="w-16 h-16 rounded-xl object-cover bg-slate-200" />
            <div className="flex-1 min-w-0">
              <p className={cn("font-bold text-base truncate", selectedPropertyId === prop.id ? "text-sky-700" : "text-slate-800")}>
                {prop.name}
              </p>
              <p className="text-xs text-slate-500 truncate">{prop.address}</p>
            </div>
            {selectedPropertyId === prop.id && (
              <div className="w-6 h-6 rounded-full bg-sky-500 flex items-center justify-center mr-2 animate-in fade-in zoom-in duration-200">
                 <Check className="w-4 h-4 text-white" />
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );

  const renderStep2_Details = () => (
    <div className="space-y-6">
       <Label className="text-sm font-bold text-slate-400 uppercase tracking-wider ml-1 flex items-center gap-2">
         <Clock className="w-4 h-4" /> Detalhes da Limpeza
       </Label>
       
       <div className="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 space-y-6">
          <div className="space-y-2">
            <Label className="text-xs text-slate-500 font-semibold">Data do Job</Label>
            <Input 
              type="date" 
              className="bg-slate-50 border-slate-200 rounded-xl h-12 text-base"
              value={newJobData.date}
              onChange={e => setNewJobData({...newJobData, date: e.target.value})}
            />
          </div>

          <div className="p-4 bg-sky-50/50 rounded-2xl border border-sky-100 relative">
             <div className="absolute top-[-10px] left-4 bg-sky-100 text-sky-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
               Janela de Serviço
             </div>
             <p className="text-xs text-slate-500 mb-4 leading-tight">
               Defina o horário de saída do hóspede anterior e entrada do próximo.
             </p>
             <div className="flex items-center gap-4">
                <div className="space-y-2 flex-1">
                  <Label className="text-xs text-rose-500 font-bold flex items-center gap-1">
                    <LogOut className="w-3 h-3" /> Check-out
                  </Label>
                  <Input 
                    type="time" 
                    className="bg-white border-slate-200 rounded-xl text-center font-bold text-slate-700"
                    value={newJobData.checkoutTime}
                    onChange={e => setNewJobData({...newJobData, checkoutTime: e.target.value})}
                  />
                </div>
                
                <div className="pt-6 text-slate-300">
                  <ArrowRight className="w-5 h-5" />
                </div>

                <div className="space-y-2 flex-1">
                  <Label className="text-xs text-emerald-500 font-bold flex items-center gap-1">
                    <LogIn className="w-3 h-3" /> Check-in
                  </Label>
                  <Input 
                    type="time" 
                    className="bg-white border-slate-200 rounded-xl text-center font-bold text-slate-700"
                    value={newJobData.checkinTime}
                    onChange={e => setNewJobData({...newJobData, checkinTime: e.target.value})}
                  />
                </div>
             </div>
          </div>

          <div className="space-y-2">
             <Label className="text-xs text-slate-500 font-semibold">Tipo de Limpeza</Label>
             <div className="grid grid-cols-2 gap-2">
                {['Checkout', 'Faxina Pesada', 'Manutenção', 'Recorrente'].map(type => (
                   <button
                     key={type}
                     onClick={() => setNewJobData({...newJobData, type})}
                     className={cn(
                       "px-2 py-3 rounded-xl text-sm font-bold transition-all border text-center",
                       newJobData.type === type 
                         ? "bg-sky-500 text-white border-sky-500 shadow-lg shadow-sky-200" 
                         : "bg-white text-slate-500 border-slate-200 hover:bg-slate-50"
                     )}
                   >
                     {type}
                   </button>
                ))}
             </div>
          </div>
       </div>
    </div>
  );

  const renderStep3_Guest = () => (
    <div className="space-y-6">
       <Label className="text-sm font-bold text-slate-400 uppercase tracking-wider ml-1 flex items-center gap-2">
         <User className="w-4 h-4" /> Próximo Hóspede
       </Label>
       <div className="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 space-y-5">
          <div className="space-y-2">
              <Label className="text-xs text-slate-500 font-semibold">Nome Completo</Label>
              <Input 
                  placeholder="Ex: John Smith"
                  className="bg-slate-50 border-slate-200 rounded-xl h-12"
                  value={newJobData.guest}
                  onChange={e => setNewJobData({...newJobData, guest: e.target.value})}
              />
          </div>
          <div className="space-y-2">
              <Label className="text-xs text-slate-500 font-semibold">Quantidade de Pessoas</Label>
              <div className="flex items-center gap-4">
                 <button 
                   onClick={() => setNewJobData(p => ({...p, guestCount: Math.max(1, p.guestCount - 1)}))}
                   className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 font-bold hover:bg-slate-200"
                 >
                   -
                 </button>
                 <span className="text-xl font-bold text-slate-800 w-8 text-center">{newJobData.guestCount}</span>
                 <button 
                   onClick={() => setNewJobData(p => ({...p, guestCount: p.guestCount + 1}))}
                   className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 font-bold hover:bg-slate-200"
                 >
                   +
                 </button>
              </div>
          </div>
          <div className="space-y-2">
              <Label className="text-xs text-slate-500 font-semibold">Notas para a equipe</Label>
              <textarea 
                  placeholder="Ex: Hóspede alérgico, usar produtos sem cheiro..."
                  className="w-full bg-slate-50 border-slate-200 rounded-xl p-3 text-sm min-h-[100px] focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                  value={newJobData.notes}
                  onChange={e => setNewJobData({...newJobData, notes: e.target.value})}
              />
          </div>
          
          <div className="flex items-start gap-2 bg-amber-50 p-3 rounded-xl border border-amber-100 text-amber-800 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <p>Verifique se as notas estão claras. A equipe verá isso no app.</p>
          </div>
       </div>
    </div>
  );

  return (
    <MobileLayout showHeader={false} showBack={false}>
      {/* --- NEW JOB WIZARD OVERLAY --- */}
      <AnimatePresence>
        {isCreating && (
          <motion.div 
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[100] bg-slate-50 flex flex-col"
          >
            {/* Header */}
            <div className="px-6 pt-safe-top pb-4 bg-white border-b border-slate-100 shadow-sm z-20">
              <div className="flex items-center justify-between mb-4">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={resetForm} 
                  className="hover:bg-slate-100 rounded-full -ml-2"
                >
                  <X className="h-6 w-6 text-slate-500" />
                </Button>
                <div className="text-center">
                  <h2 className="text-lg font-bold text-slate-800">Novo Agendamento</h2>
                  <p className="text-xs text-slate-400 font-medium">Passo {step} de 3</p>
                </div>
                <div className="w-10" /> 
              </div>
              
              {/* Progress Bar */}
              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-sky-500 rounded-full"
                  initial={{ width: '33%' }}
                  animate={{ width: `${(step / 3) * 100}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden p-6 relative">
              <AnimatePresence mode='wait' custom={direction}>
                <motion.div
                  key={step}
                  custom={direction}
                  initial={{ x: direction > 0 ? 50 : -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: direction > 0 ? -50 : 50, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {step === 1 && renderStep1_Property()}
                  {step === 2 && renderStep2_Details()}
                  {step === 3 && renderStep3_Guest()}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Bottom Actions */}
            <div className="p-6 bg-white border-t border-slate-100 z-50 pb-safe flex gap-3 shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
               {step > 1 && (
                 <Button 
                   onClick={prevStep}
                   variant="outline"
                   className="h-14 w-14 rounded-2xl border-slate-200 text-slate-600"
                 >
                   <ChevronLeft className="w-6 h-6" />
                 </Button>
               )}
               
               <Button 
                 onClick={step === 3 ? handleCreateJob : nextStep}
                 disabled={step === 1 && !selectedPropertyId}
                 className={cn(
                   "flex-1 h-14 rounded-2xl text-lg font-bold shadow-xl transition-all",
                   step === 3 
                     ? "bg-emerald-500 hover:bg-emerald-600 shadow-emerald-500/20" 
                     : "bg-sky-500 hover:bg-sky-600 shadow-sky-500/20"
                 )}
               >
                 {step === 3 ? (
                   <span className="flex items-center gap-2">Agendar <Check className="w-5 h-5" /></span>
                 ) : (
                   <span className="flex items-center gap-2">Próximo <ArrowRight className="w-5 h-5" /></span>
                 )}
               </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>


      <div className="space-y-6 pt-12 pb-24">
        
        {/* Custom Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">SCHEDULE</p>
              <h1 className="text-4xl font-bold text-slate-800 tracking-tight">Agenda</h1>
            </div>
            
            <div className="flex items-center gap-2">
              {/* Sync Airbnb Button */}
              <Button 
                variant="outline"
                size="icon"
                onClick={handleSyncAirbnb}
                disabled={isSyncing}
                className={cn(
                  "w-10 h-10 rounded-2xl border-rose-100 text-rose-500 bg-rose-50 hover:bg-rose-100 hover:text-rose-600 transition-all",
                  isSyncing && "animate-spin"
                )}
                title="Sincronizar Airbnb"
              >
                {isSyncing ? <RefreshCw className="h-5 w-5" /> : <Link className="h-5 w-5" />}
              </Button>

              <Button 
                className="bg-cyan-500 hover:bg-cyan-600 text-white rounded-2xl h-10 px-4 font-bold shadow-lg shadow-cyan-200 gap-2"
                onClick={() => setIsCreating(true)}
              >
                <Plus className="h-5 w-5" />
                Add Job
              </Button>
            </div>
          </div>

          {/* View Switcher */}
          <div className="bg-white p-1 rounded-2xl flex shadow-sm border border-slate-100">
            {(['day', 'week', 'month'] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={cn(
                  "flex-1 py-2.5 rounded-xl text-sm font-bold transition-all capitalize",
                  view === v 
                    ? "bg-cyan-500 text-white shadow-md shadow-cyan-200" 
                    : "text-slate-500 hover:bg-slate-50"
                )}
              >
                {v === 'day' ? 'Dia' : v === 'week' ? 'Semana' : 'Mês'}
              </button>
            ))}
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 hide-scrollbar">
            <div className="bg-white p-2 rounded-xl border border-slate-100 shadow-sm flex-shrink-0">
               <Filter className="h-4 w-4 text-slate-400" />
            </div>
            {['all', 'scheduled', 'pending', 'in-progress', 'completed'].map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status as JobStatus | 'all')}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border",
                  filterStatus === status
                    ? "bg-slate-800 text-white border-slate-800 shadow-md"
                    : "bg-white text-slate-500 border-slate-100 hover:border-slate-300"
                )}
              >
                {statusLabels[status] || 'Todos'}
              </button>
            ))}
          </div>
        </div>

        {/* Date Navigation */}
        <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2">
               <h2 className="text-lg font-bold text-slate-800 capitalize">
                {view === 'week' 
                  ? `Semana de ${getStartOfWeek(currentDate).getDate()}` 
                  : currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric', day: view === 'day' ? 'numeric' : undefined })}
               </h2>
            </div>
            
            <div className="flex items-center gap-2">
                <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleToday}
                    className="h-9 px-3 rounded-xl bg-white border-slate-200 text-slate-600 hover:text-cyan-600 gap-1 font-bold text-xs"
                >
                    <RotateCcw className="h-3 w-3" />
                    Hoje
                </Button>
                <div className="flex gap-1">
                    <Button variant="ghost" size="icon" onClick={handlePrev} className="h-9 w-9 rounded-full bg-white border border-slate-100 hover:bg-slate-50 shadow-sm">
                        <ChevronLeft className="h-4 w-4 text-slate-500" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={handleNext} className="h-9 w-9 rounded-full bg-white border border-slate-100 hover:bg-slate-50 shadow-sm">
                        <ChevronRight className="h-4 w-4 text-slate-500" />
                    </Button>
                </div>
            </div>
        </div>

        {/* Views Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`${view}-${currentDate.toISOString()}`}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
          >
            {view === 'month' && (
              <div className="space-y-6">
                {renderMonthView()}
                
                {/* Selected Day List (Month View) */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between px-1">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wide">
                      {selectedDate.toLocaleDateString('pt-BR', { weekday: 'long', month: 'long', day: 'numeric' })}
                    </h3>
                    <span className="text-xs font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md">
                      {selectedDayJobs.length} jobs
                    </span>
                  </div>

                  {selectedDayJobs.length > 0 ? (
                    <div className="space-y-3">
                      {selectedDayJobs.map((job) => (
                        <div 
                          key={job.id}
                          onClick={() => navigate(`/jobs/${job.id}`)}
                          className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 cursor-pointer hover:scale-[1.01] transition-transform space-y-3"
                        >
                          <div className="flex items-center gap-4">
                            <div className={cn("h-full w-1.5 rounded-full self-stretch", statusDotColors[job.status])} />
                            <div className="flex-1 space-y-1">
                              <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-800 text-lg">
                                    {job.start.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                  </span>
                                  <span className="text-slate-300">→</span>
                                  <span className="font-bold text-slate-500 text-sm">
                                    {job.end.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                  </span>
                              </div>
                              <div className="flex justify-between items-start">
                                  <div>
                                      <p className="font-bold text-slate-700">{job.property}</p>
                                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                                      <MapPin className="h-3 w-3" />
                                      {job.address}
                                      </div>
                                  </div>
                                  {job.type && (
                                      <Badge variant="secondary" className="bg-sky-50 text-sky-600 border-sky-100 text-[10px] font-bold">
                                          {job.type}
                                      </Badge>
                                  )}
                              </div>
                            </div>
                          </div>

                          {/* AI Auto-Pilot Info */}
                          {job.aiTags && job.aiTags.length > 0 && (
                            <div className="pl-5 pt-1 border-t border-slate-50 flex items-start gap-3">
                              <div className="p-1 bg-indigo-50 rounded-lg">
                                <Bot className="w-3 h-3 text-indigo-500" />
                              </div>
                              <div className="flex-1">
                                <div className="flex flex-wrap gap-1 mb-1">
                                  {job.aiTags.map(tag => (
                                    <span key={tag} className="text-[10px] font-bold px-1.5 py-0.5 bg-indigo-50 text-indigo-600 rounded">
                                      {tag}
                                    </span>
                                  ))}
                                </div>
                                {job.cleanerName && (
                                  <p className="text-xs text-slate-500">
                                    <span className="font-bold text-slate-700">Staff: {job.cleanerName}</span>
                                    {job.aiReason && <span className="block text-[10px] text-slate-400 mt-0.5 italic">{job.aiReason}</span>}
                                  </p>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-white/50 border border-slate-100 rounded-2xl p-8 text-center space-y-2">
                       <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-2">
                         <CalendarIcon className="h-6 w-6 text-slate-300" />
                       </div>
                       <p className="text-slate-400 font-medium">Nenhum job agendado para este dia.</p>
                       <Button variant="link" className="text-cyan-500 font-bold" onClick={() => setIsCreating(true)}>Agendar agora</Button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {view === 'day' && renderDayView()}

            {view === 'week' && renderWeekView()}
          </motion.div>
        </AnimatePresence>
      </div>
    </MobileLayout>
  );
}