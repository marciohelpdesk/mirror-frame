import { MobileLayout } from '@/components/layout/MobileLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign,
  Calendar,
  Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const earningsData = {
  thisMonth: 4850,
  lastMonth: 4200,
  pending: 1200,
  totalJobs: 45,
  history: [
    { id: 1, date: '02/02/2026', property: 'Casa Praia Miami', amount: 150, status: 'paid' },
    { id: 2, date: '01/02/2026', property: 'Apartamento Downtown', amount: 120, status: 'paid' },
    { id: 3, date: '31/01/2026', property: 'Villa Orlando', amount: 200, status: 'pending' },
    { id: 4, date: '30/01/2026', property: 'Casa Praia Miami', amount: 150, status: 'paid' },
    { id: 5, date: '29/01/2026', property: 'Apartamento Downtown', amount: 120, status: 'paid' },
  ]
};

export default function Earnings() {
  const variation = ((earningsData.thisMonth - earningsData.lastMonth) / earningsData.lastMonth) * 100;

  return (
    <MobileLayout title="Ganhos" rightAction={
      <Button size="icon" variant="outline" className="glass-panel border-0 w-10 h-10 rounded-xl hover:bg-white/80">
        <Download className="h-4 w-4 text-slate-600" />
      </Button>
    }>
      <div className="space-y-8 pt-4 animate-fade-in-up">
        {/* Main Stats */}
        <Card className="glass-panel border-0 overflow-hidden rounded-3xl shadow-lg shadow-sky-100/50">
          <CardHeader className="pb-2 px-7 pt-7">
            <CardTitle className="text-sm font-bold text-slate-400 uppercase tracking-wider flex items-center gap-3">
              <span className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                <DollarSign className="h-5 w-5 text-blue-600" />
              </span>
              Este Mês
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 px-7 pb-7">
            <div className="flex items-end justify-between">
              <div>
                <span className="text-5xl font-bold text-slate-800 tracking-tight block mb-2">
                  R$ {earningsData.thisMonth.toLocaleString()}
                </span>
                <div className={`flex items-center gap-2 text-sm font-medium ${variation >= 0 ? 'text-emerald-600' : 'text-destructive'}`}>
                  {variation >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
                  <span className="bg-white/60 px-2 py-1 rounded-lg border border-white/50 shadow-sm backdrop-blur-sm">
                    {Math.abs(variation).toFixed(1)}% vs mês passado
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Secondary Stats */}
        <div className="grid grid-cols-2 gap-5">
          <Card className="glass-panel border-0 p-6 rounded-3xl hover:scale-[1.02] transition-transform shadow-sm">
            <div className="flex flex-col gap-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-amber-600" />
              </div>
              <div className="space-y-1">
                <p className="text-3xl font-bold text-slate-800">R$ {earningsData.pending}</p>
                <p className="text-xs font-bold text-amber-600 uppercase tracking-wide">Pendente</p>
              </div>
            </div>
          </Card>

          <Card className="glass-panel border-0 p-6 rounded-3xl hover:scale-[1.02] transition-transform shadow-sm">
            <div className="flex flex-col gap-4">
              <div className="w-12 h-12 rounded-2xl bg-sky-100 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-sky-600" />
              </div>
              <div className="space-y-1">
                <p className="text-3xl font-bold text-slate-800">{earningsData.totalJobs}</p>
                <p className="text-xs font-bold text-sky-600 uppercase tracking-wide">Jobs Realizados</p>
              </div>
            </div>
          </Card>
        </div>

        {/* History */}
        <div className="space-y-5">
          <h3 className="font-bold text-xl text-slate-800 px-1">Histórico Recente</h3>
          
          <div className="space-y-4">
            {earningsData.history.map((item) => (
              <div 
                key={item.id}
                className="glass-panel p-6 flex items-center justify-between rounded-2xl hover:bg-white/80 transition-colors shadow-sm"
              >
                <div className="space-y-1.5">
                  <p className="font-bold text-slate-800 text-base">{item.property}</p>
                  <p className="text-xs font-semibold text-slate-400 bg-slate-100 w-fit px-2 py-0.5 rounded-md">{item.date}</p>
                </div>
                <div className="text-right space-y-1.5">
                  <p className="font-bold text-slate-800 text-lg">R$ {item.amount}</p>
                  <Badge 
                    variant={item.status === 'paid' ? 'default' : 'secondary'}
                    className={`text-[10px] h-6 px-3 rounded-lg ${item.status === 'paid' ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200' : 'bg-amber-100 text-amber-700 hover:bg-amber-200'}`}
                  >
                    {item.status === 'paid' ? 'Pago' : 'Pendente'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}