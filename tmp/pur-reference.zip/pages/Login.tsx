import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseMock';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/toaster';
import { Loader2, Check, AtSign, Lock, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Login() {
  const navigate = useNavigate();
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isValidEmail, setIsValidEmail] = useState(false);

  useEffect(() => {
    setIsValidEmail(email.includes('@') && email.includes('.'));
  }, [email]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast.error(error.message);
      setLoading(false);
    } else {
      toast.success('Bem-vindo de volta!');
      // App router will handle redirect based on auth state
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden font-sans bg-sand">
      {/* --- Coastal Ambient Background --- */}
      
      {/* 1. Gradient Base */}
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-sand via-[#E8EEF5] to-[#DCE4ED]" />
      
      {/* 2. Abstract Waves (Framer Motion) */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Deep Ocean Wave */}
        <motion.div
          className="absolute -bottom-[20%] -left-[10%] w-[120%] h-[50%] bg-ocean/5 blur-3xl rounded-[100%]"
          animate={{ 
            y: [0, -20, 0],
            rotate: [0, 2, 0],
            scale: [1, 1.05, 1]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* Seafoam Highlight */}
        <motion.div
          className="absolute top-[10%] -right-[20%] w-[80%] h-[80%] bg-seafoam/10 blur-3xl rounded-full"
          animate={{ 
            x: [0, -30, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut", delay: 2 }}
        />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", duration: 0.8, bounce: 0.2 }}
        className="glass-panel-elevated w-full max-w-sm p-8 space-y-8 relative z-10 shadow-[0_30px_60px_-12px_rgba(10,37,64,0.15)] border-white/60"
      >
        <div className="text-center space-y-4">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
            className="w-20 h-20 mx-auto relative flex items-center justify-center bg-white rounded-2xl shadow-lg shadow-ocean/5 border border-white"
          >
             <div className="absolute inset-0 bg-gradient-to-br from-white to-sand rounded-2xl" />
             <img 
               src="https://i.ibb.co/yBMkg7CV/Design-sem-nome.png" 
               alt="Pur Logo" 
               className="w-12 h-12 object-contain relative z-10" 
             />
          </motion.div>
          
          <div className="space-y-1">
            <h1 className="text-4xl font-display font-bold text-ocean tracking-tight">Pur</h1>
            <p className="text-slate-500 font-medium text-sm tracking-wide">Professional Cleaning Mgmt</p>
          </div>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-1.5 relative group">
              <Label htmlFor="email" className="text-slate-500 text-xs font-bold uppercase tracking-wider ml-1">Work Email</Label>
              <div className="relative">
                <AtSign className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-ocean transition-colors duration-300" />
                <Input
                  id="email"
                  type="email"
                  placeholder="name@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-sand border-slate-200 pl-12 h-14 rounded-2xl text-base transition-all focus:bg-white focus:border-ocean focus:ring-4 focus:ring-ocean/5 shadow-inner shadow-slate-200/50"
                />
                <AnimatePresence>
                  {isValidEmail && (
                    <motion.div 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-seafoam text-ocean p-1 rounded-full"
                    >
                      <Check className="h-3 w-3" />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <div className="space-y-1.5 relative group">
              <Label htmlFor="password" className="text-slate-500 text-xs font-bold uppercase tracking-wider ml-1">Password</Label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-ocean transition-colors duration-300" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-sand border-slate-200 pl-12 h-14 rounded-2xl text-base transition-all focus:bg-white focus:border-ocean focus:ring-4 focus:ring-ocean/5 shadow-inner shadow-slate-200/50"
                />
              </div>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full h-14 text-lg font-bold bg-ocean text-white hover:bg-slate-800 shadow-xl shadow-ocean/20 rounded-2xl transition-all hover:scale-[1.01] active:scale-[0.98] group"
            disabled={loading}
          >
            {loading ? (
              <Loader2 className="h-6 w-6 animate-spin" />
            ) : (
              <span className="flex items-center gap-2">
                Entrar <ArrowRight className="w-5 h-5 opacity-70 group-hover:translate-x-1 transition-transform" />
              </span>
            )}
          </Button>
        </form>

        <div className="text-center pt-2">
          <button 
            onClick={() => toast.info('Entre em contato com o administrador do sistema.')}
            className="text-xs text-slate-400 font-bold hover:text-ocean transition-colors"
          >
            Esqueceu sua senha?
          </button>
        </div>
      </motion.div>
      
      <p className="absolute bottom-6 text-xs text-slate-400 font-medium opacity-60">
        &copy; 2025 Pur Partners. v2.0 Coastal
      </p>
    </div>
  );
}