import React, { useState } from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  Truck, 
  Wrench, 
  Droplet, 
  Zap, 
  Star, 
  Clock, 
  Phone, 
  MessageCircle, 
  MapPin,
  Filter,
  ArrowRight,
  AlertTriangle,
  Package
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/toaster';
import { cn } from '@/lib/utils';

// --- Types ---
interface PartnerService {
  id: string;
  type: 'supplies' | 'maintenance' | 'linens' | 'emergency';
  name: string;
  specialty: string;
  rating: number;
  reviews: number;
  responseTime: string; // "30 min"
  distance: string;
  pricing: {
    base: number;
    urgent: number;
  };
  integration: 'native' | 'whatsapp' | 'phone';
  image: string;
  available: boolean;
}

// --- Mock Data ---
const PARTNERS: PartnerService[] = [
  {
    id: '1',
    type: 'emergency',
    name: 'SOS Encanador 24h',
    specialty: 'Vazamentos & Entupimentos',
    rating: 4.9,
    reviews: 128,
    responseTime: '25 min',
    distance: '1.2 km',
    pricing: { base: 150, urgent: 250 },
    integration: 'whatsapp',
    image: 'https://images.unsplash.com/photo-1581578014828-569d34204d80?q=80&w=200&auto=format&fit=crop',
    available: true
  },
  {
    id: '2',
    type: 'linens',
    name: 'Miami Fresh Linens',
    specialty: 'Aluguel de Enxoval Premium',
    rating: 4.8,
    reviews: 856,
    responseTime: '2h',
    distance: '3.5 km',
    pricing: { base: 80, urgent: 120 },
    integration: 'native',
    image: 'https://images.unsplash.com/photo-1528641638210-97686522c071?q=80&w=200&auto=format&fit=crop',
    available: true
  },
  {
    id: '3',
    type: 'supplies',
    name: 'Clean Depot Express',
    specialty: 'Produtos Químicos & Papéis',
    rating: 4.7,
    reviews: 210,
    responseTime: 'Same Day',
    distance: '5.0 km',
    pricing: { base: 0, urgent: 25 }, // Base 0 means product price varies
    integration: 'native',
    image: 'https://images.unsplash.com/photo-1585421514738-01798e348b17?q=80&w=200&auto=format&fit=crop',
    available: true
  },
  {
    id: '4',
    type: 'maintenance',
    name: 'Fix-It All Repairs',
    specialty: 'Pequenos Reparos & Pintura',
    rating: 4.5,
    reviews: 89,
    responseTime: 'Agendado',
    distance: '2.8 km',
    pricing: { base: 100, urgent: 180 },
    integration: 'phone',
    image: 'https://images.unsplash.com/photo-1621905476059-5f3460b6452d?q=80&w=200&auto=format&fit=crop',
    available: false
  }
];

const CATEGORIES = [
  { id: 'all', label: 'Todos', icon: Filter },
  { id: 'emergency', label: 'SOS', icon: Zap },
  { id: 'linens', label: 'Enxoval', icon: Package },
  { id: 'maintenance', label: 'Manutenção', icon: Wrench },
  { id: 'supplies', label: 'Produtos', icon: Droplet },
];

export default function Partners() {
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const toast = useToast();

  const filteredPartners = PARTNERS.filter(p => {
    const matchesCategory = filter === 'all' || p.type === filter;
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.specialty.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleRequest = (partner: PartnerService) => {
    if (!partner.available) {
      toast.error(`${partner.name} não está disponível no momento.`);
      return;
    }

    if (partner.integration === 'whatsapp') {
      toast.success('Abrindo WhatsApp do parceiro...');
      // window.open(`https://wa.me/...`);
    } else if (partner.integration === 'native') {
      toast.success(`Pedido enviado para ${partner.name}! Chegada estimada: ${partner.responseTime}`);
    } else {
      toast.info(`Ligando para ${partner.name}...`);
    }
  };

  return (
    <MobileLayout title="Pur Partners" showBack>
      <div className="space-y-6 pt-4 pb-24">
        
        {/* Search Header */}
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input 
              placeholder="O que você precisa agora?" 
              className="pl-12 h-14 rounded-2xl bg-white border-slate-200 shadow-sm text-base"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {/* Categories Scroll */}
          <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-2">
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              const isActive = filter === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setFilter(cat.id)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm whitespace-nowrap transition-all border",
                    isActive 
                      ? "bg-slate-800 text-white border-slate-800 shadow-lg" 
                      : "bg-white text-slate-500 border-slate-100 hover:bg-slate-50"
                  )}
                >
                  <Icon className={cn("w-4 h-4", isActive ? "text-white" : "text-slate-400")} />
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* SOS Banner (Conditional) */}
        {filter === 'emergency' && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-rose-50 border border-rose-100 rounded-2xl p-4 flex items-start gap-4"
          >
            <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center flex-shrink-0 animate-pulse">
              <AlertTriangle className="w-6 h-6 text-rose-500" />
            </div>
            <div>
              <h3 className="font-bold text-rose-800">Modo Emergência</h3>
              <p className="text-xs text-rose-600 mt-1">
                Parceiros com tag <span className="font-bold">SOS</span> atendem em até 1 hora com taxa de urgência inclusa.
              </p>
            </div>
          </motion.div>
        )}

        {/* Partners List */}
        <div className="space-y-4">
          <AnimatePresence mode='popLayout'>
            {filteredPartners.length > 0 ? (
              filteredPartners.map((partner) => (
                <motion.div
                  key={partner.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="glass-panel-elevated p-4 rounded-3xl group"
                >
                  <div className="flex gap-4">
                    {/* Image */}
                    <div className="relative w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0 bg-slate-100">
                      <img src={partner.image} className={cn("w-full h-full object-cover", !partner.available && "grayscale")} alt={partner.name} />
                      {!partner.available && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <span className="text-[10px] font-bold text-white bg-black/50 px-2 py-0.5 rounded-full">Fechado</span>
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1">
                        <h3 className="font-bold text-slate-800 text-lg truncate pr-2">{partner.name}</h3>
                        <div className="flex items-center gap-1 bg-amber-50 px-1.5 py-0.5 rounded-md border border-amber-100">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span className="text-xs font-bold text-amber-700">{partner.rating}</span>
                        </div>
                      </div>
                      
                      <p className="text-xs font-medium text-slate-500 mb-2 truncate">{partner.specialty}</p>

                      <div className="flex items-center gap-3 mb-3">
                         <div className="flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-lg">
                            <Clock className="w-3 h-3" />
                            {partner.responseTime}
                         </div>
                         <div className="flex items-center gap-1 text-xs font-medium text-slate-400">
                            <MapPin className="w-3 h-3" />
                            {partner.distance}
                         </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div className="text-xs">
                       <p className="text-slate-400 font-medium">A partir de</p>
                       <p className="text-lg font-bold text-slate-800">R$ {partner.pricing.base}</p>
                    </div>

                    <Button 
                      onClick={() => handleRequest(partner)}
                      disabled={!partner.available}
                      className={cn(
                        "h-10 rounded-xl font-bold shadow-lg transition-all gap-2",
                        partner.type === 'emergency' 
                          ? "bg-rose-500 hover:bg-rose-600 text-white shadow-rose-200" 
                          : "bg-sky-500 hover:bg-sky-600 text-white shadow-sky-200"
                      )}
                    >
                      {partner.integration === 'native' ? 'Pedir Agora' : partner.integration === 'whatsapp' ? 'WhatsApp' : 'Ligar'}
                      {partner.type === 'emergency' ? <Zap className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
                    </Button>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="text-center py-10">
                <p className="text-slate-400 font-medium">Nenhum parceiro encontrado nesta categoria.</p>
                <Button variant="link" onClick={() => setFilter('all')} className="text-sky-500 font-bold">Ver todos</Button>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </MobileLayout>
  );
}