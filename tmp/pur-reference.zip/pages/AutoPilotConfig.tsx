import React, { useState } from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/components/ui/toaster';
import { AutoScheduler, currentConfig } from '@/services/autoScheduler';
import { 
  Bot, 
  Zap, 
  Map, 
  Clock, 
  ShieldAlert, 
  Users,
  ChevronRight,
  Sparkles,
  Save
} from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function AutoPilotConfig() {
  const { success } = useToast();
  const [config, setConfig] = useState(currentConfig);

  const handleSave = () => {
    AutoScheduler.updateConfig(config);
    success('Configurações do Auto-Pilot salvas!');
    if (navigator.vibrate) navigator.vibrate(50);
  };

  const togglePriority = (key: keyof typeof config.priorityRules) => {
    setConfig(prev => ({
      ...prev,
      priorityRules: {
        ...prev.priorityRules,
        [key]: prev.priorityRules[key] === 'high' ? 'normal' : 'high'
      }
    }));
  };

  return (
    <MobileLayout title="Pur Auto-Pilot" showBack>
      <div className="space-y-8 pt-4 pb-8 animate-fade-in-up">
        
        {/* Header Hero */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 to-violet-700 text-white shadow-xl shadow-indigo-200">
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full blur-3xl -mr-10 -mt-10" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-sky-400/20 rounded-full blur-3xl -ml-10 -mb-10" />
          
          <div className="p-6 relative z-10">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md">
                <Bot className="w-8 h-8 text-sky-200" />
              </div>
              <Switch 
                checked={config.enabled} 
                onCheckedChange={(c) => setConfig({...config, enabled: c})}
                className="data-[state=checked]:bg-emerald-400 data-[state=unchecked]:bg-slate-600"
              />
            </div>
            
            <h2 className="text-2xl font-bold mb-2">Automação Inteligente</h2>
            <p className="text-indigo-100 text-sm leading-relaxed opacity-90">
              O Auto-Pilot agenda jobs, atribui cleaners e otimiza rotas automaticamente assim que uma reserva entra.
            </p>
          </div>
        </div>

        {/* Priority Rules */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider px-2 ml-1 flex items-center gap-2">
            <Zap className="w-4 h-4" /> Regras de Prioridade
          </h3>
          
          <div className="grid gap-3">
            {[
              { id: 'superhostProperties', label: 'Propriedades Superhost', icon: Sparkles, color: 'text-amber-500' },
              { id: 'newProperties', label: 'Novas Propriedades', icon: Map, color: 'text-emerald-500' },
              { id: 'vipGuests', label: 'Hóspedes VIP', icon: Users, color: 'text-rose-500' }
            ].map((rule) => {
              const key = rule.id as keyof typeof config.priorityRules;
              const isActive = config.priorityRules[key] === 'high' || config.priorityRules[key] === 'extra-care';
              
              return (
                <Card 
                  key={rule.id}
                  onClick={() => togglePriority(key)}
                  className={cn(
                    "border-0 transition-all cursor-pointer",
                    isActive ? "bg-white shadow-md ring-2 ring-indigo-100" : "bg-white/60 hover:bg-white"
                  )}
                >
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className={cn("p-2 rounded-xl bg-slate-50", isActive && "bg-indigo-50")}>
                        <rule.icon className={cn("w-5 h-5", rule.color)} />
                      </div>
                      <span className={cn("font-bold text-sm", isActive ? "text-slate-800" : "text-slate-500")}>
                        {rule.label}
                      </span>
                    </div>
                    <div className={cn(
                      "text-xs font-bold px-3 py-1 rounded-full uppercase transition-colors",
                      isActive ? "bg-indigo-100 text-indigo-700" : "bg-slate-100 text-slate-400"
                    )}>
                      {isActive ? 'Alta' : 'Normal'}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Operational Constraints */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider px-2 ml-1 flex items-center gap-2">
            <Clock className="w-4 h-4" /> Operacional
          </h3>
          
          <div className="glass-panel p-6 rounded-3xl space-y-6">
            <div className="space-y-3">
              <div className="flex justify-between">
                <Label className="text-slate-600 font-bold">Buffer de Deslocamento</Label>
                <span className="text-sky-600 font-bold">{config.travelTimeBuffer} min</span>
              </div>
              <input 
                type="range" 
                min="15" 
                max="90" 
                step="15"
                value={config.travelTimeBuffer}
                onChange={(e) => setConfig({...config, travelTimeBuffer: parseInt(e.target.value)})}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-sky-500"
              />
              <p className="text-xs text-slate-400">Tempo extra adicionado entre jobs para trânsito.</p>
            </div>

            <div className="h-px bg-slate-100" />

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label className="text-slate-600 font-bold">Limite Diário / Cleaner</Label>
                <p className="text-xs text-slate-400">Evita sobrecarga da equipe</p>
              </div>
              <div className="flex items-center gap-3">
                 <button 
                   onClick={() => setConfig(p => ({...p, maxJobsPerDay: Math.max(1, p.maxJobsPerDay - 1)}))}
                   className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center font-bold text-slate-600"
                 >
                   -
                 </button>
                 <span className="w-4 text-center font-bold text-slate-800">{config.maxJobsPerDay}</span>
                 <button 
                   onClick={() => setConfig(p => ({...p, maxJobsPerDay: p.maxJobsPerDay + 1}))}
                   className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center font-bold text-slate-600"
                 >
                   +
                 </button>
              </div>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <Button 
          onClick={handleSave}
          className="w-full h-14 bg-slate-900 text-white rounded-2xl font-bold shadow-xl shadow-slate-300 gap-2 text-base mt-4 hover:bg-slate-800"
        >
          <Save className="w-5 h-5" />
          Salvar Configuração
        </Button>

      </div>
    </MobileLayout>
  );
}