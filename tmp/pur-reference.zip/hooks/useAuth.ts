import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseMock';

export const useAuth = () => {
  // TEMPORARY: Hardcoded user to disable login screen as requested.
  // This bypasses the Supabase check and immediately grants access.
  const MOCK_USER = {
    id: '1',
    email: 'marcio@pur.app', 
    user_metadata: { full_name: 'Marcio Silva' }
  };

  return { 
    user: MOCK_USER, 
    loading: false, 
    isAuthenticated: true 
  };

  /* 
  // Original Authentication Logic (Disabled)
  const [user, setUser] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    // Check initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (mounted) {
        setUser(session?.user ?? null);
        setLoading(false);
      }
    });

    // Subscribe to auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (mounted) {
        setUser(session?.user ?? null);
        setLoading(false);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  return { user, loading, isAuthenticated: !!user };
  */
};