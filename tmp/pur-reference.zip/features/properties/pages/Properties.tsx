import React, { useState, useEffect, useRef } from 'react';
import { MobileLayout } from '@/components/layout/MobileLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FluidSkeleton } from '@/components/ui/FluidSkeleton';
import { EmptyState } from '@/components/ui/EmptyState';
import { PropertyCard, Property } from '@/features/properties/components/PropertyCard';
import { SectionHeader } from '@/components/ui/SectionHeader';
import { 
  Plus, 
  Search, 
  MapPin, 
  Star,
  Home,
  Check,
  X,
  Upload,
  Image as ImageIcon,
  ArrowLeft,
  ArrowUpDown,
  Pencil,
  Activity
} from 'lucide-react';
import { useToast } from '@/components/ui/toaster';
import { motion, AnimatePresence, useAnimation } from 'framer-motion';
import { Label } from '@/components/ui/label';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

const initialPropertiesData: Property[] = [
  {
    id: 1,
    name: 'Casa Praia Miami',
    address: '123 Ocean Drive, Miami Beach',
    type: 'Casa',
    rating: 4.9,
    jobsThisMonth: 12,
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=800&auto=format&fit=crop',
    status: 'dirty',
    nextCleaning: 'Amanhã, 09:00',
    cleaningProgress: 0
  },
  {
    id: 2,
    name: 'Apartamento Downtown',
    address: '456 Brickell Ave, Miami',
    type: 'Apartamento',
    rating: 4.7,
    jobsThisMonth: 8,
    image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=800&auto=format&fit=crop',
    status: 'clean',
    nextCleaning: '05 Fev, 14:00',
    cleaningProgress: 100
  },
  {
    id: 3,
    name: 'Villa Orlando',
    address: '789 Disney Way, Orlando',
    type: 'Villa',
    rating: 4.8,
    jobsThisMonth: 15,
    image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=800&auto=format&fit=crop',
    status: 'occupied',
    nextCleaning: '03 Fev, 11:00',
    cleaningProgress: 100
  },
];

const StatPill = ({ icon: Icon, value, label }: { icon: any, value: string | number, label: string }) => (
    <div className="glass-panel py-3 px-4 flex flex-col items-center justify-center gap-1 hover:scale-105 transition-transform">
      <div className="flex items-center gap-2 text-slate-500 text-xs font-medium uppercase tracking-wider">
        <Icon className="h-3.5 w-3.5" />
        {label}
      </div>
      <p className="text-xl font-bold text-slate-800">{value}</p>
    </div>
);

const AnimatedPropertyCard: React.FC<{ 
  property: Property; 
  onEdit: (e: React.MouseEvent) => void;
  onPhoto: (e: React.MouseEvent) => void;
  onNavigate: () => void;
}> = ({ 
  property, 
  onEdit, 
  onPhoto,
  onNavigate 
}) => {
  const controls = useAnimation();
  const prevStatus = useRef(property.status);

  useEffect(() => {
    if (prevStatus.current !== property.status) {
      // Trigger haptic feedback on status change
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try { navigator.vibrate([50, 30, 50]); } catch (e) {}
      }

      controls.start({
        scale: [1, 1.03, 1], 
        opacity: [1, 0.9, 1], 
        boxShadow: [
            "0 4px 6px -1px rgba(0, 0, 0, 0.02)", 
            "0 0 0 4px rgba(56, 189, 248, 0.4)",
            "0 4px 6px -1px rgba(0, 0, 0, 0.02)"
        ],
        transition: { duration: 0.5, ease: "circOut" }
      });
      
      prevStatus.current = property.status;
    }
  }, [property.status, controls]);

  return (
    <motion.div
      animate={controls}
      layout
      className="relative rounded-3xl"
    >
      <PropertyCard 
        property={property}
        onClick={onNavigate} 
        onEdit={onEdit}
        onPhoto={onPhoto}
      />
    </motion.div>
  );
};

export default function Properties() {
  const [properties, setProperties] = useState<Property[]>(initialPropertiesData);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('Todos');
  const [sortBy, setSortBy] = useState<'name' | 'rating'>('name');
  const [isLoading, setIsLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const addButtonControls = useAnimation();

  const [formData, setFormData] = useState({
    name: '',
    address: '',
    type: 'Casa',
    image: '',
    status: 'clean' as Property['status']
  });
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const toast = useToast();

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500); 
    return () => clearTimeout(timer);
  }, []);

  const propertyTypes = ['Todos', 'Casa', 'Apartamento', 'Villa'];

  const filteredProperties = properties
    .filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
                          p.address.toLowerCase().includes(search.toLowerCase());
      const matchesType = filterType === 'Todos' || p.type === filterType;
      return matchesSearch && matchesType;
    })
    .sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });

  const handleEdit = (e: React.MouseEvent, property: Property) => {
    e.stopPropagation();
    
    // Pre-fill form
    setEditingId(property.id);
    setFormData({
      name: property.name,
      address: property.address,
      type: property.type,
      image: property.image,
      status: property.status
    });
    
    // Show form
    setShowAddForm(true);
    
    // Scroll to top smoothly
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePhoto = (e: React.MouseEvent, property: Property) => {
    e.stopPropagation();
    toast.info(`Câmera para ${property.name}`);
  };

  const toggleForm = () => {
    if (isSuccess) return; 
    
    if (showAddForm) {
      // Closing form
      setShowAddForm(false);
      setEditingId(null);
      setFormData({ name: '', address: '', type: 'Casa', image: '', status: 'clean' });
    } else {
      // Opening new form
      setShowAddForm(true);
      setEditingId(null);
      setFormData({ name: '', address: '', type: 'Casa', image: '', status: 'clean' });
    }
    
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const toggleSort = () => {
    const newSort = sortBy === 'name' ? 'rating' : 'name';
    setSortBy(newSort);
    toast.info(`Ordenando por: ${newSort === 'name' ? 'Nome' : 'Avaliação'}`);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, image: reader.result as string }));
        toast.success('Imagem carregada!');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProperty = () => {
    if (!formData.name || !formData.address) {
      toast.error('Preencha os campos obrigatórios');
      return;
    }

    if (editingId) {
      // Update existing property
      setProperties(prev => prev.map(p => 
        p.id === editingId 
          ? { 
              ...p, 
              name: formData.name, 
              address: formData.address, 
              type: formData.type, 
              image: formData.image || p.image,
              status: formData.status
            } 
          : p
      ));
      toast.success('Propriedade atualizada!');
    } else {
      // Create new property
      const newId = Math.max(...properties.map(p => p.id)) + 1;
      const propertyToAdd: Property = {
        id: newId,
        name: formData.name,
        address: formData.address,
        type: formData.type,
        rating: 5.0,
        jobsThisMonth: 0,
        image: formData.image || 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?q=80&w=800&auto=format&fit=crop',
        status: formData.status,
        nextCleaning: '-',
        cleaningProgress: 0
      };
      setProperties(prev => [propertyToAdd, ...prev]);
      toast.success('Propriedade adicionada!');
    }
    
    if (navigator.vibrate) navigator.vibrate(50);
    
    setShowAddForm(false);
    setIsSuccess(true);
    setEditingId(null);
    setFormData({ name: '', address: '', type: 'Casa', image: '', status: 'clean' });
    
    addButtonControls.start({
        scale: [1, 1.05, 1],
        opacity: [1, 0.8, 1],
        transition: { duration: 0.3, ease: "easeInOut" }
    });

    setTimeout(() => {
        setIsSuccess(false);
    }, 2000);
  };

  return (
    <MobileLayout showHeader={false} showBack={false}>
      <div className="space-y-8 pt-14">
        {/* Custom Header for Properties */}
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
                onClick={() => navigate('/dashboard')}
                className="w-11 h-11 rounded-full bg-white/50 flex items-center justify-center hover:bg-white hover:shadow-md transition-all border border-white/60"
            >
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </button>
            <h1 className="text-3xl font-bold text-slate-800">Propriedades</h1>
          </div>
          
          <motion.button 
            layout
            animate={addButtonControls}
            onClick={toggleForm}
            className={`
                px-5 py-2.5 rounded-full font-medium text-sm shadow-lg transition-all flex items-center gap-2 overflow-hidden
                ${isSuccess 
                  ? 'bg-emerald-500 text-white shadow-emerald-200 ring-2 ring-emerald-200'
                  : showAddForm 
                    ? 'bg-slate-200 text-slate-700 hover:bg-slate-300' 
                    : 'bg-gradient-to-r from-sky-500 to-blue-600 text-white hover:shadow-sky-200'
                }
            `}
          >
             <AnimatePresence mode="wait" initial={false}>
                {isSuccess ? (
                   <motion.div
                     key="success"
                     initial={{ opacity: 0, scale: 0.5, y: 10 }}
                     animate={{ opacity: 1, scale: 1, y: 0 }}
                     exit={{ opacity: 0, scale: 0.5, y: -10 }}
                     className="flex items-center gap-2"
                   >
                     <Check className="w-5 h-5" />
                     <span>Salvo!</span>
                   </motion.div>
                ) : (
                   <motion.div
                     key={showAddForm ? "cancel" : "add"}
                     initial={{ opacity: 0, scale: 0.5 }}
                     animate={{ opacity: 1, scale: 1 }}
                     exit={{ opacity: 0, scale: 0.5 }}
                     className="flex items-center gap-2"
                   >
                      {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                      <span>{showAddForm ? 'Cancelar' : 'Nova'}</span>
                   </motion.div>
                )}
             </AnimatePresence>
          </motion.button>
        </header>

        {/* Search and Sort */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative group flex-1">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-sky-500 transition-colors" />
              <Input
                placeholder="Buscar propriedade..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full h-14 pl-14 pr-5 rounded-2xl bg-white border border-slate-200 shadow-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-4 focus:ring-sky-100 focus:border-sky-300 transition-all text-base"
              />
            </div>
            
            <button
              onClick={toggleSort}
              className="h-14 w-14 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-500 hover:text-sky-600 hover:border-sky-200 hover:bg-sky-50 transition-all active:scale-95"
            >
              <ArrowUpDown className="h-6 w-6" />
            </button>
          </div>
          
          <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-2">
            {propertyTypes.map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`
                    px-5 py-2.5 rounded-full text-sm font-medium transition-all whitespace-nowrap
                    ${filterType === type 
                        ? 'bg-slate-800 text-white shadow-md shadow-slate-200' 
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                    }
                `}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Add/Edit Property Form */}
        <AnimatePresence>
          {showAddForm && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="glass-panel-elevated p-6 mb-4 border border-sky-100 shadow-xl space-y-6">
                <h3 className="font-bold text-xl flex items-center gap-2 text-slate-800">
                  <span className="w-8 h-8 rounded-full bg-sky-100 flex items-center justify-center">
                    {editingId ? <Pencil className="h-4 w-4 text-sky-600" /> : <Home className="h-4 w-4 text-sky-600" />}
                  </span>
                  {editingId ? 'Editar Propriedade' : 'Nova Propriedade'}
                </h3>
                
                <div className="space-y-4">
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="relative w-full h-48 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-100 transition-all overflow-hidden group"
                  >
                    {formData.image ? (
                      <>
                        <img src={formData.image} alt="Preview" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">
                            <p className="text-white font-medium flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full border border-white/30">
                                <ImageIcon className="h-5 w-5" /> Alterar foto
                            </p>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-sm mb-3 group-hover:scale-110 transition-transform">
                            <Upload className="h-6 w-6 text-slate-400" />
                        </div>
                        <p className="text-sm text-slate-500 font-medium">Toque para enviar foto</p>
                        <p className="text-xs text-slate-400 mt-1">Recomendado: 1600x1000px</p>
                      </>
                    )}
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept="image/*"
                      onChange={handleImageUpload}
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="propName" className="text-slate-600 ml-1">Nome da Propriedade</Label>
                      <Input 
                        id="propName" 
                        placeholder="Ex: Villa Sunshine" 
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                        className="bg-white/50 h-12"
                      />
                    </div>
                    
                    <div className="space-y-1.5">
                      <Label htmlFor="propAddress" className="text-slate-600 ml-1">Endereço</Label>
                      <Input 
                        id="propAddress" 
                        placeholder="Ex: 123 Palm Street" 
                        value={formData.address}
                        onChange={e => setFormData({...formData, address: e.target.value})}
                         className="bg-white/50 h-12"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-600 ml-1">Tipo de Imóvel</Label>
                      <div className="flex gap-2">
                         {['Casa', 'Apartamento', 'Villa'].map(type => (
                            <button
                                key={type}
                                onClick={() => setFormData({...formData, type})}
                                className={`flex-1 py-3 rounded-xl text-sm font-medium transition-all border ${formData.type === type ? 'bg-sky-500 text-white border-sky-500 shadow-md shadow-sky-200' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
                            >
                                {type}
                            </button>
                         ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-slate-600 ml-1">Status</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {['clean', 'dirty', 'occupied', 'maintenance'].map(s => (
                          <button
                            key={s}
                            onClick={() => setFormData({...formData, status: s as any})}
                            className={cn(
                              "py-2 rounded-xl text-xs font-bold uppercase transition-all border",
                              formData.status === s
                                ? "bg-slate-800 text-white border-slate-800"
                                : "bg-white text-slate-500 border-slate-200 hover:bg-slate-50"
                            )}
                          >
                            {s === 'dirty' ? 'Sujo' : s === 'clean' ? 'Limpo' : s === 'occupied' ? 'Ocupado' : 'Manut.'}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <Button onClick={handleSaveProperty} className="w-full h-12 gap-2 mt-4 bg-slate-900 hover:bg-slate-800 text-white shadow-lg">
                    {editingId ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                    {editingId ? 'Atualizar' : 'Salvar Imóvel'}
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Stats Pills */}
        <div className="grid grid-cols-3 gap-4">
          <StatPill icon={Home} value={properties.length} label="Total" />
          <StatPill icon={Star} value="4.8" label="Média" />
          <StatPill icon={MapPin} value="3" label="Cidades" />
        </div>

        {/* Properties List */}
        <div className="space-y-6 min-h-[300px] pb-4">
          <SectionHeader 
            title={filterType === 'Todos' ? 'Todas Propriedades' : `${filterType}s`} 
            count={filteredProperties.length}
          />

          {isLoading ? (
            <div className="space-y-5">
              <FluidSkeleton.PropertyCard />
              <FluidSkeleton.PropertyCard />
            </div>
          ) : filteredProperties.length > 0 ? (
            <AnimatePresence mode="popLayout">
                {filteredProperties.map((property) => (
                    <AnimatedPropertyCard
                        key={property.id}
                        property={property}
                        onEdit={(e) => handleEdit(e, property)}
                        onPhoto={(e) => handlePhoto(e, property)}
                        onNavigate={() => navigate(`/properties/${property.id}`)}
                    />
                ))}
            </AnimatePresence>
          ) : (
            <EmptyState 
              type="properties"
              title="Nenhum imóvel encontrado"
              description={`Não encontramos resultados para "${search}".`}
              onAction={() => setShowAddForm(true)}
              actionLabel="Adicionar agora"
            />
          )}
        </div>
      </div>
    </MobileLayout>
  );
}