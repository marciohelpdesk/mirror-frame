import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/components/ui/toaster';
import { 
  Camera, 
  Check, 
  ChevronLeft, 
  Clock, 
  Image as ImageIcon, 
  AlertCircle,
  MoreHorizontal,
  ChevronDown,
  ChevronUp,
  Maximize2,
  Minimize2,
  Mic,
  Music,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ArrowRight,
  Zap,
  FileText,
  Send,
  Share2,
  X,
  Hammer,
  Search,
  CheckCircle2,
  MapPin,
  Calendar as CalendarIcon,
  User,
  AlertTriangle
} from 'lucide-react';
import React, { useState, useRef, useMemo, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// --- Types ---
interface ChecklistItemType {
  id: number;
  category: string;
  text: string;
  photos: string[];
  completed: boolean;
}

type SoundscapeType = 'silent' | 'lofi' | 'nature';

// --- Mock Data ---
const initialItems: ChecklistItemType[] = [
  { id: 1, category: 'Entrada', text: 'Verificar fechadura inteligente', photos: [], completed: false },
  { id: 2, category: 'Entrada', text: 'Limpar tapete de entrada', photos: [], completed: false },
  { id: 3, category: 'Sala de Estar', text: 'Aspirar sofá e poltronas', photos: [], completed: false },
  { id: 4, category: 'Sala de Estar', text: 'Limpar TV e eletrônicos', photos: [], completed: false },
  { id: 5, category: 'Sala de Estar', text: 'Organizar almofadas', photos: [], completed: false },
  { id: 6, category: 'Cozinha', text: 'Limpar interior da geladeira', photos: [], completed: false },
  { id: 7, category: 'Cozinha', text: 'Verificar louça na máquina', photos: [], completed: false },
  { id: 8, category: 'Cozinha', text: 'Limpar bancadas e pia', photos: [], completed: false },
  { id: 9, category: 'Banheiro Principal', text: 'Higienizar vaso sanitário', photos: [], completed: false },
  { id: 10, category: 'Banheiro Principal', text: 'Limpar box e vidros', photos: [], completed: false },
  { id: 11, category: 'Banheiro Principal', text: 'Repor papel higiênico', photos: [], completed: false },
];

// --- COMPONENTS ---

const SoapBubbles = () => {
  const bubbles = Array.from({ length: 15 }).map((_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    size: Math.random() * 30 + 10,
    delay: Math.random() * 2,
    duration: Math.random() * 3 + 2,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
      {bubbles.map((bubble) => (
        <motion.div
          key={bubble.id}
          className="absolute rounded-full border border-white/40 shadow-sm backdrop-blur-[1px]"
          style={{
            left: bubble.left,
            width: bubble.size,
            height: bubble.size,
            background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.8), rgba(255,255,255,0.1) 60%, rgba(255,255,255,0.05) 100%)',
          }}
          initial={{ y: -100, x: 0, opacity: 0 }}
          animate={{ y: window.innerHeight + 100, opacity: [0, 1, 1, 0] }}
          transition={{ duration: bubble.duration, delay: bubble.delay, repeat: Infinity, ease: "linear" }}
        />
      ))}
    </div>
  );
};

const LiquidGauge = ({ value }: { value: number }) => {
  return (
    <div className="relative w-14 h-14 rounded-full border-2 border-sky-100 bg-white overflow-hidden shadow-inner shadow-slate-200">
      <div className="absolute inset-0 bg-slate-50 opacity-50"></div>
      <motion.div
        className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-sky-500 to-sky-400"
        initial={{ height: '0%' }}
        animate={{ height: `${value}%` }}
        transition={{ type: "spring", stiffness: 50, damping: 20 }}
      >
        <motion.div
          className="absolute -top-[120%] -left-[50%] w-[200%] h-[200%] bg-white/30 rounded-[40%]"
          animate={{ rotate: 360 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />
      </motion.div>
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <span className={cn("text-xs font-bold transition-colors duration-300 drop-shadow-sm", value > 55 ? "text-white" : "text-slate-600")}>
          {Math.round(value)}%
        </span>
      </div>
    </div>
  );
};

// --- MAIN PAGE COMPONENT ---

export default function Checklist() {
  const navigate = useNavigate();
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // State
  const [items, setItems] = useState<ChecklistItemType[]>(initialItems);
  const [activeItemId, setActiveItemId] = useState<number | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  
  // Report State
  const [showReport, setShowReport] = useState(false);
  const [lostAndFound, setLostAndFound] = useState('');
  const [damages, setDamages] = useState('');
  const [damagePhotos, setDamagePhotos] = useState<string[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [startTime] = useState(new Date());
  
  // Timer
  const [seconds, setSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);

  // Focus Mode State
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [currentFocusIndex, setCurrentFocusIndex] = useState(0);
  const [soundscape, setSoundscape] = useState<SoundscapeType>('silent');
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // --- Effects ---

  useEffect(() => {
    let interval: any;
    if (isTimerRunning) {
      interval = setInterval(() => setSeconds(s => s + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  // Grouping
  const groupedItems = useMemo(() => {
    const groups: Record<string, ChecklistItemType[]> = {};
    items.forEach(item => {
      if (!groups[item.category]) groups[item.category] = [];
      groups[item.category].push(item);
    });
    return groups;
  }, [items]);

  useEffect(() => {
    const initial: Record<string, boolean> = {};
    Object.keys(groupedItems).forEach(cat => initial[cat] = true);
    setExpandedCategories(initial);
  }, []);

  // --- Voice Recognition Logic ---
  useEffect(() => {
    if (!voiceEnabled || !isFocusMode) return;

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      toast.error('Seu navegador não suporta comandos de voz.');
      setVoiceEnabled(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = 'pt-BR';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const lastResult = event.results[event.results.length - 1];
      const command = lastResult[0].transcript.trim().toLowerCase();
      
      console.log('Voice Command:', command);
      
      if (command.includes('próximo') || command.includes('next')) {
        handleFocusNext();
      } else if (command.includes('foto') || command.includes('câmera')) {
        fileInputRef.current?.click();
      } else if (command.includes('ok') || command.includes('feito') || command.includes('check')) {
        const currentItem = items[currentFocusIndex];
        if (!currentItem.completed) handleToggleItem(currentItem.id);
      }
    };

    try {
      recognition.start();
    } catch (e) {
      console.error(e);
    }

    return () => {
      recognition.stop();
    };
  }, [voiceEnabled, isFocusMode, currentFocusIndex, items]);


  // --- Logic Helpers ---

  const completedCount = items.filter(i => i.completed).length;
  const progress = (completedCount / items.length) * 100;
  const isComplete = progress === 100;
  const allPhotos = items.flatMap(i => i.photos);

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({ ...prev, [category]: !prev[category] }));
  };

  const handleToggleItem = (id: number) => {
    if (navigator.vibrate) navigator.vibrate(15);
    
    setItems(prev => {
        const newItems = prev.map(item => item.id === id ? { ...item, completed: !item.completed } : item);
        return newItems;
    });
  };

  const handlePhotoCapture = (itemId: number, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setActiveItemId(itemId);
    fileInputRef.current?.click();
  };

  // Special handler for report damages photo
  const handleDamagePhoto = () => {
    setActiveItemId(-1); // Special ID for damages
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        
        if (activeItemId === -1) {
            // Adding to Damage Photos in Report
            setDamagePhotos(prev => [...prev, result]);
            toast.success('Foto da avaria adicionada!');
        } else {
            // Adding to Checklist Item
            const targetId = isFocusMode ? items[currentFocusIndex].id : activeItemId;
            if (targetId) {
                setItems(prev => prev.map(item => 
                  item.id === targetId 
                    ? { ...item, photos: [...item.photos, result], completed: true }
                    : item
                ));
                toast.success('Foto salva!');
            }
        }
        setActiveItemId(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFocusNext = () => {
    if (currentFocusIndex < items.length - 1) {
        setCurrentFocusIndex(prev => prev + 1);
    } else {
        setIsFocusMode(false);
        toast.success('Focus Flow finalizado!');
    }
  };

  const handleFinish = () => {
    if (!isComplete) {
      toast.error('Complete todos os itens antes de finalizar.');
      return;
    }
    setIsTimerRunning(false);
    setShowReport(true);
  };

  const handleSendReport = async () => {
    setIsSending(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsSending(false);
    setShowReport(false);
    toast.success('Relatório enviado ao proprietário com sucesso!');
    navigate('/jobs');
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDuration = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    return `${hours}h ${mins}min`;
  };

  const getFocusBackground = () => {
    switch (soundscape) {
        case 'nature': return 'bg-gradient-to-b from-emerald-900 to-teal-900';
        case 'lofi': return 'bg-gradient-to-b from-indigo-900 to-purple-900';
        default: return 'bg-gradient-to-b from-slate-900 to-slate-800';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col relative overflow-hidden">
      
      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* --- REPORT PREVIEW MODAL (MAISON PUR STYLE) --- */}
      <AnimatePresence>
        {showReport && (
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[150] bg-slate-100 flex flex-col"
          >
            {/* Action Header */}
            <div className="bg-white px-6 pt-safe-top pb-4 border-b border-slate-200 shadow-sm flex items-center justify-between sticky top-0 z-50">
              <Button variant="ghost" size="icon" onClick={() => setShowReport(false)} className="rounded-full">
                <ChevronLeft className="w-6 h-6 text-slate-600" />
              </Button>
              <h2 className="text-sm font-bold text-slate-500 uppercase tracking-widest">Visualizar Relatório</h2>
              <div className="w-10" />
            </div>

            <div className="flex-1 overflow-y-auto p-0 bg-slate-200">
              {/* --- MAISON PUR REPORT LAYOUT --- */}
              <div className="bg-white shadow-2xl min-h-[1000px] max-w-2xl mx-auto pb-12">
                
                {/* 1. Official Header */}
                <div className="bg-[#0A2540] text-white p-10 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-[80px] -mr-20 -mt-20 pointer-events-none" />
                    
                    <div className="flex flex-col items-center justify-center text-center space-y-4 relative z-10">
                        <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/50 mb-2">
                            <span className="font-display font-bold text-3xl italic">P</span>
                        </div>
                        <div>
                            <h1 className="text-4xl font-display font-bold tracking-tight mb-1">MAISON PUR</h1>
                            <p className="text-xs font-medium text-slate-400 tracking-[0.2em] uppercase">Excelência em Gestão de Propriedades</p>
                        </div>
                        <div className="h-px w-24 bg-cyan-500/50 my-4" />
                        <h2 className="text-lg font-bold text-cyan-400 uppercase tracking-widest">Relatório de Inspeção e Limpeza</h2>
                    </div>

                    <div className="mt-12 text-center">
                        <h3 className="text-3xl font-bold text-white mb-2">BLUE HOUSE</h3>
                        <p className="text-slate-400 font-medium">123 Ocean Drive, Miami</p>
                    </div>

                    {/* Data Grid */}
                    <div className="grid grid-cols-4 gap-4 mt-12 border-t border-white/10 pt-8">
                        <div className="bg-white/5 rounded-xl p-4 text-center backdrop-blur-sm">
                            <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Data</p>
                            <p className="font-mono text-sm font-bold">{format(new Date(), 'dd/MM/yyyy')}</p>
                        </div>
                        <div className="bg-white/5 rounded-xl p-4 text-center backdrop-blur-sm">
                            <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Início</p>
                            <p className="font-mono text-sm font-bold">{format(startTime, 'HH:mm')}</p>
                        </div>
                        <div className="bg-white/5 rounded-xl p-4 text-center backdrop-blur-sm">
                            <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Término</p>
                            <p className="font-mono text-sm font-bold">{format(new Date(), 'HH:mm')}</p>
                        </div>
                        <div className="bg-white/5 rounded-xl p-4 text-center backdrop-blur-sm">
                            <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Responsável</p>
                            <p className="font-mono text-sm font-bold truncate">Maria Santos</p>
                        </div>
                    </div>
                </div>

                {/* 2. Executive Summary */}
                <div className="p-8">
                    <h3 className="text-xl font-bold text-slate-800 uppercase tracking-tight mb-6 border-l-4 border-slate-800 pl-4">Resumo Executivo</h3>
                    
                    <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                        <div className="col-span-2 md:col-span-1 bg-emerald-50 rounded-xl p-4 text-center border-b-4 border-emerald-500">
                            <p className="text-3xl font-bold text-emerald-600">100%</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase mt-1">Conclusão</p>
                        </div>
                        <div className="bg-slate-50 rounded-xl p-4 text-center border-b-4 border-sky-500">
                            <p className="text-2xl font-bold text-sky-600">{items.length}/{items.length}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase mt-1">Tarefas</p>
                        </div>
                        <div className={cn("rounded-xl p-4 text-center border-b-4 transition-colors", damages ? "bg-rose-50 border-rose-500" : "bg-slate-50 border-emerald-500")}>
                            <p className={cn("text-2xl font-bold", damages ? "text-rose-600" : "text-emerald-600")}>{damages ? '1' : '0'}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase mt-1">Avarias</p>
                        </div>
                        <div className={cn("rounded-xl p-4 text-center border-b-4 transition-colors", lostAndFound ? "bg-amber-50 border-amber-500" : "bg-slate-50 border-slate-300")}>
                            <p className={cn("text-2xl font-bold", lostAndFound ? "text-amber-600" : "text-slate-400")}>{lostAndFound ? '1' : '0'}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase mt-1">Achados</p>
                        </div>
                        <div className="bg-slate-50 rounded-xl p-4 text-center border-b-4 border-sky-500">
                            <p className="text-2xl font-bold text-slate-700">{allPhotos.length + damagePhotos.length}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase mt-1">Fotos</p>
                        </div>
                        <div className="bg-slate-50 rounded-xl p-4 text-center border-b-4 border-slate-400">
                            <p className="text-xl font-bold text-slate-700">{formatDuration(seconds)}</p>
                            <p className="text-[10px] text-slate-500 font-bold uppercase mt-1">Duração</p>
                        </div>
                    </div>
                </div>

                {/* 3. Incidents & Notes Section */}
                <div className="px-8 pb-8 space-y-6">
                    <h3 className="text-xl font-bold text-slate-800 uppercase tracking-tight border-l-4 border-slate-800 pl-4">Ocorrências</h3>

                    {/* Damage Box */}
                    <div className="bg-rose-50 rounded-xl p-6 border border-rose-100">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="p-2 bg-rose-100 rounded-full text-rose-600">
                                <Hammer className="w-5 h-5" />
                            </div>
                            <h4 className="font-bold text-rose-800">Danos e Manutenção</h4>
                        </div>
                        <textarea 
                            value={damages}
                            onChange={(e) => setDamages(e.target.value)}
                            placeholder="Descreva itens quebrados, manchas ou necessidades de manutenção..."
                            className="w-full bg-white border border-rose-200 rounded-lg p-3 text-sm min-h-[80px] focus:outline-none focus:ring-2 focus:ring-rose-200 placeholder:text-rose-300/70 text-slate-700"
                        />
                        {/* Damage Photos */}
                        <div className="mt-3 flex gap-3 overflow-x-auto pb-2">
                            <button 
                                onClick={handleDamagePhoto}
                                className="w-16 h-16 rounded-lg border-2 border-dashed border-rose-300 bg-rose-100/50 flex flex-col items-center justify-center text-rose-500 hover:bg-rose-100 transition-colors flex-shrink-0"
                            >
                                <Camera className="w-5 h-5 mb-1" />
                                <span className="text-[9px] font-bold uppercase">Foto</span>
                            </button>
                            {damagePhotos.map((photo, i) => (
                                <div key={i} className="relative w-16 h-16 rounded-lg overflow-hidden border border-rose-200 flex-shrink-0">
                                    <img src={photo} className="w-full h-full object-cover" />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Lost & Found Box */}
                    <div className="bg-amber-50 rounded-xl p-6 border border-amber-100">
                        <div className="flex items-center gap-3 mb-3">
                            <div className="p-2 bg-amber-100 rounded-full text-amber-600">
                                <Search className="w-5 h-5" />
                            </div>
                            <h4 className="font-bold text-amber-800">Achados e Perdidos</h4>
                        </div>
                        <textarea 
                            value={lostAndFound}
                            onChange={(e) => setLostAndFound(e.target.value)}
                            placeholder="Descreva itens deixados pelo hóspede (local e item)..."
                            className="w-full bg-white border border-amber-200 rounded-lg p-3 text-sm min-h-[80px] focus:outline-none focus:ring-2 focus:ring-amber-200 placeholder:text-amber-300/70 text-slate-700"
                        />
                    </div>
                </div>

                {/* 4. Detailed Checklist */}
                <div className="px-8 pb-12">
                    <div className="flex items-center justify-between mb-6 border-l-4 border-slate-800 pl-4">
                        <h3 className="text-xl font-bold text-slate-800 uppercase tracking-tight">Checklist de Inspeção</h3>
                    </div>

                    <div className="space-y-8">
                        {Object.entries(groupedItems).map(([category, rawCatItems]) => {
                            const catItems = rawCatItems as ChecklistItemType[];
                            const catPhotos = catItems.flatMap(i => i.photos);
                            const total = catItems.length;
                            
                            return (
                                <div key={category} className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                                    {/* Category Header (Green Bar style) */}
                                    <div className="bg-emerald-500 px-6 py-3 flex justify-between items-center text-white">
                                        <h4 className="font-bold text-lg">{category}</h4>
                                        <span className="bg-emerald-600 px-3 py-1 rounded-full text-xs font-bold">{total}/{total}</span>
                                    </div>

                                    {/* Items List */}
                                    <div className="p-6 space-y-3">
                                        {catItems.map(item => (
                                            <div key={item.id} className="flex items-start gap-3">
                                                <div className="mt-0.5">
                                                    <Check className="w-4 h-4 text-emerald-500 stroke-[3px]" />
                                                </div>
                                                <span className="text-sm text-slate-600 font-medium">{item.text}</span>
                                            </div>
                                        ))}
                                    </div>

                                    {/* Category Photos */}
                                    {catPhotos.length > 0 && (
                                        <div className="px-6 pb-6">
                                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2">FOTOS DE VERIFICAÇÃO — {category.toUpperCase()}</p>
                                            <div className="grid grid-cols-4 gap-2">
                                                {catPhotos.map((photo, i) => (
                                                    <div key={i} className="aspect-square rounded-lg overflow-hidden border border-slate-100 bg-slate-50">
                                                        <img src={photo} className="w-full h-full object-cover" />
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* 5. Footer / Signature */}
                <div className="px-10 pb-20 pt-10 text-center border-t border-slate-100">
                    <div className="flex flex-col items-center justify-center mb-8">
                        <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-xl flex items-center justify-center shadow-lg mb-3">
                            <span className="font-display font-bold text-2xl text-white italic">P</span>
                        </div>
                        <h2 className="text-xl font-bold text-slate-800">MAISON PUR</h2>
                        <p className="text-xs text-slate-400">Excelência em Gestão de Propriedades</p>
                    </div>

                    <div className="w-64 mx-auto border-b border-slate-300 pb-2 mb-2">
                        <p className="font-display text-2xl text-slate-600 font-bold opacity-50 italic">Maria Santos</p>
                    </div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Assinatura do Responsável</p>
                    
                    <div className="mt-6 inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-4 py-2 rounded-full border border-emerald-100">
                        <CheckCircle2 className="w-4 h-4" />
                        <span className="text-xs font-bold">VERIFICADO DIGITALMENTE</span>
                    </div>
                </div>

              </div>
            </div>

            {/* Sticky Actions */}
            <div className="p-4 bg-white border-t border-slate-200 pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
              <Button 
                onClick={handleSendReport}
                disabled={isSending}
                className={cn(
                  "w-full h-14 rounded-2xl text-lg font-bold shadow-xl transition-all gap-3",
                  isSending ? "bg-slate-100 text-slate-400" : "bg-[#0A2540] text-white hover:bg-slate-800 shadow-slate-300"
                )}
              >
                {isSending ? (
                  "Gerando PDF..."
                ) : (
                  <>
                    <Send className="w-5 h-5" /> Enviar Relatório
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- FOCUS MODE OVERLAY (Existing) --- */}
      <AnimatePresence>
        {isFocusMode && (
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className={cn(
                    "fixed inset-0 z-[100] flex flex-col text-white transition-colors duration-1000",
                    getFocusBackground()
                )}
            >
                {/* 1. Focus Header */}
                <div className="flex items-center justify-between p-6">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => setIsFocusMode(false)}
                        className="rounded-full bg-white/10 hover:bg-white/20 text-white"
                    >
                        <Minimize2 className="w-6 h-6" />
                    </Button>
                    
                    <div className="flex items-center gap-3 bg-white/10 px-4 py-2 rounded-full backdrop-blur-md">
                        <Clock className="w-4 h-4 text-white/70" />
                        <span className="font-mono font-bold">{formatTime(seconds)}</span>
                    </div>

                    <div className="flex gap-2">
                        <Button
                             variant="ghost" 
                             size="icon" 
                             onClick={() => setVoiceEnabled(!voiceEnabled)}
                             className={cn("rounded-full transition-all", voiceEnabled ? "bg-red-500/80 text-white animate-pulse" : "bg-white/10 text-white/50")}
                        >
                            <Mic className="w-5 h-5" />
                        </Button>
                        <Button
                             variant="ghost" 
                             size="icon" 
                             onClick={() => {
                                 const modes: SoundscapeType[] = ['silent', 'lofi', 'nature'];
                                 const nextIdx = (modes.indexOf(soundscape) + 1) % modes.length;
                                 setSoundscape(modes[nextIdx]);
                                 setIsPlaying(true);
                             }}
                             className="rounded-full bg-white/10 hover:bg-white/20 text-white"
                        >
                            {soundscape === 'silent' ? <VolumeX className="w-5 h-5" /> : <Music className="w-5 h-5" />}
                        </Button>
                    </div>
                </div>

                {/* 2. Audio Visualizer (Fake) */}
                <div className="h-12 flex items-center justify-center gap-1.5 opacity-50">
                    {soundscape !== 'silent' && Array.from({length: 12}).map((_, i) => (
                        <motion.div 
                            key={i}
                            className="w-1.5 bg-white rounded-full"
                            animate={{ 
                                height: isPlaying ? [10, Math.random() * 30 + 10, 10] : 8 
                            }}
                            transition={{ 
                                duration: 0.5, 
                                repeat: Infinity, 
                                delay: i * 0.1 
                            }}
                        />
                    ))}
                    {soundscape === 'silent' && <span className="text-xs font-medium tracking-widest uppercase opacity-50">Modo Silencioso</span>}
                </div>

                {/* 3. Main Content Card */}
                <div className="flex-1 flex flex-col justify-center px-6 pb-12 relative">
                    {/* Progress Indicator */}
                    <div className="absolute top-4 left-6 right-6 flex gap-1">
                        {items.map((_, idx) => (
                            <div 
                                key={idx} 
                                className={cn(
                                    "h-1 flex-1 rounded-full transition-colors duration-300",
                                    idx < currentFocusIndex ? "bg-white/80" : 
                                    idx === currentFocusIndex ? "bg-white" : "bg-white/20"
                                )}
                            />
                        ))}
                    </div>

                    <AnimatePresence mode='wait'>
                        <motion.div
                            key={currentFocusIndex}
                            initial={{ x: 50, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            exit={{ x: -50, opacity: 0 }}
                            className="space-y-6 text-center"
                        >
                            <span className="inline-block px-3 py-1 rounded-lg bg-white/20 text-sm font-bold uppercase tracking-wider backdrop-blur-sm">
                                {items[currentFocusIndex].category}
                            </span>
                            
                            <h2 className="text-3xl font-bold leading-tight drop-shadow-md">
                                {items[currentFocusIndex].text}
                            </h2>

                            {/* Photo Gallery in Focus Mode */}
                            {items[currentFocusIndex].photos.length > 0 && (
                                <div className="flex justify-center gap-3 py-4">
                                    {items[currentFocusIndex].photos.map((p, i) => (
                                        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} key={i} className="w-20 h-20 rounded-xl border-2 border-white/50 overflow-hidden shadow-lg">
                                            <img src={p} className="w-full h-full object-cover" />
                                        </motion.div>
                                    ))}
                                </div>
                            )}

                        </motion.div>
                    </AnimatePresence>
                </div>

                {/* 4. Large Action Controls */}
                <div className="bg-white/10 backdrop-blur-xl border-t border-white/10 p-6 pb-safe">
                    <div className="flex items-center gap-4 max-w-md mx-auto">
                        <Button
                             onClick={() => handlePhotoCapture(items[currentFocusIndex].id)}
                             className="h-16 w-16 rounded-2xl bg-white/20 hover:bg-white/30 border border-white/20 flex-shrink-0"
                        >
                            <Camera className="w-7 h-7" />
                        </Button>
                        
                        <Button
                            onClick={() => {
                                handleToggleItem(items[currentFocusIndex].id);
                                handleFocusNext();
                            }}
                            className={cn(
                                "flex-1 h-16 rounded-2xl text-lg font-bold shadow-xl transition-all",
                                items[currentFocusIndex].completed 
                                    ? "bg-emerald-500 hover:bg-emerald-600 text-white"
                                    : "bg-white text-slate-900 hover:bg-slate-100"
                            )}
                        >
                            {items[currentFocusIndex].completed ? (
                                <span className="flex items-center gap-2">
                                    Concluído <Check className="w-6 h-6" />
                                </span>
                            ) : (
                                <span className="flex items-center gap-2">
                                    Próximo <ArrowRight className="w-6 h-6" />
                                </span>
                            )}
                        </Button>
                    </div>
                </div>
            </motion.div>
        )}
      </AnimatePresence>


      {/* --- NORMAL MODE UI --- */}
      
      {/* Show Soap Bubbles when complete */}
      <AnimatePresence>
        {isComplete && !isFocusMode && !showReport && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <SoapBubbles />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full hover:bg-slate-100 -ml-2">
              <ChevronLeft className="h-6 w-6 text-slate-700" />
            </Button>
            <div>
              <h1 className="text-lg font-bold text-slate-800 leading-tight">Checklist</h1>
              <p className="text-xs text-slate-500 font-medium">Casa Praia Miami</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
             <Button 
                onClick={() => setIsFocusMode(true)}
                className="bg-slate-900 text-white hover:bg-slate-800 h-9 px-3 rounded-lg text-xs font-bold gap-2 shadow-md shadow-slate-300"
             >
                <Zap className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                Focus Flow
             </Button>
          </div>
        </div>
      </div>

      {/* List Content - Updated Glass Panel Style */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 pb-32">
        {Object.entries(groupedItems).map(([category, rawCatItems]) => {
          const isExpanded = expandedCategories[category];
          const itemsList = rawCatItems as ChecklistItemType[];
          const completedInCategory = itemsList.filter(i => i.completed).length;
          const totalInCategory = itemsList.length;
          const isCategoryComplete = completedInCategory === totalInCategory;

          return (
            <div key={category} className="space-y-3">
              <button 
                onClick={() => toggleCategory(category)}
                className="w-full flex items-center justify-between py-2 px-1 group"
              >
                <div className="flex items-center gap-2">
                  <h3 className={cn("text-sm font-bold uppercase tracking-wider transition-colors", isCategoryComplete ? "text-emerald-600" : "text-slate-500 group-hover:text-slate-700")}>
                    {category}
                  </h3>
                  {isCategoryComplete && <Check className="h-4 w-4 text-emerald-500" />}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-slate-400">{completedInCategory}/{totalInCategory}</span>
                  {isExpanded ? <ChevronUp className="h-4 w-4 text-slate-400" /> : <ChevronDown className="h-4 w-4 text-slate-400" />}
                </div>
              </button>

              <AnimatePresence initial={false}>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden space-y-3"
                  >
                      {itemsList.map((item) => {
                        const isChecked = item.completed;
                        const hasPhotos = item.photos.length > 0;

                        return (
                          <div 
                            key={item.id} 
                            onClick={() => handleToggleItem(item.id)}
                            className={cn(
                                "glass-panel p-4 flex items-start gap-4 transition-all group active:scale-[0.98] cursor-pointer",
                                isChecked ? "bg-slate-50 border-emerald-100" : "bg-white hover:border-slate-300"
                            )}
                          >
                              <div className={cn("flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all mt-0.5", isChecked ? "bg-emerald-500 border-emerald-500" : "border-slate-300 bg-white")}>
                                {isChecked && <Check className="h-3.5 w-3.5 text-white stroke-[3px]" />}
                              </div>
                              
                              <div className="flex-1 min-w-0">
                                <p className={cn("text-sm font-semibold transition-colors leading-relaxed", isChecked ? "text-slate-400 line-through" : "text-slate-800")}>
                                  {item.text}
                                </p>
                                {hasPhotos && (
                                  <div className="flex gap-2 mt-3 overflow-x-auto hide-scrollbar">
                                    {item.photos.map((photo, i) => (
                                      <div key={i} className="relative w-12 h-12 rounded-lg overflow-hidden border border-slate-200 flex-shrink-0">
                                        <img src={photo} className="w-full h-full object-cover" alt="evidence" />
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>

                              <div className="flex gap-2">
                                <button
                                  onClick={(e) => handlePhotoCapture(item.id, e)}
                                  className={cn(
                                      "p-2.5 rounded-xl transition-all border", 
                                      hasPhotos 
                                        ? "bg-sky-50 text-sky-600 border-sky-100" 
                                        : "bg-slate-50 text-slate-400 border-transparent hover:bg-sky-50 hover:text-sky-500"
                                  )}
                                >
                                  <Camera className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={(e) => { e.stopPropagation(); toast.info("Reportar problema..."); }}
                                  className="p-2.5 rounded-xl bg-slate-50 text-slate-400 border border-transparent hover:bg-rose-50 hover:text-rose-500 transition-all"
                                >
                                  <AlertTriangle className="h-4 w-4" />
                                </button>
                              </div>
                          </div>
                        );
                      })}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* Footer Actions */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-200 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] z-50 pb-safe">
        <div className="flex items-center gap-4 max-w-lg mx-auto">
          <div className="flex items-center gap-3 flex-1">
             <LiquidGauge value={progress} />
             <div className="flex flex-col">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Progresso</span>
                <span className="text-sm font-semibold text-slate-700">{progress === 100 ? 'Tudo pronto!' : 'Em andamento'}</span>
             </div>
          </div>
          <Button 
            className={cn("h-14 px-8 rounded-2xl font-bold shadow-lg transition-all text-base", isComplete ? "bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-200 scale-105" : "bg-slate-800 text-slate-400 cursor-not-allowed")}
            onClick={handleFinish}
            disabled={!isComplete}
          >
            {isComplete ? 'Finalizar' : 'Pendente'}
          </Button>
        </div>
      </div>
    </div>
  );
}