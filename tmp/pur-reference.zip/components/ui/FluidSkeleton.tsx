import React from 'react';
import { cn } from '@/lib/utils';

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
}

export const Skeleton = ({ className, ...props }: SkeletonProps) => {
  return (
    <div
      className={cn(
        "bg-slate-200/50 animate-pulse rounded-lg",
        className
      )}
      {...props}
    />
  );
};

export const PropertyCardSkeleton = () => (
  <div className="glass-panel p-4 space-y-3 relative overflow-hidden">
    {/* Fluid Shimmer Effect */}
    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent translate-x-[-100%] animate-shimmer pointer-events-none z-10" />
    
    <div className="flex items-start gap-3">
      {/* Icon Placeholder */}
      <Skeleton className="w-16 h-16 rounded-xl flex-shrink-0" />
      
      <div className="flex-1 space-y-2">
        {/* Title */}
        <Skeleton className="h-5 w-3/4 bg-slate-200" />
        {/* Subtitle */}
        <Skeleton className="h-3 w-1/2 bg-slate-200" />
        
        {/* Badges */}
        <div className="flex gap-2 pt-1">
          <Skeleton className="h-4 w-16 rounded-full" />
          <Skeleton className="h-4 w-12 rounded-full" />
        </div>
      </div>
      
      {/* Arrow */}
      <Skeleton className="h-5 w-5 rounded-full" />
    </div>
    
    {/* Footer line */}
    <div className="pt-2 border-t border-slate-100">
      <Skeleton className="h-3 w-1/3" />
    </div>
  </div>
);

export const FluidSkeleton = {
  PropertyCard: PropertyCardSkeleton,
  Basic: Skeleton
};