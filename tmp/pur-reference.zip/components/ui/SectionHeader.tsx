import React from 'react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ChevronRight } from 'lucide-react';

interface SectionHeaderProps {
  title: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  count?: number;
  className?: string;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({ 
  title, 
  action, 
  count, 
  className 
}) => {
  return (
    <div className={cn("flex items-center justify-between", className)}>
      <div className="flex items-center gap-3">
        <h3 className="text-xl font-bold text-slate-800 tracking-tight">
          {title}
        </h3>
        {count !== undefined && (
          <span className="text-sm font-bold text-slate-500 bg-slate-100/80 px-2.5 py-0.5 rounded-lg border border-slate-200/50">
            {count}
          </span>
        )}
      </div>

      {action && (
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-sky-600 hover:text-sky-700 hover:bg-sky-50 h-9 px-4 rounded-full font-medium gap-1 group"
          onClick={action.onClick}
        >
          {action.label}
          <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
        </Button>
      )}
    </div>
  );
};