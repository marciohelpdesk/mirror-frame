import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

// Artistic Illustrations (SVG Components)
const HouseIllustration = () => (
  <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="100" cy="100" r="80" fill="#E0F2FE" fillOpacity="0.5" />
    <path d="M60 110L100 70L140 110" stroke="#3B82F6" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M70 110V150H130V110" stroke="#3B82F6" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <rect x="90" y="120" width="20" height="30" stroke="#3B82F6" strokeWidth="4" />
    <circle cx="150" cy="60" r="10" fill="#FDE68A" />
    <path d="M40 150H160" stroke="#CBD5E1" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const CleaningIllustration = () => (
  <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="100" cy="100" r="80" fill="#E0F2FE" fillOpacity="0.5" />
    <path d="M80 70L120 70" stroke="#3B82F6" strokeWidth="4" strokeLinecap="round" />
    <path d="M85 70V120H115V70" stroke="#3B82F6" strokeWidth="4" />
    <path d="M70 120H130L125 150H75L70 120Z" stroke="#3B82F6" strokeWidth="4" fill="#EFF6FF" />
    <path d="M120 50L135 65" stroke="#F59E0B" strokeWidth="3" strokeLinecap="round" />
    <path d="M130 40L145 55" stroke="#F59E0B" strokeWidth="3" strokeLinecap="round" />
  </svg>
);

const MoneyIllustration = () => (
  <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="100" cy="100" r="80" fill="#E0F2FE" fillOpacity="0.5" />
    <rect x="60" y="80" width="80" height="50" rx="4" stroke="#3B82F6" strokeWidth="4" fill="#EFF6FF" />
    <circle cx="100" cy="105" r="12" stroke="#3B82F6" strokeWidth="3" />
    <path d="M140 70L150 60" stroke="#10B981" strokeWidth="3" strokeLinecap="round" />
    <path d="M150 75L160 65" stroke="#10B981" strokeWidth="3" strokeLinecap="round" />
  </svg>
);

const DefaultIllustration = () => (
  <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
    <circle cx="100" cy="100" r="70" stroke="#CBD5E1" strokeWidth="2" strokeDasharray="8 8" />
    <path d="M90 90L110 110" stroke="#94A3B8" strokeWidth="4" strokeLinecap="round" />
    <path d="M110 90L90 110" stroke="#94A3B8" strokeWidth="4" strokeLinecap="round" />
  </svg>
);

interface EmptyStateProps {
  type: 'jobs' | 'properties' | 'earnings' | 'default';
  title?: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState = ({ 
  type, 
  title, 
  description, 
  actionLabel, 
  onAction 
}: EmptyStateProps) => {
  const illustrations = {
    jobs: <CleaningIllustration />,
    properties: <HouseIllustration />,
    earnings: <MoneyIllustration />,
    default: <DefaultIllustration />
  };

  const defaultTexts = {
    jobs: { title: 'Nenhum job encontrado', desc: 'Comece agendando sua primeira limpeza' },
    properties: { title: 'Nenhuma propriedade', desc: 'Adicione imóveis para gerenciar' },
    earnings: { title: 'Sem dados financeiros', desc: 'Seus ganhos aparecerão aqui' },
    default: { title: 'Nada encontrado', desc: 'Tente ajustar seus filtros' }
  };

  const text = defaultTexts[type] || defaultTexts.default;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="flex flex-col items-center justify-center py-12 text-center"
    >
      <motion.div 
        initial={{ y: 10 }}
        animate={{ y: 0 }}
        transition={{ 
          duration: 2, 
          repeat: Infinity, 
          repeatType: "reverse", 
          ease: "easeInOut" 
        }}
        className="w-48 h-48 mb-4 opacity-90"
      >
        {illustrations[type] || illustrations.default}
      </motion.div>
      
      <h3 className="text-xl font-bold text-slate-800 mb-2">
        {title || text.title}
      </h3>
      
      <p className="text-slate-500 mb-8 max-w-[250px] leading-relaxed text-sm">
        {description || text.desc}
      </p>
      
      {onAction && (
        <Button 
          onClick={onAction}
          className="shadow-lg shadow-primary/20 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-xl h-12 px-8"
        >
          {actionLabel || `Adicionar ${type === 'properties' ? 'Imóvel' : 'Item'}`}
          <Plus className="ml-2 h-4 w-4" />
        </Button>
      )}
    </motion.div>
  );
};