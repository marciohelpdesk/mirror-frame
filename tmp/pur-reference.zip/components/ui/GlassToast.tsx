import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, Info, X, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface ToastMessage {
  title: string;
  description?: string;
}

interface GlassToastProps {
  id: number;
  message: ToastMessage;
  type: ToastType;
  onClose: (id: number) => void;
  duration?: number;
}

const icons = {
  success: <CheckCircle className="w-6 h-6 text-emerald-500" />,
  error: <XCircle className="w-6 h-6 text-rose-500" />,
  info: <Info className="w-6 h-6 text-sky-500" />,
  warning: <AlertTriangle className="w-6 h-6 text-amber-500" />
};

const gradients = {
  success: "from-emerald-500 to-emerald-400",
  error: "from-rose-500 to-rose-400",
  info: "from-sky-500 to-blue-500",
  warning: "from-amber-500 to-orange-400"
};

export const GlassToast: React.FC<GlassToastProps> = ({ id, message, type, onClose, duration = 3000 }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: 100, scale: 0.95 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      className="glass-panel-elevated pointer-events-auto relative w-full max-w-sm overflow-hidden shadow-2xl backdrop-blur-xl border border-white/60"
    >
      <div className="p-4 flex items-start gap-4">
        {/* Icon Container */}
        <div className="flex-shrink-0 mt-0.5 p-2 rounded-full bg-white/50 backdrop-blur-md shadow-sm">
          {icons[type]}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 pt-1">
          <h4 className="font-semibold text-slate-800 text-sm leading-none mb-1">
            {message.title}
          </h4>
          {message.description && (
            <p className="text-xs text-slate-500 leading-relaxed opacity-90">
              {message.description}
            </p>
          )}
        </div>

        {/* Close Button */}
        <button 
          onClick={() => onClose(id)}
          className="flex-shrink-0 p-1 hover:bg-black/5 rounded-full transition-colors -mr-1 -mt-1"
        >
          <X className="w-4 h-4 text-slate-400" />
        </button>
      </div>
      
      {/* Progress Bar */}
      <motion.div 
        className={cn("absolute bottom-0 left-0 h-1 bg-gradient-to-r", gradients[type])}
        initial={{ width: "100%" }}
        animate={{ width: "0%" }}
        transition={{ duration: duration / 1000, ease: "linear" }}
        onAnimationComplete={() => onClose(id)}
      />
    </motion.div>
  );
};