import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';
import { AnimatePresence } from 'framer-motion';
import { GlassToast, ToastType, ToastMessage } from './GlassToast';

interface Toast {
  id: number;
  message: ToastMessage;
  type: ToastType;
}

type ToastInput = string | ToastMessage;

interface ToastContextType {
  success: (msg: ToastInput) => void;
  error: (msg: ToastInput) => void;
  info: (msg: ToastInput) => void;
  warning: (msg: ToastInput) => void;
  remove: (id: number) => void;
}

const ToastContext = createContext<ToastContextType | null>(null);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = useCallback((input: ToastInput, type: ToastType) => {
    const id = Date.now();
    
    // Normalize input to ToastMessage object
    const message: ToastMessage = typeof input === 'string' 
      ? { title: input } 
      : input;

    setToasts(prev => [...prev, { id, message, type }]);
  }, []);

  const removeToast = useCallback((id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Memoize the context value to prevent consumers from re-rendering/re-running effects
  // when the toast list changes, unless addToast/removeToast references change (which they don't).
  const contextValue = useMemo(() => ({
    success: (msg: ToastInput) => addToast(msg, 'success'),
    error: (msg: ToastInput) => addToast(msg, 'error'),
    info: (msg: ToastInput) => addToast(msg, 'info'),
    warning: (msg: ToastInput) => addToast(msg, 'warning'),
    remove: removeToast
  }), [addToast, removeToast]);

  return (
    <ToastContext.Provider value={contextValue}>
      {children}
      
      {/* Toast Container */}
      <div className="fixed top-4 left-0 right-0 z-[100] flex flex-col items-center gap-3 px-4 pointer-events-none">
        <AnimatePresence mode='popLayout'>
          {toasts.map(toast => (
            <GlassToast 
              key={toast.id}
              id={toast.id}
              message={toast.message}
              type={toast.type}
              onClose={removeToast}
            />
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used within ToastProvider');
  return context;
};

// Fallback for non-hook usage (less common in React 18+ strict mode but kept for legacy compat)
export const toast = {
  success: (msg: string) => console.log('Toast success:', msg),
  error: (msg: string) => console.error('Toast error:', msg),
  info: (msg: string) => console.log('Toast info:', msg),
};