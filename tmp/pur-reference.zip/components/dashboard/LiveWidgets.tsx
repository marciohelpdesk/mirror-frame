import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, DollarSign, Clock, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

// --- Mock Hook for Live Data ---
const useLiveEarnings = () => {
  const [data, setData] = useState({
    total: 4834,
    trend: 12.5,
    history: [30, 45, 35, 60, 50, 75, 65, 85]
  });

  useEffect(() => {
    // Simulate live updates every 5 seconds
    const interval = setInterval(() => {
      setData(prev => {
        const newValue = prev.total + Math.floor(Math.random() * 50) - 10;
        const newHistoryPoint = prev.history[prev.history.length - 1] + (Math.random() * 20 - 10);
        return {
          ...prev,
          total: newValue,
          history: [...prev.history.slice(1), newHistoryPoint]
        };
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return data;
};

// --- Helper Components ---

const Sparkline = ({ data, color = "#10b981" }: { data: number[], color?: string }) => {
  const height = 50;
  const width = 120;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  
  const points = data.map((val, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((val - min) / range) * height;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible opacity-90">
      <defs>
        <linearGradient id="gradient" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <motion.path
        d={`M ${points}`}
        fill="none"
        stroke={color}
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 1.5, ease: "easeOut" }}
      />
       <motion.path
        d={`M ${points} L ${width},${height} L 0,${height} Z`}
        fill="url(#gradient)"
        stroke="none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5, delay: 0.5 }}
      />
    </svg>
  );
};

// --- Main Components ---

export const EarningsCard = () => {
  const earnings = useLiveEarnings();
  const isPositive = earnings.trend >= 0;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel-elevated rounded-3xl p-7 space-y-6 relative overflow-hidden"
    >
      {/* Background decorativo sutil */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-sky-200/30 to-emerald-200/20 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
      
      {/* Header do card com espaçamento */}
      <div className="flex justify-between items-start relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-200">
            <DollarSign className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="text-slate-500 text-sm font-medium">Ganhos do Mês</p>
            <p className="text-slate-400 text-xs">Atualizado agora</p>
          </div>
        </div>
        
        <div className={cn(
          "flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-sm font-bold shadow-sm backdrop-blur-sm",
          isPositive 
            ? "bg-emerald-50 border-emerald-100 text-emerald-700" 
            : "bg-rose-50 border-rose-100 text-rose-700"
        )}>
           {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
          <span>{Math.abs(earnings.trend).toFixed(1)}%</span>
        </div>
      </div>

      {/* Valor com espaçamento superior */}
      <div className="relative z-10 space-y-2">
        <motion.h2 
          className="text-5xl font-bold text-slate-800 tracking-tight"
          key={earnings.total} // animate on change
          initial={{ scale: 0.95, opacity: 0.8 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.4 }}
        >
          R$ {earnings.total.toLocaleString()}
        </motion.h2>
        <p className="text-slate-400 text-sm font-medium">Meta: R$ 6.000</p>
      </div>

      {/* Gráfico com margem superior generosa */}
      <div className="pt-2 w-full">
        <Sparkline data={earnings.history} color="#10b981" />
      </div>
    </motion.div>
  );
};

export const StatsGrid = ({ pending, completed }: { pending: number, completed: number }) => {
  const stats = [
    { 
      id: 'pending',
      icon: Clock, 
      label: "Pendentes", 
      value: pending, 
      color: "orange" 
    },
    { 
      id: 'completed',
      icon: CheckCircle2, 
      label: "Concluídos", 
      value: completed, 
      color: "emerald" 
    }
  ];

  return (
    <div className="grid grid-cols-2 gap-5">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        // Mapping colors safely
        const colorClasses = stat.color === 'orange' 
          ? { bg: 'bg-orange-100', text: 'text-orange-600' }
          : { bg: 'bg-emerald-100', text: 'text-emerald-600' };

        return (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
            className="glass-panel rounded-2xl p-5 space-y-4"
          >
            {/* Ícone com container maior */}
            <div className="flex justify-between items-start">
              <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center", colorClasses.bg)}>
                <Icon className={cn("w-5 h-5", colorClasses.text)} />
              </div>
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                Hoje
              </span>
            </div>
            
            {/* Número com espaçamento */}
            <div className="space-y-1">
              <p className="text-3xl font-bold text-slate-800">{stat.value}</p>
              <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};