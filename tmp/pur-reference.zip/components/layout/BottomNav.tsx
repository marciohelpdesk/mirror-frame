import React, { useEffect, useState } from 'react';
import { Home, Calendar, Building2, BarChart2, User } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const navItems = [
  { to: '/dashboard', icon: Home, label: 'Início' },
  { to: '/jobs', icon: Calendar, label: 'Jobs' },
  { to: '/properties', icon: Building2, label: 'Imóveis' },
  { to: '/analytics', icon: BarChart2, label: 'Análise' },
  { to: '/settings', icon: User, label: 'Perfil' },
];

export const BottomNav = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('');

  useEffect(() => {
    const active = navItems.find(item => location.pathname.startsWith(item.to));
    if (active) setActiveTab(active.to);
  }, [location.pathname]);

  const handlePress = (path: string) => {
    navigate(path);
    if (navigator.vibrate) try { navigator.vibrate(5); } catch (e) {}
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 pb-safe z-50 px-6 pb-6 pointer-events-none">
      <div className="glass-panel-elevated rounded-3xl px-2 py-3 pointer-events-auto shadow-2xl shadow-sky-900/10 border-white/80">
        <nav className="flex justify-around items-center">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.to;
            
            return (
              <button
                key={item.to}
                onClick={() => handlePress(item.to)}
                className="relative flex flex-col items-center gap-1.5 py-2 px-2 w-full min-w-[64px] focus:outline-none group"
              >
                {/* Active Indicator */}
                {isActive && (
                  <motion.div
                    layoutId="activeTabIndicator"
                    className="absolute -top-3 w-10 h-1 rounded-full bg-gradient-to-r from-sky-400 to-blue-500 shadow-[0_0_10px_rgba(56,189,248,0.5)]"
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}
                
                <motion.div
                  animate={{ 
                    scale: isActive ? 1.1 : 1,
                    y: isActive ? -2 : 0
                  }}
                  transition={{ type: "spring", stiffness: 400 }}
                >
                  <Icon 
                    className={cn(
                      "w-6 h-6 transition-colors duration-300", 
                      isActive ? "text-sky-600 stroke-[2.5px]" : "text-slate-400 stroke-[2px] group-hover:text-slate-500"
                    )} 
                  />
                </motion.div>
                
                <motion.span 
                  animate={{ 
                    opacity: isActive ? 1 : 0.7,
                    scale: isActive ? 1 : 0.95
                  }}
                  className={cn(
                    "text-[11px] font-medium transition-colors duration-300",
                    isActive ? "text-sky-700" : "text-slate-400 group-hover:text-slate-500"
                  )}
                >
                  {item.label}
                </motion.span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};