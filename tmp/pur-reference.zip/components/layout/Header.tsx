import React from 'react';
import { ChevronLeft, Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/toaster';

interface HeaderProps {
  title?: string;
  showBack?: boolean;
  rightAction?: React.ReactNode;
  className?: string;
}

export const Header = ({ title, showBack = false, rightAction, className }: HeaderProps) => {
  const navigate = useNavigate();
  const toast = useToast();

  return (
    <header className={cn(
      "glass-panel-elevated mx-4 mt-4 px-4 py-3 flex items-center justify-between z-50",
      className
    )}>
      <div className="flex items-center gap-3">
        {showBack && (
          <button 
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-xl flex items-center justify-center hover:bg-black/5 transition-colors"
          >
            <ChevronLeft className="h-5 w-5 text-foreground" />
          </button>
        )}
        {title && (
          <h1 className="text-lg font-semibold text-foreground">{title}</h1>
        )}
      </div>
      
      <div className="flex items-center gap-2">
        {rightAction || (
          <button 
            onClick={() => toast.info('Sem novas notificações')}
            className="w-10 h-10 rounded-xl relative flex items-center justify-center hover:bg-black/5 transition-colors"
          >
            <Bell className="h-5 w-5 text-foreground" />
            <span className="absolute top-2 right-3 w-2 h-2 bg-destructive rounded-full" />
          </button>
        )}
      </div>
    </header>
  );
};