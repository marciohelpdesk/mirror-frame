import React from 'react';
import { BottomNav } from './BottomNav';
import { Header } from './Header';
import { useLocation } from 'react-router-dom';
import { PageTransition } from './PageTransition';
import { cn } from '@/lib/utils';

interface MobileLayoutProps {
  children: React.ReactNode;
  title?: string;
  showNav?: boolean;
  showHeader?: boolean;
  rightAction?: React.ReactNode;
  showBack?: boolean;
  className?: string;
}

export const MobileLayout: React.FC<MobileLayoutProps> = ({ 
  children, 
  title, 
  showNav = true, 
  showHeader = true,
  rightAction,
  showBack,
  className
}) => {
  const location = useLocation();
  
  // Don't show nav on certain pages if passed as default
  const hideNavPaths = ['/checklist'];
  const shouldShowNav = showNav && !hideNavPaths.some(path => location.pathname.startsWith(path));

  const shouldShowBack = showBack !== undefined ? showBack : location.pathname !== '/dashboard';

  return (
    // bg-transparent ensures the body's Florida Sunset gradient is visible
    <div className="mobile-frame relative min-h-screen flex flex-col bg-transparent">
      {/* Content */}
      <div className="relative z-10 flex flex-col flex-1 h-full">
        {showHeader && (
          <Header 
            title={title} 
            rightAction={rightAction}
            className="flex-shrink-0"
            showBack={shouldShowBack}
          />
        )}
        
        {/* Adjusted padding to px-6 (24px) for airier feel */}
        <main className={cn(
          "flex-1 px-6 pb-28 overflow-x-hidden", 
          showHeader ? "pt-4" : "pt-0", // If no header, let the page handle top padding (usually pt-14)
          className
        )}>
          <PageTransition key={location.pathname}>
            {children}
          </PageTransition>
        </main>

        {shouldShowNav && <BottomNav />}
      </div>
    </div>
  );
};