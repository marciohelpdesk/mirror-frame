import React from 'react';
import { motion } from 'framer-motion';

interface PageTransitionProps {
  children: React.ReactNode;
}

export const PageTransition: React.FC<PageTransitionProps> = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.99 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -5, scale: 0.99 }}
      transition={{ 
        duration: 0.5, 
        ease: [0.22, 1, 0.36, 1] // "Ocean" ease: fast start, slow sophisticated finish
      }}
      className="w-full h-full"
    >
      {children}
    </motion.div>
  );
};