import { motion } from 'framer-motion';
import { Home, Clock, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface Job {
  id: number;
  property: string;
  time: string;
  status: 'completed' | 'in-progress' | 'pending';
}

interface JobCardProps {
    job: Job;
    onClick?: () => void;
}

export const JobCard = ({ job, onClick }: JobCardProps) => {
  return (
    <motion.button
      whileHover={{ scale: 1.01, y: -2 }}
      whileTap={{ scale: 0.99 }}
      onClick={onClick}
      className="w-full glass-panel rounded-2xl p-6 flex items-center gap-5 cursor-pointer group text-left transition-all hover:shadow-lg hover:shadow-sky-100"
    >
      <div className="relative flex-shrink-0">
        <div className={cn(
          "w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-colors",
          job.status === 'completed' && "bg-gradient-to-br from-emerald-400 to-emerald-500 shadow-emerald-200",
          job.status === 'in-progress' && "bg-gradient-to-br from-sky-400 to-blue-500 shadow-sky-200 animate-pulse-slow",
          job.status === 'pending' && "bg-gradient-to-br from-amber-400 to-orange-500 shadow-amber-200"
        )}>
          <Home className="w-7 h-7 text-white" />
        </div>
        <div className={cn(
          "absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center",
          job.status === 'completed' && "bg-emerald-500",
          job.status === 'in-progress' && "bg-sky-500",
          job.status === 'pending' && "bg-amber-500"
        )}>
          <div className="w-2 h-2 rounded-full bg-white" />
        </div>
      </div>

      <div className="flex-1 space-y-1.5">
        <h3 className="font-bold text-slate-800 text-lg group-hover:text-sky-600 transition-colors leading-tight">
          {job.property}
        </h3>
        <div className="flex items-center gap-2 text-slate-500">
          <Clock className="w-4 h-4 text-sky-400" />
          <span className="text-sm font-medium">{job.time}</span>
        </div>
      </div>

      <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-sky-50 transition-colors flex-shrink-0">
        <ChevronRight className="h-5 w-5 text-slate-400 group-hover:text-sky-500 group-hover:translate-x-0.5 transition-transform" />
      </div>
    </motion.button>
  );
};