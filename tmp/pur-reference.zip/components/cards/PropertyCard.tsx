import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  MapPin, 
  Star, 
  ChevronRight, 
  Camera, 
  Edit,
  Calendar
} from 'lucide-react';
import { cn } from '@/lib/utils';

export interface Property {
  id: number;
  name: string;
  address: string;
  type: string;
  rating: number;
  jobsThisMonth: number;
  image: string;
  status: 'clean' | 'dirty' | 'occupied' | 'maintenance';
  nextCleaning?: string;
  cleaningProgress?: number;
}

interface PropertyCardProps {
  property: Property;
  onClick?: () => void;
  onEdit?: (e: React.MouseEvent) => void;
  onPhoto?: (e: React.MouseEvent) => void;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, onClick, onEdit, onPhoto }) => {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="glass-panel-elevated rounded-3xl overflow-hidden cursor-pointer group relative shadow-sm hover:shadow-2xl hover:shadow-sky-100 transition-all duration-300"
    >
      {/* Image Section - Aspect Ratio 16:10 */}
      <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
        <motion.img
          src={property.image}
          alt={property.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent opacity-80" />
        
        {/* Floating Status Badge */}
        <div className="absolute top-4 left-4 z-10">
          <span className={cn(
            "px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wide backdrop-blur-md shadow-lg",
            property.status === 'dirty' ? "bg-rose-500/90 text-white" :
            property.status === 'clean' ? "bg-emerald-500/90 text-white" :
            property.status === 'occupied' ? "bg-amber-500/90 text-white" :
            "bg-slate-500/90 text-white"
          )}>
            {property.status === 'dirty' ? 'Sujo' : 
             property.status === 'clean' ? 'Limpo' :
             property.status === 'occupied' ? 'Ocupado' : 'Manutenção'}
          </span>
        </div>
        
        {/* Floating Actions */}
        <div className="absolute bottom-4 right-4 flex gap-2 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 translate-y-2 group-hover:translate-y-0">
          {onEdit && (
            <button 
                onClick={onEdit}
                className="w-9 h-9 rounded-full bg-white/90 text-slate-700 flex items-center justify-center hover:bg-white hover:scale-110 transition-all shadow-lg"
            >
                <Edit className="h-4 w-4" />
            </button>
          )}
          {onPhoto && (
            <button 
                onClick={onPhoto}
                className="w-9 h-9 rounded-full bg-white/90 text-slate-700 flex items-center justify-center hover:bg-white hover:scale-110 transition-all shadow-lg"
            >
                <Camera className="h-4 w-4" />
            </button>
          )}
        </div>
        
        {/* Rating */}
        <div className="absolute bottom-4 left-4 flex items-center gap-1.5 z-10">
            <Star className="h-4 w-4 fill-amber-400 text-amber-400 drop-shadow-sm" />
            <span className="text-white font-bold text-sm drop-shadow-md">{property.rating}</span>
        </div>
      </div>

      {/* Content Section - More padding */}
      <div className="p-6 space-y-4">
        <div className="flex justify-between items-start">
          <div className="flex-1 min-w-0 mr-4 space-y-1">
            <h3 className="font-bold text-slate-800 text-xl group-hover:text-sky-600 transition-colors truncate leading-tight">
                {property.name}
            </h3>
            <div className="flex items-center gap-1.5 text-sm text-slate-500 truncate">
                <MapPin className="h-4 w-4 text-sky-400 flex-shrink-0" />
                {property.address}
            </div>
          </div>
          <ChevronRight className="w-6 h-6 text-slate-300 group-hover:text-sky-500 group-hover:translate-x-1 transition-all" />
        </div>
        
        <div className="h-px bg-slate-100" />

        <div className="space-y-2">
            <div className="flex justify-between items-center text-sm">
                <span className="flex items-center gap-2 text-slate-600 font-medium">
                    <Calendar className="h-4 w-4 text-sky-500" />
                    Próxima: <span className="text-slate-500 font-normal">{property.nextCleaning}</span>
                </span>
                {property.cleaningProgress !== undefined && (
                    <span className="font-bold text-sky-600">{property.cleaningProgress}%</span>
                )}
            </div>
            
            {property.cleaningProgress !== undefined && (
                <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                        className="h-full bg-gradient-to-r from-sky-400 to-blue-500 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${property.cleaningProgress}%` }} 
                    />
                </div>
            )}
        </div>
      </div>
    </motion.div>
  );
};