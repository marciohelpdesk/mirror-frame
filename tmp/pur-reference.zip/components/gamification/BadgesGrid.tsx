import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Lock, Zap, Award, Image, Sunrise } from 'lucide-react';

export interface BadgeItem {
  id: string;
  icon: any;
  name: string;
  desc: string;
  unlocked: boolean;
  tier: string;
}

export const BADGES: BadgeItem[] = [
  { 
    id: 'speed_demon', 
    icon: Zap, 
    name: 'Relâmpago', 
    desc: '10 jobs abaixo do tempo estimado',
    unlocked: true,
    tier: 'gold' 
  },
  { 
    id: 'perfectionist', 
    icon: Award, 
    name: 'Perfeccionista', 
    desc: '50 checklists 100% completos',
    unlocked: true,
    tier: 'platinum'
  },
  { 
    id: 'photo_pro', 
    icon: Image, 
    name: 'Fotógrafo Pro', 
    desc: 'Galeria com 100+ fotos alta qualidade',
    unlocked: false,
    tier: 'silver'
  },
  { 
    id: 'early_bird', 
    icon: Sunrise, 
    name: 'Madrugador', 
    desc: '20 jobs iniciados antes das 8h',
    unlocked: false,
    tier: 'bronze'
  }
];

export const BadgesGrid = () => {
  return (
    <div className="grid grid-cols-2 gap-4">
      {BADGES.map((badge, index) => (
        <BadgeCard key={badge.id} badge={badge} index={index} />
      ))}
    </div>
  );
};

interface BadgeCardProps {
  badge: BadgeItem;
  index: number;
}

const BadgeCard: React.FC<BadgeCardProps> = ({ badge, index }) => {
  const Icon = badge.icon;
  
  const getGradient = (tier: string) => {
    switch(tier) {
      case 'gold': return 'from-amber-200 via-yellow-400 to-amber-500 text-amber-900 border-amber-200';
      case 'platinum': return 'from-slate-200 via-slate-300 to-slate-400 text-slate-800 border-slate-200';
      case 'silver': return 'from-gray-100 via-gray-200 to-gray-300 text-gray-700 border-gray-200';
      default: return 'from-orange-100 via-orange-200 to-orange-300 text-orange-800 border-orange-200';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.1 }}
      className={cn(
        "relative p-4 rounded-3xl border flex flex-col items-center text-center gap-3 overflow-hidden",
        badge.unlocked 
          ? "bg-white border-slate-100 shadow-sm" 
          : "bg-slate-50 border-slate-100 opacity-80"
      )}
    >
      {/* Icon Container */}
      <div className={cn(
        "w-16 h-16 rounded-full flex items-center justify-center shadow-lg relative",
        badge.unlocked 
          ? `bg-gradient-to-br ${getGradient(badge.tier)}`
          : "bg-slate-200"
      )}>
        {badge.unlocked ? (
            <Icon className="w-7 h-7 drop-shadow-sm" />
        ) : (
            <Lock className="w-6 h-6 text-slate-400" />
        )}
        
        {/* Shine Effect for Unlocked */}
        {badge.unlocked && (
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-white/40 to-transparent pointer-events-none" />
        )}
      </div>

      <div className="space-y-1 z-10">
        <h4 className={cn(
            "font-bold text-sm",
            badge.unlocked ? "text-slate-800" : "text-slate-400"
        )}>
            {badge.name}
        </h4>
        <p className="text-[10px] text-slate-400 leading-tight px-1 font-medium">
            {badge.desc}
        </p>
      </div>

      {!badge.unlocked && (
        <div className="absolute inset-0 bg-slate-50/50 backdrop-blur-[1px] z-0" />
      )}
    </motion.div>
  );
};