import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Trophy, Zap, Camera, Star, Clock, TrendingUp } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export interface ProMetrics {
  overallScore: number;
  consistencyScore: number;      // % de jobs no horário
  qualityRating: number;         // Média das avaliações (0-5)
  speedEfficiency: number;       // Tempo estimado vs real (%)
  photoQuality: number;          // Score de IA (0-100)
  streakDays: number;            // Dias consecutivos
}

interface ProScoreCardProps {
  metrics: ProMetrics;
  compact?: boolean;
  onClick?: () => void;
}

export const ProScoreCard: React.FC<ProScoreCardProps> = ({ metrics, compact = false, onClick }) => {
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-500 from-emerald-500 to-teal-400';
    if (score >= 80) return 'text-sky-500 from-sky-500 to-blue-400';
    if (score >= 70) return 'text-amber-500 from-amber-500 to-orange-400';
    return 'text-rose-500 from-rose-500 to-red-400';
  };

  const scoreColorClass = getScoreColor(metrics.overallScore);

  if (compact) {
    return (
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onClick}
        className="relative w-full overflow-hidden rounded-3xl bg-white p-1 shadow-lg shadow-slate-200/50 group"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-white to-slate-100 opacity-50" />
        <div className="relative flex items-center gap-4 p-4 rounded-[1.25rem] border border-slate-100 bg-white/60 backdrop-blur-md">
          {/* Circular Score Mini */}
          <div className="relative w-14 h-14 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-100"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
              />
              <motion.path
                className={cn("drop-shadow-sm", scoreColorClass.split(' ')[0])}
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="url(#gradient-mini)"
                strokeWidth="3"
                strokeDasharray={`${metrics.overallScore}, 100`}
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
               <defs>
                <linearGradient id="gradient-mini" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" className={cn(scoreColorClass.split(' ')[1].replace('from-', 'stop-'))} />
                  <stop offset="100%" className={cn(scoreColorClass.split(' ')[2].replace('to-', 'stop-'))} />
                </linearGradient>
              </defs>
            </svg>
            <span className="absolute text-sm font-bold text-slate-700">{metrics.overallScore}</span>
          </div>

          <div className="flex-1 text-left">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
              Pur Pro Score
              <Trophy className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            </h3>
            <p className="text-xs text-slate-500 font-medium">Top 10% da região</p>
          </div>

          <div className="flex flex-col items-end">
            <div className="flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">
              <TrendingUp className="w-3 h-3" />
              +2.4
            </div>
          </div>
        </div>
      </motion.button>
    );
  }

  return (
    <div className="w-full space-y-6">
      {/* Main Large Score Card */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative overflow-hidden rounded-[2.5rem] bg-slate-900 text-white shadow-2xl shadow-slate-900/20"
      >
        {/* Background Effects */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-sky-500/20 rounded-full blur-[80px] -mr-16 -mt-16 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px] -ml-16 -mb-16 pointer-events-none" />
        
        <div className="relative p-8 flex flex-col items-center justify-center text-center space-y-6">
          <div className="space-y-1">
             <h2 className="text-lg font-medium text-slate-300 uppercase tracking-widest text-[10px]">Performance Global</h2>
             <div className="flex items-center justify-center gap-2">
                <span className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400">
                  {metrics.overallScore}
                </span>
                <span className="text-2xl text-slate-500 font-light">/100</span>
             </div>
          </div>

          <div className="grid grid-cols-2 gap-3 w-full">
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center gap-2 backdrop-blur-md">
               <div className="p-2 bg-amber-500/20 rounded-full text-amber-400">
                 <Zap className="w-5 h-5 fill-amber-400" />
               </div>
               <div className="text-center">
                 <span className="block text-xl font-bold">{metrics.streakDays}</span>
                 <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Dias Streak</span>
               </div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center gap-2 backdrop-blur-md">
               <div className="p-2 bg-emerald-500/20 rounded-full text-emerald-400">
                 <Star className="w-5 h-5 fill-emerald-400" />
               </div>
               <div className="text-center">
                 <span className="block text-xl font-bold">{metrics.qualityRating}</span>
                 <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Avaliação</span>
               </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Detailed Metrics Grid */}
      <div className="grid gap-4">
         <MetricRow 
            icon={Clock} 
            label="Pontualidade & Consistência" 
            value={metrics.consistencyScore} 
            color="bg-sky-500"
            subLabel="Chegadas no horário"
         />
         <MetricRow 
            icon={TrendingUp} 
            label="Eficiência de Tempo" 
            value={metrics.speedEfficiency} 
            color="bg-indigo-500"
            subLabel="Jobs dentro do prazo estimado"
         />
         <MetricRow 
            icon={Camera} 
            label="Qualidade Fotográfica" 
            value={metrics.photoQuality} 
            color="bg-rose-500"
            subLabel="Clareza e iluminação das evidências"
         />
      </div>
    </div>
  );
};

const MetricRow = ({ icon: Icon, label, value, color, subLabel }: { icon: any, label: string, value: number, color: string, subLabel: string }) => (
  <motion.div 
    initial={{ opacity: 0, x: -10 }}
    whileInView={{ opacity: 1, x: 0 }}
    className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm"
  >
    <div className="flex items-center gap-4 mb-3">
      <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-md", color)}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-center mb-0.5">
           <h4 className="font-bold text-slate-800 text-sm">{label}</h4>
           <span className="font-bold text-slate-800">{value}%</span>
        </div>
        <p className="text-xs text-slate-400 font-medium">{subLabel}</p>
      </div>
    </div>
    <Progress value={value} className="h-2 rounded-full bg-slate-100" />
  </motion.div>
);