import { SyncedReservation } from './airbnbSync';

// --- Types ---

export interface Cleaner {
  id: string;
  name: string;
  rating: number;
  status: 'available' | 'busy' | 'off';
  currentLocation: string; // Mock location
  preferredProperties: string[];
}

export interface AutoScheduleConfig {
  enabled: boolean;
  maxJobsPerDay: number;
  travelTimeBuffer: number; // minutes
  priorityRules: {
    superhostProperties: 'high' | 'normal';
    newProperties: 'high' | 'normal';
    vipGuests: 'extra-care' | 'normal';
  };
}

export interface ScheduledJobResult {
  cleanerId: string;
  cleanerName: string;
  startTime: Date;
  endTime: Date;
  tags: string[];
  aiReasoning: string; // Explanation for the user
}

// --- Mock Data ---

const MOCK_CLEANERS: Cleaner[] = [
  { 
    id: 'c1', 
    name: 'Maria Santos', 
    rating: 4.9, 
    status: 'available', 
    currentLocation: 'Downtown',
    preferredProperties: ['Casa Praia Miami']
  },
  { 
    id: 'c2', 
    name: 'João Silva', 
    rating: 4.7, 
    status: 'available', 
    currentLocation: 'North Beach',
    preferredProperties: ['Apartamento Downtown']
  },
  { 
    id: 'c3', 
    name: 'Ana Costa', 
    rating: 4.8, 
    status: 'busy', 
    currentLocation: 'Brickell',
    preferredProperties: []
  }
];

// Default Configuration
export let currentConfig: AutoScheduleConfig = {
  enabled: true,
  maxJobsPerDay: 2,
  travelTimeBuffer: 45, // 45 mins travel buffer
  priorityRules: {
    superhostProperties: 'high',
    newProperties: 'high',
    vipGuests: 'extra-care'
  }
};

// --- Service Logic ---

export const AutoScheduler = {
  
  // Updates the configuration (called from UI)
  updateConfig: (newConfig: Partial<AutoScheduleConfig>) => {
    currentConfig = { ...currentConfig, ...newConfig };
  },

  getConfig: () => currentConfig,

  // The main brain function
  processReservation: async (reservation: SyncedReservation): Promise<ScheduledJobResult> => {
    // 1. Calculate Timings based on Check-out
    const cleaningDurationHours = 3; // Standard
    const checkOutTime = new Date(reservation.checkOut);
    checkOutTime.setHours(11, 0, 0, 0); // Force 11 AM checkout standard

    const startTime = new Date(checkOutTime);
    // Add buffer if configured (e.g., start 30 mins after checkout to be safe)
    startTime.setMinutes(startTime.getMinutes() + 30); 

    const endTime = new Date(startTime);
    endTime.setHours(endTime.getHours() + cleaningDurationHours);

    // 2. Determine Priority & Tags
    const tags: string[] = ['Auto-Scheduled'];
    
    // Logic: If guest has 5 stars or special request, mark as VIP
    if (reservation.previousReviews.length > 0 || reservation.specialRequests) {
      if (currentConfig.priorityRules.vipGuests === 'extra-care') {
        tags.push('VIP Guest');
      }
    }

    // Logic: Property specific priorities
    if (reservation.propertyName.includes('Villa') && currentConfig.priorityRules.superhostProperties === 'high') {
      tags.push('High Priority');
    }

    // 3. Find Best Cleaner
    // Filter available
    const availableCleaners = MOCK_CLEANERS.filter(c => c.status !== 'off');
    
    // Sort by: Preference -> Rating -> Random
    availableCleaners.sort((a, b) => {
      const aPref = a.preferredProperties.includes(reservation.propertyName) ? 1 : 0;
      const bPref = b.preferredProperties.includes(reservation.propertyName) ? 1 : 0;
      if (aPref !== bPref) return bPref - aPref; // Higher preference first
      return b.rating - a.rating; // Higher rating second
    });

    const bestCleaner = availableCleaners[0] || MOCK_CLEANERS[0];

    // 4. Generate Reasoning
    let reasoning = `Atribuído a ${bestCleaner.name} (Rating ${bestCleaner.rating})`;
    if (bestCleaner.preferredProperties.includes(reservation.propertyName)) {
      reasoning += ` pois é especialista nesta propriedade.`;
    } else {
      reasoning += ` baseado na proximidade e disponibilidade.`;
    }

    // Simulate async processing
    await new Promise(resolve => setTimeout(resolve, 500));

    return {
      cleanerId: bestCleaner.id,
      cleanerName: bestCleaner.name,
      startTime,
      endTime,
      tags,
      aiReasoning: reasoning
    };
  }
};