export interface SyncedReservation {
  airbnbConfirmationCode: string;
  guestName: string;
  checkIn: Date;
  checkOut: Date;
  guestCount: number;
  guestProfileImage?: string;
  previousReviews: string[];
  specialRequests: string;
  propertyName: string; // Matches internal property name
  listingImage?: string;
}

// Mock data generator relative to current date
const addDays = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d;
};

export const mockReservations: SyncedReservation[] = [
  {
    airbnbConfirmationCode: 'HMW123456',
    guestName: 'Sarah Connor',
    checkIn: addDays(2), // Arriving in 2 days
    checkOut: addDays(5),
    guestCount: 3,
    guestProfileImage: 'https://randomuser.me/api/portraits/women/44.jpg',
    previousReviews: ['Hóspede muito limpo', 'Comunicação fácil'],
    specialRequests: 'Late check-in requested (20:00). Allergies to feathers.',
    propertyName: 'Casa Praia Miami',
    listingImage: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=200&auto=format&fit=crop'
  },
  {
    airbnbConfirmationCode: 'HMW987654',
    guestName: 'Kyle Reese',
    checkIn: addDays(0), // Arriving today
    checkOut: addDays(4),
    guestCount: 2,
    previousReviews: [],
    specialRequests: '',
    propertyName: 'Apartamento Downtown',
    listingImage: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?q=80&w=200&auto=format&fit=crop'
  }
];

export const AirbnbService = {
  // Simulates fetching data from Airbnb API
  syncReservations: async (): Promise<SyncedReservation[]> => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    return mockReservations;
  },

  // Helper to check if a job already exists for this reservation
  shouldCreateJob: (reservation: SyncedReservation, existingJobs: any[]) => {
    // Logic to check duplicates would go here
    return true; 
  }
};