import React, { lazy, Suspense, useEffect, useRef } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { ToastProvider, useToast } from '@/components/ui/toaster';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Setup Query Client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5, // 5 minutes
    },
  },
});

// Feature-based Lazy Loading
const Login = lazy(() => import('@/pages/Login'));
const Dashboard = lazy(() => import('@/pages/Dashboard'));

// Scheduling Feature
const Jobs = lazy(() => import('@/features/scheduling/pages/Jobs'));
const JobDetail = lazy(() => import('@/features/scheduling/pages/JobDetail'));

// Properties Feature
const Properties = lazy(() => import('@/features/properties/pages/Properties'));
const PropertyDetail = lazy(() => import('@/features/properties/pages/PropertyDetail'));

// Cleaning Feature
const Checklist = lazy(() => import('@/features/cleaning/pages/Checklist'));

// Earnings Feature
const Earnings = lazy(() => import('@/features/earnings/pages/Earnings'));

// Intelligence Feature
const ManagerDashboard = lazy(() => import('@/pages/ManagerDashboard'));
const AutoPilotConfig = lazy(() => import('@/pages/AutoPilotConfig'));
const Performance = lazy(() => import('@/pages/Performance'));

const Partners = lazy(() => import('@/pages/Partners'));
const Settings = lazy(() => import('@/pages/Settings'));
const NotFound = lazy(() => import('@/pages/NotFound'));

// Loading component
const PageLoader = () => (
  <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="relative w-20 h-20 mb-6"
    >
      <div className="absolute inset-0 bg-blue-400/20 blur-2xl rounded-full animate-pulse" />
      <img 
        src="https://i.ibb.co/yBMkg7CV/Design-sem-nome.png" 
        alt="Loading..." 
        className="w-full h-full object-contain relative z-10"
      />
    </motion.div>
    <Loader2 className="h-6 w-6 animate-spin text-primary/70" />
  </div>
);

// Auth Guard
const RequireAuth = ({ children }: React.PropsWithChildren) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <PageLoader />;
  
  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

// Public only (redirect if logged in)
const PublicOnly = ({ children }: React.PropsWithChildren) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <PageLoader />;
  
  if (user) {
    // Redirect to the page they were trying to visit, or dashboard by default
    const from = (location.state as any)?.from?.pathname || "/dashboard";
    return <Navigate to={from} replace />;
  }

  return <>{children}</>;
};

// Notification Logic Component
const NotificationManager = () => {
  const { info, warning } = useToast();
  const hasRunSimulation = useRef(false);

  useEffect(() => {
    // Request permission on mount
    if ('Notification' in window && Notification.permission !== 'granted') {
      Notification.requestPermission();
    }

    // Mock upcoming job check
    const checkUpcomingJobs = () => {
      const shouldNotify = Math.random() > 0.8; // 20% chance every check
      
      if (shouldNotify && Notification.permission === 'granted') {
        new Notification('Próximo Job: Casa Praia Miami', {
          body: 'O serviço começa em 1 hora. Prepare-se!',
          icon: 'https://i.ibb.co/yBMkg7CV/Design-sem-nome.png'
        });
        
        info({ title: 'Lembrete de Job', description: 'Casa Praia Miami começa em 1h' });
      }
    };

    // Simulate Airbnb "Guest Arriving" notification
    const checkGuestArrival = () => {
        if (hasRunSimulation.current) return;
        hasRunSimulation.current = true;

        // Trigger simulation
        setTimeout(() => {
            // Check setting before showing
            if (localStorage.getItem('airbnb_alerts_enabled') === 'false') return;

            warning({ 
                title: 'Airbnb Alert', 
                description: 'Hóspede Sarah Connor chega em 2h na Casa Praia Miami.' 
            });
        }, 5000); // 5 seconds after load
    };

    const interval = setInterval(checkUpcomingJobs, 60000 * 5); // Check every 5 minutes
    
    // Initial checks
    checkGuestArrival();

    return () => {
      clearInterval(interval);
    };
  }, [info, warning]);

  return null;
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <NotificationManager />
        <HashRouter>
          <Suspense fallback={<PageLoader />}>
            <Routes>
              <Route path="/login" element={
                <PublicOnly>
                  <Login />
                </PublicOnly>
              } />
              
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              
              <Route path="/dashboard" element={
                <RequireAuth>
                  <Dashboard />
                </RequireAuth>
              } />
              
              <Route path="/jobs" element={
                <RequireAuth>
                  <Jobs />
                </RequireAuth>
              } />
              
              <Route path="/jobs/:id" element={
                <RequireAuth>
                  <JobDetail />
                </RequireAuth>
              } />

              <Route path="/checklist/:jobId" element={
                <RequireAuth>
                  <Checklist />
                </RequireAuth>
              } />
              
              <Route path="/properties" element={
                <RequireAuth>
                  <Properties />
                </RequireAuth>
              } />

              <Route path="/properties/:id" element={
                <RequireAuth>
                  <PropertyDetail />
                </RequireAuth>
              } />
              
              <Route path="/earnings" element={
                <RequireAuth>
                  <Earnings />
                </RequireAuth>
              } />

              <Route path="/analytics" element={
                <RequireAuth>
                  <ManagerDashboard />
                </RequireAuth>
              } />

              <Route path="/autopilot" element={
                <RequireAuth>
                  <AutoPilotConfig />
                </RequireAuth>
              } />

              <Route path="/partners" element={
                <RequireAuth>
                  <Partners />
                </RequireAuth>
              } />

              <Route path="/performance" element={
                <RequireAuth>
                  <Performance />
                </RequireAuth>
              } />
              
              <Route path="/settings" element={
                <RequireAuth>
                  <Settings />
                </RequireAuth>
              } />
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </HashRouter>
      </ToastProvider>
    </QueryClientProvider>
  );
};

export default App;